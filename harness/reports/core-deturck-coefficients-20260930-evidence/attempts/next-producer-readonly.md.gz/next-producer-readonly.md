Read-only preparation by buffered_atlas_contract at 77ffad28907cce2fc9766c3814134e26f662e9eb. No edits/builds performed.

Core helped: UniversalHamiltonConvergenceStatement. Consumer: actual coupled Graph forcing for L=dt-DQ(g0).

Use the same A, psi and xi from the actual g0-adapted local solvers. For q_i=A.cover.anchor i construct actual G_i, DG_i, D2G_i, B_i, DB_i. Let Z_i/F_i be accepted actual zeroOrder/firstOrder maps, Raw0_iabcd=entry_cd(Z_i(tensor_ab)), Raw1_ipabcd=entry_cd(F_i(firstJet_pab)). The existing tsupport xi_i is compact inside the true chart-target/cutoff-one-germ zone U_i.

Construct eta_i using exists_buffered_cutoff: eta smooth compact, tsupport eta subset U_i, eta=1 germwise at all tsupport xi_i. Define c0=eta*Raw0 and c1=eta*Raw1. Global smoothness follows from contDiff_cutoff_mul (ClosedLaplacianStokesGlobalCoefficients:16), compact support from hceta.mul_right, and fixed-generator smoothness from ContDiffOn.clm_apply followed by entryCLM. Export actual raw equality germwise throughout tsupport xi_i, hence on tsupport psi_i.

ParabolicCutoffCommutator.exists_cutoff_carrier (line363) constructs each time-uniform scalar Y carrier from these actual compact coefficients. Sum the finite nonnegative constants before T. The subsequent forcing is the sum of firstOrderForcing over all nine input Graph entries, with zero-order and each of the three directional coefficients. Accepted coefficient_action retains all ordered slots and identifies it with the actual Z(h)+F(Dh). Use the existing norm/time estimates, retain original norms, and subtract the lower forcing in L=dt-DQ.

This is a proposed next producer shape, not a proved compact extension, bound, forcing operator, flow or universal core.
