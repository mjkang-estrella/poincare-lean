import Poincare.Global.DeTurckCoefficientDefinitions
import Lean
open Lean Elab Command Term
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (G0 : Poincare.DeTurckPrincipalSecondJet.Bilin) (i j : Fin 3), G0.IsInvertible →\nContDiffAt ℝ ((⊤ : ENat) : WithTop ENat) (fun G : Poincare.DeTurckPrincipalSecondJet.Bilin => Poincare.DeTurckPrincipalSecondJet.inverseEntries G i j) G0" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: contDiffAt_inverseEntry"
