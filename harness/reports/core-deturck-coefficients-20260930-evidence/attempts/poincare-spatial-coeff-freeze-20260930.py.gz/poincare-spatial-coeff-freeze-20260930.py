import json,hashlib
from pathlib import Path
from harness.v2.runtime.validation import statement_contract_snapshot
root=Path.cwd();folder=root/'harness/v2/contracts/core-deturck-coefficients-20260930';state=root/'harness/v2/state/core-deturck-coefficients-20260930'
E='Poincare.DeTurckPrincipalSecondJet.E';G='Poincare.DeTurckPrincipalSecondJet.Bilin';J='Poincare.DeTurckPrincipalSecondJet.Jet1';F='Poincare.DeTurckJetLinearization';V=F+'.Variables';C='Poincare.DeTurckCoefficients';S='Poincare.DeTurckSpatialCoefficients';A='Poincare.DeTurckPrincipalSecondJet.inverseEntries'
old=json.loads((root/'harness/v2/contracts/core-deturck-linearization-20260930/full.contract.json').read_text())['statement_contract']['declarations'][0]['lean_type'];pre=old.split('∀ (B',1)[0]
for domain in [G,J]:
 target=f'({domain} →L[ℝ] {G})';pre+=f'''letI : NormedAddCommGroup {target} := ContinuousLinearMap.toNormedAddCommGroup
 (𝕜 := ℝ) (𝕜₂ := ℝ) (E := {domain}) (F := {G}) (σ₁₂ := RingHom.id ℝ);
letI : NormedSpace ℝ {target} := ContinuousLinearMap.toNormedSpace
 (𝕜 := ℝ) (𝕜₂ := ℝ) (E := {domain}) (F := {G}) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);
'''
Z=f'{S}.zeroOrder (B z) (fderiv ℝ B z) (G0 z) (fderiv ℝ G0 z) (fderiv ℝ (fderiv ℝ G0) z)';P=f'{S}.firstOrder (B z) (fderiv ℝ B z) (G0 z) (fderiv ℝ G0 z)'
t=pre+f'''∀ (M : Type u) [TopologicalSpace M] [T2Space M]
[ChartedSpace ({E}) M]
[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]
(g0 bg : Poincare.ClosedSmoothRiemannianMetric 3 M) (anchor : M),
let G0 := _root_.CovariantDerivative.chartMetric g0.inner anchor
let B := Poincare.GeodesicTransport.chartChristoffelField bg anchor
let U := (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor).target ∩
 (fun z : {E} => Filter.Eventually (fun y => Poincare.GeodesicTransport.cutoff (n := 3) anchor y = 1) (nhds z))
IsOpen U ∧ (∀ z ∈ U, (G0 z).IsInvertible) ∧
(∀ i j : Fin 3, ContDiffOn ℝ ((⊤ : ENat) : WithTop ENat) (fun z => {A} (G0 z) i j) U) ∧
ContDiffOn ℝ ((⊤ : ENat) : WithTop ENat) (fun z => {Z}) U ∧
ContDiffOn ℝ ((⊤ : ENat) : WithTop ENat) (fun z => {P}) U ∧
∀ z ∈ U, ∀ h : {V},
{F}.differential (B z) (fderiv ℝ B z) (G0 z) (fderiv ℝ G0 z)
 (fderiv ℝ (fderiv ℝ G0) z) h =
{F}.principal (G0 z) h.2 + {Z} h.1.1 + {P} h.1.2'''
pins=['Poincare/Global/RiemannianContext.lean','Poincare/ChartTransport.lean','Poincare/Global/DeTurckPrincipalSecondJet.lean','Poincare/Global/DeTurckPrincipalIdentity.lean','Poincare/Global/DeTurckInverseEntryDerivativeDefinitions.lean','Poincare/Global/DeTurckJetLinearizationDefinitions.lean','Poincare/Global/DeTurckCoefficientDefinitions.lean','Poincare/Global/DeTurckSpatialCoefficientDefinitions.lean']
c={'imports':['Poincare.Global.DeTurckActualSpatialCoefficients'],'declarations':[{'name':'Poincare.DeTurckActualSpatialCoefficients.actual_spatial_coefficients','lean_type':t,'universes':['u']}],'definition_files':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in pins],'author':'root-orchestrator'};c['review']={'reviewer':'deturck-coefficient-readback','method':'blind-readback','snapshot_sha256':statement_contract_snapshot(c),'verdict':'pending','report_path':'harness/v2/contracts/core-deturck-coefficients-20260930/actual.readback.json','report_sha256':'0'*64};(folder/'actual.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
probe='import Poincare.Global.DeTurckSpatialCoefficientDefinitions\nimport Lean\nopen Lean Elab Command Term\nuniverse u\n';probe+=f'run_cmd liftTermElabM do\n  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(t,ensure_ascii=False)} with\n    | .ok s => pure s\n    | .error e => throwError e\n  let expected ← Term.elabType stx\n  Term.synthesizeSyntheticMVarsNoPostponing\n  let expected ← instantiateMVars expected\n  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"\n  logInfo "PREFLIGHT_OK: actual_spatial_coefficients"\n';(state/'actual.preflight.lean').write_text(probe)
