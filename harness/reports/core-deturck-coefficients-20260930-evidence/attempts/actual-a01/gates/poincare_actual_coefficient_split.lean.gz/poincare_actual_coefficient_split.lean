import Poincare.Global.DeTurckSpatialCoefficientDefinitions
noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option synthInstance.maxHeartbeats 100000
open scoped BigOperators
namespace Poincare.DeTurckSpatialCoefficients
open DeTurckPrincipalSecondJet DeTurckJetLinearization
local instance : NormedAddCommGroup Jet1 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance : NormedSpace ℝ Jet1 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance : NormedAddCommGroup Jet2 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1) (σ₁₂ := RingHom.id ℝ)
local instance : NormedSpace ℝ Jet2 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance : AddCommMonoid (Bilin × Jet1) := Prod.instAddCommMonoid


example (B : DeTurckCoefficients.Background)
    (DB : DeTurckCoefficients.BackgroundDerivative)
    (G : Bilin) (J : Jet1) (H : Jet2) (h : Variables) :
    differential B DB G J H h =
      principal G h.2 + zeroOrder B DB G J H h.1.1 + firstOrder B DB G J h.1.2 := by
  have hl : lowerDifferential B DB G J h.1 =
      lowerDifferential B DB G J (h.1.1, 0) +
      lowerDifferential B DB G J (0, h.1.2) := by
    simpa using (lowerDifferential B DB G J).map_add (h.1.1, 0) (0, h.1.2)
  simp only [differential, principal, zeroOrder, firstOrder,
    metricProjection, secondJetEvaluation,
    ContinuousLinearMap.comp_apply, ContinuousLinearMap.add_apply,
    ContinuousLinearMap.sum_apply, ContinuousLinearMap.smulRight_apply,
    ContinuousLinearMap.smul_apply, ContinuousLinearMap.apply_apply,
    ContinuousLinearMap.coe_fst', ContinuousLinearMap.coe_snd',
    ContinuousLinearMap.inl_apply, ContinuousLinearMap.inr_apply]
  rw [hl]
  abel
end Poincare.DeTurckSpatialCoefficients
