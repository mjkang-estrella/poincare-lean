import json,hashlib
from pathlib import Path
from harness.v2.runtime.validation import statement_contract_snapshot
root=Path.cwd();folder=root/'harness/v2/contracts/core-deturck-coefficients-20260930';state=root/'harness/v2/state/core-deturck-coefficients-20260930'
E='Poincare.DeTurckPrincipalSecondJet.E';G='Poincare.DeTurckPrincipalSecondJet.Bilin';J='Poincare.DeTurckPrincipalSecondJet.Jet1';C='Poincare.DeTurckCoefficients';A='Poincare.DeTurckPrincipalSecondJet.inverseEntries'
old=json.loads((root/'harness/v2/contracts/core-deturck-linearization-20260930/joint.contract.json').read_text())['statement_contract']['declarations'][0]['lean_type'];pre=old.split('∀ (B',1)[0]+f'''letI : AddCommMonoid ({G} × {J}) := Prod.instAddCommMonoid;
'''
bridge=pre+f'''∀ (B : {C}.Background) (DB : {C}.BackgroundDerivative) (G0 : {G}) (J0 : {J}),
G0.IsInvertible → {C}.partialLower ((B,DB),(G0,J0)) =
 (fderiv ℝ {C}.jointLower ((B,DB),(G0,J0))).comp {C}.metricInclusion'''
invs=f'''∀ (G0 : {G}) (i j : Fin 3), G0.IsInvertible →
ContDiffAt ℝ ((⊤ : ENat) : WithTop ENat) (fun G : {G} => {A} G i j) G0'''
partial=pre+f'''∀ (B : {C}.Background) (DB : {C}.BackgroundDerivative) (G0 : {G}) (J0 : {J}),
G0.IsInvertible → ContDiffAt ℝ ((⊤ : ENat) : WithTop ENat)
 {C}.partialLower ((B,DB),(G0,J0))'''
pins=['Poincare/Global/RiemannianContext.lean','Poincare/Global/DeTurckPrincipalSecondJet.lean','Poincare/Global/DeTurckPrincipalIdentity.lean','Poincare/Global/DeTurckJetLinearizationDefinitions.lean','Poincare/Global/DeTurckCoefficientDefinitions.lean']
for slug,mod,name,t in [('bridge','DeTurckPartialDerivativeBridge','partialLower_eq_joint_derivative',bridge),('inverse-smooth','DeTurckInverseEntrySmoothness','contDiffAt_inverseEntry',invs),('partial-smooth','DeTurckPartialCoefficientSmoothness','contDiffAt_partialLower',partial)]:
 pp=pins if slug!='inverse-smooth' else pins[:3]
 c={'imports':['Poincare.Global.'+mod],'declarations':[{'name':'Poincare.'+mod+'.'+name,'lean_type':t,'universes':[]}],'definition_files':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in pp],'author':'root-orchestrator'};c['review']={'reviewer':'deturck-coefficient-readback','method':'blind-readback','snapshot_sha256':statement_contract_snapshot(c),'verdict':'pending','report_path':f'harness/v2/contracts/core-deturck-coefficients-20260930/{slug}.readback.json','report_sha256':'0'*64};(folder/f'{slug}.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
 probe='import Poincare.Global.DeTurckCoefficientDefinitions\nimport Lean\nopen Lean Elab Command Term\n';probe+=f'run_cmd liftTermElabM do\n  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(t,ensure_ascii=False)} with\n    | .ok s => pure s\n    | .error e => throwError e\n  let expected ← Term.elabType stx\n  Term.synthesizeSyntheticMVarsNoPostponing\n  let expected ← instantiateMVars expected\n  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"\n  logInfo "PREFLIGHT_OK: {name}"\n';(state/f'{slug}.preflight.lean').write_text(probe)
(folder/'construction-context.md').write_text('''# Actual spatial DeTurck coefficient construction

Core assumption helped by every task: UniversalHamiltonConvergenceStatement through genuine Ricci-flow input construction. Partial derivative bridge and inverse-entry smoothness are consumed by partial coefficient smoothness and the actual-g0 spatial coefficient producer; these feed compact-buffer coefficient bounds and real global L=dt-DQ(g0), tensor covariance, signed L/P/R contraction. Smoothability and universal Hamilton endpoints remain unproved.

The canonical definitions are actual jointLower(B,DB,G,J), partialLower=the existing fderiv with respect only to metric/first jets, and metricInclusion(hG,hJ)=((0,0),(hG,hJ)). Prove equality with the full joint derivative restricted along that inclusion. Do not silently differentiate background data in the PDE direction. No supplied differential/flow/limit package may replace construction.

Joint lower smoothness is already proved with B/DB/G/J varying. hasFDerivAt_prodMk_right + composition and .fderiv prove the bridge. ContDiffAt.fderiv_right (m=n=ENat infinity) then clm_comp with constant inr proves restricted joint derivative smoothness. The bridge must hold in a neighborhood of the point, so derive eventual invertibility from ContinuousLinearEquiv.nhds (range of equivalences) and continuous metric projection before congr_of_eventuallyEq. Do not infer joint spatial smoothness from a fixed-background theorem.

Inverse scalar smoothness must use actual inverseEntries and G0.IsInvertible only. CLM inversion is C-infinity at invertible G0; inverseEntries_eq_coordinates identifies scalar coordinates throughout an eventual invertible neighborhood. No symmetry/determinant/unit/positive-curvature premise may be added. Public Bilin/real norms and actual whole inverse semantics remain unchanged.

Existing canonical Jet/background/product dictionary bindings are proved to preserve actual operator norms and operations. If further default-scope cache pins are needed, preserve failed probes and verify the exact dictionary before revising a draft. No alternate norm/scalar action or supplied hypothesis is allowed. The earlier false Pi.monoid IsUnit Task is superseded and must not be reused.

The subsequent actual-g0 producer must construct true G,DG,D2G,B,DB fields and use chart-target/cutoff-one invertibility. Its zero-order coefficient retains Da(G0)[h]:D2G0 and D_Glower[h]; first-order retains D_Jlower[Dh]. The finite-jet differential and actual-metric chart-evolution identity are already verified. Coefficient boundedness, covariance and full L/R are subsequent unproved obligations.

Local Codex helpers are not registered Pi/Leanstral Jobs. Preserve all source/compiler attempts and final diff. Workers do not full-build/self-accept/merge/manage services. Frozen core statements and Poincare target are unchanged.
''')
