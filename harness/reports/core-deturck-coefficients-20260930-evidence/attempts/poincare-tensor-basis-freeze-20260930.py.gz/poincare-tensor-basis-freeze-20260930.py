import json,hashlib
from pathlib import Path
from harness.v2.runtime.validation import statement_contract_snapshot
root=Path.cwd();folder=root/'harness/v2/contracts/core-deturck-coefficients-20260930';state=root/'harness/v2/state/core-deturck-coefficients-20260930'
E='Poincare.DeTurckPrincipalSecondJet.E';G='Poincare.DeTurckPrincipalSecondJet.Bilin';J='Poincare.DeTurckPrincipalSecondJet.Jet1';B='Poincare.DeTurckTensorBasis';e='Poincare.DeTurckPrincipalSecondJet.basis3';entry='Poincare.DeTurckInverseEntryDerivative.entryCLM'
old=json.loads((folder/'bridge.contract.json').read_text())['statement_contract']['declarations'][0]['lean_type'];pre=old.split('∀ (B',1)[0]
types=[('tensor_expansion',f'''∀ h : {G}, h = ∑ a : Fin 3, ∑ b : Fin 3, h ({e} a) ({e} b) • {B}.tensor a b'''),('firstJet_expansion',pre+f'''∀ J : {J}, J = ∑ p : Fin 3, ∑ a : Fin 3, ∑ b : Fin 3,
 J ({e} p) ({e} a) ({e} b) • {B}.firstJet p a b'''),('coefficient_action',pre+f'''∀ (L0 : {G} →L[ℝ] {G}) (L1 : {J} →L[ℝ] {G})
(h : {G}) (J : {J}) (c d : Fin 3),
{entry} c d (L0 h) = ∑ a : Fin 3, ∑ b : Fin 3,
 {entry} c d (L0 ({B}.tensor a b)) * h ({e} a) ({e} b) ∧
{entry} c d (L1 J) = ∑ p : Fin 3, ∑ a : Fin 3, ∑ b : Fin 3,
 {entry} c d (L1 ({B}.firstJet p a b)) * J ({e} p) ({e} a) ({e} b)''')]
pins=['Poincare/Global/RiemannianContext.lean','Poincare/Global/DeTurckPrincipalSecondJet.lean','Poincare/Global/DeTurckInverseEntryDerivativeDefinitions.lean','Poincare/Global/DeTurckTensorBasisDefinitions.lean'];c={'imports':['Poincare.Global.DeTurckTensorBasisReconstruction'],'declarations':[{'name':B+'.'+n,'lean_type':t,'universes':[]} for n,t in types],'definition_files':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in pins],'author':'root-orchestrator'};c['review']={'reviewer':'deturck-coefficient-readback','method':'blind-readback','snapshot_sha256':statement_contract_snapshot(c),'verdict':'pending','report_path':'harness/v2/contracts/core-deturck-coefficients-20260930/tensor-basis.readback.json','report_sha256':'0'*64};(folder/'tensor-basis.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
probe='import Poincare.Global.DeTurckTensorBasisDefinitions\nimport Lean\nopen Lean Elab Command Term\n'
for n,t in types:
 probe+=f'run_cmd liftTermElabM do\n  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(t,ensure_ascii=False)} with\n    | .ok s => pure s\n    | .error e => throwError e\n  let expected ← Term.elabType stx\n  Term.synthesizeSyntheticMVarsNoPostponing\n  let expected ← instantiateMVars expected\n  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"\n  logInfo "PREFLIGHT_OK: {n}"\n'
(state/'tensor-basis.preflight.lean').write_text(probe)
(folder/'tensor-basis-context.md').write_text('''# Actual scalar extraction of coupled DeTurck coefficients

Core assumption helped: UniversalHamiltonConvergenceStatement through true Ricci-flow construction. Subsequent consumer: construct scalar zero/first-order coefficient arrays from ACTUAL zeroOrder/firstOrder fields and their smooth compact buffers, then true coupled Graph forcing CLM for L=dt-DQ(g0), covariance and signed L/P/R contraction.

The elementary tensor basis is q_a.smulRight q_b, q_a the actual Euclidean coordinate CLM. First jet basis is q_p.smulRight tensor_a_b. Reconstruct all nine bilinear entries and all 27 first-jet slots; no symmetric-six encoding or half-offdiagonal convention is permitted. Existing FrozenEllipticHeatOperator.bilinear_expansion, EuclideanSpace.basisFun.sum_repr/basisFun_repr and map_sum/map_smul supply the finite identities. The coefficient action identities must evaluate the actual arbitrary L0/L1 on these basis elements; the subsequent actual-g0 producer already constructs concrete L0/L1, so no unconstructed coefficient package replaces it.

No new norms, symmetry/realization/invertibility premise or supplied flow/limit is needed for this algebra. Canonical Jet1 binding retains original operator norm. Preserve source/compiler failures/finaldiff and run exact gates. Local helpers are not registered Pi/Leanstral Jobs; workers do not selfaccept/merge/fullbuild/manage services. Both universal cores and frozen final Poincare target remain open/unchanged.
''')
