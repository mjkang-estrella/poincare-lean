import Poincare.Global.DeTurckSpatialCoefficientDefinitions
import Lean
open Lean Meta Elab Command Term
universe u
partial def rootChartApps (e : Expr) : List Expr :=
  match e with
  | .app f a =>
      if e.getAppFn.constName? == some ``CovariantDerivative.chartMetric then [e]
      else rootChartApps f ++ rootChartApps a
  | .lam _ t b _ => rootChartApps t ++ rootChartApps b
  | .forallE _ t b _ => rootChartApps t ++ rootChartApps b
  | .letE _ t v b _ => rootChartApps t ++ rootChartApps v ++ rootChartApps b
  | .mdata _ b => rootChartApps b
  | .proj _ _ b => rootChartApps b
  | _ => []
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "letI : NormedAddCommGroup Poincare.DeTurckPrincipalSecondJet.Jet1 :=\n  ContinuousLinearMap.toNormedAddCommGroup\n    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin)\n    (σ₁₂ := RingHom.id ℝ);\nletI : NormedSpace ℝ Poincare.DeTurckPrincipalSecondJet.Jet1 :=\n  ContinuousLinearMap.toNormedSpace\n    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin)\n    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);\nletI : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ);\nletI : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);\nletI : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ);\nletI : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);\nletI : NormedAddCommGroup Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedAddCommGroup\n (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ);\nletI : NormedSpace ℝ Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedSpace\n (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);\nletI : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.normedAddCommGroup;\nletI : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.normedSpace;\nletI : NormedAddCommGroup Poincare.DeTurckJetLinearization.Variables := Prod.normedAddCommGroup;\nletI : NormedSpace ℝ Poincare.DeTurckJetLinearization.Variables := Prod.normedSpace;\nletI : AddCommMonoid (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.instAddCommMonoid;\nletI : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.Bilin →L[ℝ] Poincare.DeTurckPrincipalSecondJet.Bilin) := ContinuousLinearMap.toNormedAddCommGroup\n (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.Bilin) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ);\nletI : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.Bilin →L[ℝ] Poincare.DeTurckPrincipalSecondJet.Bilin) := ContinuousLinearMap.toNormedSpace\n (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.Bilin) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);\nletI : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.Jet1 →L[ℝ] Poincare.DeTurckPrincipalSecondJet.Bilin) := ContinuousLinearMap.toNormedAddCommGroup\n (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.Jet1) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ);\nletI : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.Jet1 →L[ℝ] Poincare.DeTurckPrincipalSecondJet.Bilin) := ContinuousLinearMap.toNormedSpace\n (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.Jet1) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);\n∀ (M : Type u) [TopologicalSpace M] [T2Space M]\n[ChartedSpace (Poincare.DeTurckPrincipalSecondJet.E) M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(g0 bg : Poincare.ClosedSmoothRiemannianMetric 3 M) (anchor : M),\nlet G0 := _root_.CovariantDerivative.chartMetric (I := Poincare.closedSmoothModelWithCorners 3) g0.inner anchor\nlet B := Poincare.GeodesicTransport.chartChristoffelField bg anchor\nlet U := (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor).target ∩\n (fun z : Poincare.DeTurckPrincipalSecondJet.E => Filter.Eventually (fun y => Poincare.GeodesicTransport.cutoff (n := 3) anchor y = 1) (nhds z))\nIsOpen U ∧ (∀ z ∈ U, (G0 z).IsInvertible) ∧\n(∀ i j : Fin 3, ContDiffOn ℝ ((⊤ : ENat) : WithTop ENat) (fun z => Poincare.DeTurckPrincipalSecondJet.inverseEntries (G0 z) i j) U) ∧\nContDiffOn ℝ ((⊤ : ENat) : WithTop ENat) (fun z => Poincare.DeTurckSpatialCoefficients.zeroOrder (B z) (fderiv ℝ B z) (G0 z) (fderiv ℝ G0 z) (fderiv ℝ (fderiv ℝ G0) z)) U ∧\nContDiffOn ℝ ((⊤ : ENat) : WithTop ENat) (fun z => Poincare.DeTurckSpatialCoefficients.firstOrder (B z) (fderiv ℝ B z) (G0 z) (fderiv ℝ G0 z)) U ∧\n∀ z ∈ U,\nlet Gz : Poincare.DeTurckPrincipalSecondJet.Bilin := G0 z\nlet Jz : Poincare.DeTurckPrincipalSecondJet.Jet1 := fderiv ℝ G0 z\nlet Hz : Poincare.DeTurckJetLinearization.Jet2 := fderiv ℝ (fderiv ℝ G0) z\nlet Bz : Poincare.DeTurckCoefficients.Background := B z\nlet DBz : Poincare.DeTurckCoefficients.BackgroundDerivative := fderiv ℝ B z\n∀ h : Poincare.DeTurckJetLinearization.Variables,\n\nPoincare.DeTurckJetLinearization.differential Bz DBz Gz Jz\n Hz h =\nPoincare.DeTurckJetLinearization.principal Gz h.2 + Poincare.DeTurckSpatialCoefficients.zeroOrder Bz DBz Gz Jz Hz h.1.1 + Poincare.DeTurckSpatialCoefficients.firstOrder Bz DBz Gz Jz h.1.2" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"
  if expected.hasSorry then throwError "recovered placeholder"
  let ci ← getConstInfo ``CovariantDerivative.chartMetric
  let names ← forallTelescope ci.type fun xs _ => do
    xs.toList.mapM fun x => do pure (← getFVarLocalDecl x).userName
  let some iIndex := names.findIdx? (· == `I) | throwError "model I binder not found"
  logInfo m!"CHART_METRIC_BINDERS: {names}; I_INDEX={iIndex}"
  let apps := rootChartApps expected
  if apps.isEmpty then throwError "no chartMetric application in actual target"
  let canon ← Term.elabTerm (← `(term| Poincare.closedSmoothModelWithCorners 3)) none
  Term.synthesizeSyntheticMVarsNoPostponing
  let canon ← instantiateMVars canon
  for k in [:apps.length] do
    let args := apps[k]!.getAppArgs
    let actualI := args[iIndex]!
    logInfo m!"ACTUAL_CHART_MODEL[{k}]: {actualI}; APP_ARITY={args.size}"
    let eqTy ← mkEq actualI canon
    let proof ← mkEqRefl actualI
    addDecl <| .thmDecl {
      name := Name.mkSimple ("RootActualChartModelEq" ++ toString k)
      levelParams := []
      type := eqTy
      value := proof }
  logInfo "PREFLIGHT_OK: actual chartMetric I dictionary equals closedSmoothModelWithCorners 3 by kernel rfl"

