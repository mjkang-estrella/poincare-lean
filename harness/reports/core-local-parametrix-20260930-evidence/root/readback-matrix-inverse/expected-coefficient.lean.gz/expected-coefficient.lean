import Poincare.Global.BufferedFrozenParabolicSolver
noncomputable section
set_option pp.all true
#check @Poincare.BufferedFrozenParabolicSolver.chartValue
#check fun (α T : ℝ)
  (F : Poincare.ClosedSmoothModel 3 → Matrix (Fin 3) (Fin 3) ℝ)
  (G : Poincare.ParabolicSolutionGraph.Graph (E := Poincare.ClosedSmoothModel 3) α T)
  (p : ℝ × Poincare.ClosedSmoothModel 3) =>
  Poincare.BufferedFrozenParabolicSolver.chartValue
    (fun z => @Inv.inv (Matrix (Fin 3) (Fin 3) ℝ) Matrix.inv (F z)) G p
#check fun (α T : ℝ)
  (F : Poincare.ClosedSmoothModel 3 → Matrix (Fin 3) (Fin 3) ℝ)
  (G : Poincare.ParabolicSolutionGraph.Graph (E := Poincare.ClosedSmoothModel 3) α T)
  (p : ℝ × Poincare.ClosedSmoothModel 3) =>
  Poincare.BufferedFrozenParabolicSolver.chartValue
    (fun z => (F z)⁻¹) G p
