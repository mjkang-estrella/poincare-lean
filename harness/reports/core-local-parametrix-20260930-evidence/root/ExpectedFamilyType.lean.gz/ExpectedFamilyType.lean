import Poincare.Global.MetricAdaptedBufferedAtlas
open scoped Manifold ContDiff Topology
universe u
#check (∀ {M : Type u} [TopologicalSpace M] [T2Space M] [CompactSpace M] [ChartedSpace (Poincare.ClosedSmoothModel 3) M], ∀ [IsManifold (modelWithCornersSelf ℝ (Poincare.ClosedSmoothModel 3)) ((⊤ : ENat) : WithTop ENat) M], ∀ (g0 : Poincare.ClosedSmoothRiemannianMetric 3 M) (α : ℝ), 0 < α → α < 1 →
 ∃ A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M,
 ∃ ψ ξ : Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → ℝ,
 (∀ i, ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (ψ i) ∧ HasCompactSupport (ψ i) ∧
   (∀ z ∈ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A i, Filter.Eventually (fun y ↦ ψ i y = 1) (nhds z)) ∧
   (∀ z, ψ i z ∈ Set.Icc 0 1) ∧
   ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (ξ i) ∧ HasCompactSupport (ξ i) ∧
   (∀ z, ξ i z ∈ Set.Icc 0 1) ∧ (∀ z ∈ tsupport (ψ i), ξ i z = 1) ∧
   tsupport (ξ i) ⊆ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).target ∧
   (∀ z ∈ tsupport (ξ i), Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor i) y = 1) (nhds z))) ∧
 ∃ Cψ CP τ : ℝ, 0 ≤ Cψ ∧ 0 ≤ CP ∧ 0 < τ ∧ τ ≤ 1 ∧
 ∀ T ∈ Set.Ioc 0 τ,
   ∃ P : Fin A.cover.chartCount → (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ℝ) →L[ℝ] (Poincare.ParabolicSolutionGraph.Graph (E := (Poincare.ClosedSmoothModel 3)) α T),
   ∃ R : Fin A.cover.chartCount → (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ℝ) →L[ℝ] (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ℝ),
   ∀ i, (∀ f p, p.2 ∉ tsupport (ψ i) → (P i f).u p = 0) ∧
     ∀ f : (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ℝ), (∀ p, p.2 ∉ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A i → f p = 0) →
       (∀ p, R i f p = Poincare.BufferedFrozenParabolicSolver.chartValue
         (fun z ↦ (Poincare.inverseChartPullbackGramMatrixField g0 (A.cover.anchor i) z)⁻¹)
         (P i f) p - f p) ∧
       ‖R i f‖ ≤ Cψ * (T ^ ((1-α)/2) + T ^ (1-α/2)) * ‖f‖ ∧
       ‖P i f‖ ≤ CP * ‖f‖)
