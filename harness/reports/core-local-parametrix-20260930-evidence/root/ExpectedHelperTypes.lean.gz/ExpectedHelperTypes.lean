import Poincare.Global.MetricAdaptedBufferedAtlas
open scoped Manifold ContDiff Topology
universe u
#check (∀ {M : Type u} [TopologicalSpace M] [T2Space M] [CompactSpace M] [ChartedSpace (Poincare.ClosedSmoothModel 3) M], ∀ [IsManifold (modelWithCornersSelf ℝ (Poincare.ClosedSmoothModel 3)) ((⊤ : ENat) : WithTop ENat) M], ∀ (g0 : Poincare.ClosedSmoothRiemannianMetric 3 M) (p : M), ∀ z ∈ (extChartAt (modelWithCornersSelf ℝ (Poincare.ClosedSmoothModel 3)) p).target, (Poincare.inverseChartPullbackGramMatrixField g0 p z)⁻¹ |>.PosDef)
#check (∀ {M : Type u} [TopologicalSpace M] [T2Space M] [CompactSpace M] [ChartedSpace (Poincare.ClosedSmoothModel 3) M], ∀ [IsManifold (modelWithCornersSelf ℝ (Poincare.ClosedSmoothModel 3)) ((⊤ : ENat) : WithTop ENat) M], ∀ (g0 : Poincare.ClosedSmoothRiemannianMetric 3 M) (p : M) (i j : Fin 3), ContDiffOn ℝ ((⊤ : ENat) : WithTop ENat) (fun z ↦ (Poincare.inverseChartPullbackGramMatrixField g0 p z)⁻¹ i j) (extChartAt (modelWithCornersSelf ℝ (Poincare.ClosedSmoothModel 3)) p).target)
#check (∀ (n : ℕ) (C D τ : Fin n → ℝ), (∀ i, 0 ≤ C i) → (∀ i, 0 ≤ D i) → (∀ i, 0 < τ i) → ∃ C₀ D₀ δ : ℝ, 0 ≤ C₀ ∧ 0 ≤ D₀ ∧ 0 < δ ∧ δ ≤ 1 ∧ ∀ i, C i ≤ C₀ ∧ D i ≤ D₀ ∧ δ ≤ τ i)
