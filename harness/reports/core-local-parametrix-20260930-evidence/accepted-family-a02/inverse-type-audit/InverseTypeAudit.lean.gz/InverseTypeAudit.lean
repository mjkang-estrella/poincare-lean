import Poincare.Global.MetricInverseCoefficientRegularity
import Poincare.Global.MetricAdaptedBufferedAtlas
import Lean

open Lean Elab Command

namespace LocalInverseInstanceAudit

partial def constants (e : Expr) (seen : NameSet := {}) : NameSet :=
  match e with
  | .const n _ => seen.insert n
  | .proj n _ e => constants e (seen.insert n)
  | .app f a => constants a (constants f seen)
  | .lam _ t b _ | .forallE _ t b _ => constants b (constants t seen)
  | .letE _ t v b _ => constants b (constants v (constants t seen))
  | .mdata _ e => constants e seen
  | _ => seen

partial def inverseInstances (e : Expr) : Array Expr :=
  let own := if e.getAppFn.isConstOf ``Inv.inv && e.getAppArgs.size == 3 then
    #[e.getAppArgs[1]!]
    else #[]
  own ++ match e with
  | .proj _ _ e => inverseInstances e
  | .app f a => inverseInstances f ++ inverseInstances a
  | .lam _ t b _ | .forallE _ t b _ => inverseInstances t ++ inverseInstances b
  | .letE _ t v b _ => inverseInstances t ++ inverseInstances v ++ inverseInstances b
  | .mdata _ e => inverseInstances e
  | _ => #[]

run_cmd do
  let names := #[
    ``Poincare.MetricCoefficientNeighborhoods.inverse_metric_entry_continuousAt,
    ``Poincare.MetricCoefficientNeighborhoods.exists_coefficient_neighborhoods,
    ``Poincare.MetricAdaptedBufferedAtlas.exists_metric_adapted_buffered_atlas,
    ``Poincare.MetricInverseCoefficientRegularity.inverse_metric_field_posDef,
    ``Poincare.MetricInverseCoefficientRegularity.inverse_metric_entry_contDiffOn]
  for name in names do
    let ci ← getConstInfo name
    let instances := inverseInstances ci.type
    logInfo s!"DECLARATION {name}: type has {instances.size} inverse occurrences"
    for i in [:instances.size] do
      let inst := instances[i]!
      let head := inst.getAppFn.constName?
      logInfo s!"INSTANCE_HEAD {i}: {head}"
      unless head == some ``Matrix.inv do
        throwError "Unexpected inverse instance in {name}: {reprStr inst}"
      logInfo s!"INVERSE_INSTANCE {i}: {reprStr inst}"
      logInfo s!"INSTANCE_CONSTANTS {i}: {(constants inst).toArray.map Name.toString}"
    let invConsts := (constants ci.type).toArray.filter fun n =>
      (n.toString.splitOn "Inv").length > 1
    logInfo s!"ALL_TYPE_INVERSE_CONSTANTS: {invConsts.map Name.toString}"
    logInfo s!"RAW_TYPE: {reprStr ci.type}"

end LocalInverseInstanceAudit
