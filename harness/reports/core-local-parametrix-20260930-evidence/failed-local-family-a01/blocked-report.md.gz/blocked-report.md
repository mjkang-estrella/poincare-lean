# Local-family a01: blocked frozen-type discrepancy

Base: 127725fb499b88b5b35654479d8859afeb8f4448
Owned source: Poincare/Global/MetricAdaptedLocalParametrix.lean
Status: held for orchestrator contract audit; no source commit or acceptance.

First fresh Lean compilation failed at hidentity. The actual solver proves R f = chartValue (fun z => @Inv.inv (Matrix (Fin 3) (Fin 3) Real) Matrix.inv (inverseChartPullbackGramMatrixField g0 anchor z)) (P f) - f. The source/frozen residual expression using ordinary inverse notation elaborates instead to @Inv.inv (Fin 3 -> Fin 3 -> Real) Pi.instInv, because chartValue expects function-valued coefficients. These functions represent different mathematical operators. The exact compiler type mismatch is preserved in compile-01.log and source in compile-01.source.lean.

No extra premise or altered identity was supplied. Root ordered source changes stopped and a01 evidence retained before any further attempt; any corrected contract requires author/reviewer audit and a newly dispatched attempt. Current source remains an unverified draft. Exact frozen gate and remaining acceptance gates have not been run for this blocked attempt.

Strongest verified inputs remain the imported metric-adapted buffered atlas, actual inverse coefficient regularity, finite common bounds/lifespans and single-chart parametrix. This construction aims at actual global tensor L/P/R assembly, toward UniversalHamiltonConvergenceStatement; neither core assumption has been discharged.
