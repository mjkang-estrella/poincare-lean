# Inverse coefficient regularity: verified worker result

Base: 055e782f94da95290584a4dbe047351cadb83bf9.
Branch: codex/core-inverse-regularity-a01.
Owned source: Poincare/Global/MetricInverseCoefficientRegularity.lean only.

Core assumption helped: UniversalHamiltonConvergenceStatement, through actual
Ricci-flow input construction. Subsequent consumer:
MetricAdaptedLocalParametrix.exists_metric_adapted_local_parametrix. This result
supplies the actual positive frozen inverse matrix and smooth variable inverse
entries required by BufferedFrozenParabolicSolver.exists_single_chart_parametrix.

Proved both exact frozen exports. Positivity identifies the actual Gram field
with the bilinear form matrix in the genuine inverse-chart tangent basis;
metric positivity gives the quadratic form positivity, then Matrix.PosDef.inv
proves positivity of its inverse. Smoothness derives actual Gram entry
smoothness locally from the metric section, reuses the existing pure smooth
determinant lemma and accepted determinant nonzero result, and differentiates
the reciprocal determinant times adjugate formula. No connectedness,
measurable/Borel, curvature, flow or independent ellipticity premise was added.
The compactness binder remains as prescribed by the frozen reviewed types.

Verification: all four scoped Task gates passed; the internal-inclusive scan
found exactly two emitted declarations, both safe/nonpartial and using only
propext, Classical.choice and Quot.sound. No full build was run; the frozen
audit performed its specified targeted module build. First compiler attempt
failed at invalid include-binder syntax and is retained in compile-01 with its
source snapshot and exit code. Corrected compile-02 passed. The final source
produces only the expected unused explicit compactness binder warning.

No core assumption is wholly discharged by this helper. Global tensor L/P/R
assembly, nonlinear inversion, ordinary initial-time joint C3, general Ricci
flow, continuation/surgery and favorable metric/limit existence remain open.
The separate smoothability core is unchanged. Worker has not accepted or
merged the Task; independent orchestrator acceptance is required.
