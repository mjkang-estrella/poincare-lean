# Finite local solver bounds: verified worker result

Base: 055e782f94da95290584a4dbe047351cadb83bf9
Source commit: 3023dddac0bf593dc5381c195980113386b0b082
Branch: codex/core-finite-bounds-a01
Owned source: Poincare/Global/FiniteLocalSolverBounds.lean

Core assumption helped: UniversalHamiltonConvergenceStatement, through the construction of actual general Ricci-flow inputs. Neither this core nor smoothability is discharged by this finite arithmetic lemma.

Subsequent consumer: MetricAdaptedLocalParametrix.exists_metric_adapted_local_parametrix. Apply this theorem to the nonnegative bounds and positive lifespans already constructed by the single-chart parametrices. It supplies one common positive time interval before global tensor operator assembly.

Exact conclusion: for any n, nonnegative C,D : Fin n -> Real and positive tau : Fin n -> Real, there are nonnegative C0,D0 and delta > 0 with delta <= 1 and, for every i, C i <= C0, D i <= D0 and delta <= tau i. No nonempty-index or uniform-lifespan premise is added. The witnesses are C0 = sum C, D0 = sum D and delta = 1/(1 + sum (1/tau i)); the empty family has delta = 1.

All four frozen Task gates passed: fresh source Lean compilation, forbidden-token scan, git diff --check, and exact reviewed frozen type/permitted-axiom audit. Staged whitespace was additionally checked so the new file was included. No full repository build or root edit was performed. One compiler attempt sufficed; no failed compiler attempts occurred. The source, compiler log, gate logs, task snapshot and base-relative final diff are preserved here. Task acceptance and integration remain the root orchestrator's responsibility.
