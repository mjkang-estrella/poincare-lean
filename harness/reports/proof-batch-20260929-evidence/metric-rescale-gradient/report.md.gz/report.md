# Metric scalar-gradient rescaling worker result

Status: proved, awaiting independent root review.
Base: 25fa4718fb9ff2c93c02106209d2fa72bd29bf47
Branch: codex/proof-metric-rescale-gradient-a01
Worktree: /Users/mjkang/.codex/worktrees/proof-metric-rescale-gradient/poincare
Scope: new Poincare/Global/MetricRescaleScalarGradient.lean only.

Exact deliverable: Poincare.MetricRescaleScalarGradient.constSMul_scalarGradNormSqAt
Frozen type and universes pass definitional-equality comparison against the task snapshot.
Five named lemmas prove metric duality rescaling, zero chosen gradient outside differentiability,
nonzero scalar homogeneity, c^-2 scalar-curvature vector scaling, and c^-3 squared norm scaling.
No stronger differentiability premise was added to the target.

Verification:
- Fresh focused single-thread source compilation passed, compile-02.log.
- Fresh focused compiler olean output written only into this evidence directory, compile-03-olean.log.
- Exact frozen type, dependency safety, target axioms, and every emitted module declaration passed,
  contract-and-axioms-03.log: FROZEN_CONTRACT_OK and GATE_SCAN declarations=17 nonstandard=[].
- Target and all five named mathematical lemmas use exactly propext, Classical.choice, Quot.sound.
- Forbidden-token scan and staged/base diff whitespace checks pass, token-check.log and final.patch.
- Pinned definition hashes and blind readback validated before the exact probe.

Actual failures retained:
- compile-01.log: field_simp left (df)(w)*(1-1)=0; fixed with ring.
- contract-and-axioms.log: a partial Poincare search-path overlay omitted imported oleans;
  fixed by symlinking unchanged artifacts into the private overlay.
- contract-and-axioms-02.log: generated type parser lacked notation scopes for infinity;
  evidence-only probe adds open scoped Manifold ContDiff before the identical frozen type.
  No contract/source definition was changed. Root acceptance must open these scopes too.

No full build, root import edit, service operation, merge, or Task acceptance performed.
First independent action: env LEAN_NUM_THREADS=1 lake env lean Poincare/Global/MetricRescaleScalarGradient.lean
Then rerun the identical frozen type with Manifold and ContDiff scopes and all-declaration axioms.
