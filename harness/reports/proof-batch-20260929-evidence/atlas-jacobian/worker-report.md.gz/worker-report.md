# Atlas Jacobian worker result

Base: `25fa4718fb9ff2c93c02106209d2fa72bd29bf47`.
Head: `9e50d3dcaccb3bc38fe6f5c31dbc75083c4d5277`.
Branch: `codex/proof-atlas-jacobian-a01`.
Scope: the new `Poincare/Global/FiniteAtlasJacobianCocycle.lean` only.

The exact frozen `Poincare.FiniteAtlasParabolicTensorSpace.jac_cocycle`
is proved with all three genuine chart-source hypotheses. The new file
also proves ordinary-derivative conversion to `tangentCoordChange`,
derivative composition, Euclidean-basis matrix composition, `jac_self`,
`jac_left_inverse`, `covariant_twoTensor_self`, and
`covariant_twoTensor_cocycle`.

Fresh focused Lean compilation passes. The final copied-source probe
checks the literal frozen type and every emitted declaration dependency.
All 12 emitted declarations, including three lazily generated equation
lemmas for existing definitions, use only `propext`, `Classical.choice`,
and `Quot.sound`. The nine named new theorems are all checked. Forbidden
token and base-relative whitespace checks pass. Both original definition
file hashes still match the frozen task. The checkout is clean.

Commits:
- `756e168dc84f5a50be0a06f57d8f2c7b2a5331ca`: Jacobian identity and cocycle.
- `9e50d3dcaccb3bc38fe6f5c31dbc75083c4d5277`: covariant tensor contraction laws.

No bounded chart transport, field reconstruction, global solver, or final
Poincare theorem is claimed. No root import, existing definition, service,
model process, main checkout, or frozen contract was changed. No full build
was launched. The orchestrator must independently review and accept.

First orchestrator action: rerun the frozen scoped Lean gate against the
base-relative diff, then run the literal contract/dependency probe from the
same checkout before integration.
