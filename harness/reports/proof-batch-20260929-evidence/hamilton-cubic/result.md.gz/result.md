# Hamilton cubic reaction task result

Date: 2026-09-29.
Task: completion-20260929-hamilton-cubic revision 1.
Base: 25fa4718fb9ff2c93c02106209d2fa72bd29bf47.
Worktree: /Users/mjkang/.codex/worktrees/proof-hamilton-cubic/poincare.
Branch: codex/proof-hamilton-cubic-a01.

The exact frozen theorem Poincare.HamiltonScalarGradientEstimate.cubic_reaction_le_four_scalar_mul_traceless is proved. This is a Codex assistant result for independent root review, not acceptance or integration. Only Poincare/Global/HamiltonScalarGradientEstimate.lean changed, with all 21,741 original bytes preserved as a prefix and 51 appended lines.

The proof uses the existing positive-scalar reaction remainder inequality to obtain R C <= 4 N^2. Subtracting the scalar trace reaction gives R T <= 4 N U. The quotient hypothesis gives N <= R^2, and the genuine traceless squared norm satisfies U >= 0. These combine to R T <= 4 R^2 U, then positive R permits cancellation. The conclusion is a pointwise invariant cubic estimate; no flow existence or parabolic statement is added.

Verification:
- Fresh focused Lean elaboration, exit 0, silent, 5.078 seconds: 07-focused-final.json and .out.
- Targeted module build, exit 0, 11.450 seconds: 06-module-build.json and .out. It reports 3,578 jobs with only the final module freshly built in 6.1 seconds; warnings replayed from imports.
- Exact frozen type comparison at rigid universe u and named allowed-axiom/dependency check, exit 0: 11-scoped-contract-and-module-axioms.json and .out.
- Module-wide axiom scan including internal/generated declarations, exit 0, MODULE_AXIOMS_PASS declarations=18. Every printed footprint is [propext, Classical.choice, Quot.sound].
- Forbidden-token scan and git diff --check, exit 0: 12-forbidden-final and 13-diff-check-final.
- Frozen context source hashes and blind readback verify_context pass. Original-byte preservation checked independently against the base.

The raw generated probe initially could not parse the frozen infinity notation because its generator has no open scoped ContDiff prelude. The failed output is retained in 08-contract-and-module-axioms.out. ScopedContractAndAxioms.lean adds only open scoped Manifold ContDiff Topology before the unchanged generated exact-type code; the frozen type, universe contract, definitions and task are unchanged. That probe passes. Root should include the notation prelude for its independent review or repair the generator separately.

Earlier focused failures and the linter-producing successful trial are preserved in 01 through 03. The final focused check is silent. The base-relative final diff is final-proof.diff. No full build, root-import change, service operation, merge, main edit, or acceptance was performed.

Next exact reviewer command: LEAN_NUM_THREADS=1 lake env lean Poincare/Global/HamiltonScalarGradientEstimate.lean, then independently run the unchanged frozen contract type under the notation prelude and module-wide axiom scan from this base.
