# Smooth-germ automatic invertibility: proved

Date: 2026-09-29.
Base: 25fa4718fb9ff2c93c02106209d2fa72bd29bf47.
Worker head: 01e3a4d1dec4fd7855f6d67587970d0a634e147e.
Branch: codex/proof-smooth-germ-invertibility-a01.
Owned file: Poincare/Global/SmoothabilitySmoothGermInvertibilityReduction.lean.

The exact frozen theorem locallySmoothlyConjugate_of_locallySmoothlyExtendable is proved with the unchanged frozen assumptions. The supplied corrections remain fixed. Compact extraction retains those corrections literally, and the existing smooth partition-of-unity construction supplies global smooth extensions of every ordered edge. Actual reversed chart transitions make the two blended extensions compose to the identity on the genuine open corrected overlap. Continuity of their derivatives extends that identity to every compact-domain boundary point. Finite dimensionality makes the derivative invertible. A restricted inverse-function chart has all derivatives invertible on one fixed open neighborhood, so its inverse is smooth there to every order.

This result constructs neither the corrections nor their smooth local extensions. Universal topological smoothing and the Poincare endpoint are not claimed.

Verification:
- Exact acceptance scoped compile passed, 2.537 seconds in the final run.
- A compiled temporary module plus literal frozen-type assignment passed.
- All 15 emitted declarations, including compiler-generated declarations, have dependencies contained in propext, Classical.choice, Quot.sound. Every substantive theorem has exactly these three dependencies.
- Forbidden-token scan and working/staged diff checks passed.
- No root import, full build, merge, acceptance, or service mutation was performed.
- Worktree is clean after the proof commit.

Append-only evidence:
- compile-02.log preserves the actual failed reverse-pair rewrite.
- exact-contract-and-axioms.log preserves the initial temporary namespace projection failure.
- compile-final.log/json, acceptance-0.log through acceptance-3.log and acceptance.json preserve final scoped gates.
- exact-contract-and-axioms.lean and exact-contract-and-axioms-02.log/json preserve exact type and complete declaration axiom checks.
- proof.diff is the base-relative proof diff.

First independent action: from this worker head, run LEAN_NUM_THREADS=1 lake env lean Poincare/Global/SmoothabilitySmoothGermInvertibilityReduction.lean, inspect proof.diff, and repeat the frozen literal type/axiom probe using an ephemeral compiled module projection.
