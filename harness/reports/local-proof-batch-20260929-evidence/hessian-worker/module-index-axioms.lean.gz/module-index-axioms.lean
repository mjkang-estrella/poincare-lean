import Lean
import Poincare.Global.HamiltonScalarGradientHessianBound
open Lean Elab Command
run_cmd do
  let env := (← getEnv).setExporting false
  let some moduleIndex := env.getModuleIdxFor? `Poincare.HamiltonScalarGradientHessianBound.hessian_gradient_square_completion | throwError "missing module index"
  let allowed : List Name := [`propext, `Classical.choice, `Quot.sound]
  let mut count := 0
  for (name, info) in env.constants.toList do
    if env.getModuleIdxFor? name == some moduleIndex then
      if info.isUnsafe || info.isPartial then
        throwError "unsafe or partial declaration {name}"
      let footprint ← collectAxioms name
      for dependency in footprint do
        unless allowed.contains dependency do
          throwError "forbidden dependency {dependency} in {name}"
      logInfo m!"MODULE_AXIOMS_OK: {name}: {footprint}"
      count := count + 1
  logInfo m!"MODULE_DECLARATIONS_CHECKED: {count}"
