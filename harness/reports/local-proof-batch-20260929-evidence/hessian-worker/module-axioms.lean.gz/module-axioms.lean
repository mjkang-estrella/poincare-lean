import Lean
import Poincare.Global.HamiltonScalarGradientHessianBound
open Lean Elab Command
run_cmd do
  let env := (← getEnv).setExporting false
  let allowed : List Name := [`propext, `Classical.choice, `Quot.sound]
  let mut count := 0
  for (name, info) in env.constants.toList do
    if name.toString.startsWith "Poincare.HamiltonScalarGradientHessianBound." then
      if info.isUnsafe || info.isPartial then
        throwError "unsafe or partial declaration {name}"
      let footprint ← collectAxioms name
      for dependency in footprint do
        unless allowed.contains dependency do
          throwError "forbidden dependency {dependency} in {name}"
      logInfo "MODULE_AXIOMS_OK: {name}: {footprint}"
      count := count + 1
  logInfo "MODULE_DECLARATIONS_CHECKED: {count}"
