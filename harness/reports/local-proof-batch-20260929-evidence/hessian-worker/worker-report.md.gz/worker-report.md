# Worker result: quotient Hessian square

Status: compiled, committed, awaiting independent root acceptance.
Base: `f9f59cd2659b9cb2c9c89924970b7eb9211c0b61`. Proof commit: `a57f0b3e9fe02d0a7becc4234154b96db4d58ce3`.
Scope: only `Poincare/Global/HamiltonScalarGradientHessianBound.lean`, 170 new lines.
No root import, frozen source, contract, task status, service or other worktree was changed.

The exact reviewed declaration
`Poincare.HamiltonScalarGradientHessianBound.hessian_gradient_square_completion`
holds for arbitrary real a and locally C2 f. The intrinsic trace is changed to
a genuine metric-orthogonal basis. Positivity of the squared rank-one difference
and reconstruction of its mixed and rank-one terms give the estimate. Metric
compatibility of the canonical connection identifies the derivative of |grad f|².
No flow, compactness, curvature positivity, Hessian-symmetry, or square-completion
hypothesis was added. This closes one geometric estimate and does not prove the
full quotient evolution or final Poincare declaration.

Four public theorem-shaped declarations are provided: metric-trace positivity,
linear-map rank-one square completion, the gradient-norm derivative identity,
and the frozen geometric target. The module-index scan includes all 14 emitted
declarations: six proof constants have exactly propext, Classical.choice and
Quot.sound; eight internal syntax declarations have empty footprints.

Passed checks:
- Fresh source compile (compile-02.log; no diagnostics).
- Frozen exact-type and axiom contract, including targeted Lake build (contract-01.log).
- Internal-inclusive module-index allowed-axiom scan (module-index-axioms.log).
- Forbidden-token check and both ordinary and staged diff checks.

The first source compiler attempt is preserved in compile-01.log. It found
basis-coordinate reconstruction rewrites, bilinear evaluation simplifications,
and continuous-linear-map coercion details, all repaired in the accepted source.
The first prefix-only axiom probe had literal log labels; its guard still ran.
The corrected prefix probe and final module-index probe are retained separately.
No full build or root audit was run by this worker.

The source-only final.diff is the complete committed patch. All compiler logs,
probe source, command/exit/timing records and task snapshot remain append-only.
This is a Codex helper result, not a registered Pi or Leanstral runtime Job.
