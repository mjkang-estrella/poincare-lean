import Poincare.Global.HamiltonScalarGradientMixedBound
open Lean Elab Command in
run_cmd do
  let env := (← getEnv).setExporting false
  let some idx := env.getModuleIdx? `Poincare.Global.HamiltonScalarGradientMixedBound |
    throwError "module not found"
  let mut bad : Array String := #[]
  let mut count := 0
  for (n, _) in env.constants.map₁.toList do
    if env.getModuleIdxFor? n == some idx then
      let axs ← liftCoreM (collectAxioms n)
      count := count + 1
      logInfo m!"MODULE_AXIOMS {n}: {axs}"
      for a in axs do
        if a != ``propext && a != ``Classical.choice && a != ``Quot.sound then
          bad := bad.push s!"{n} uses {a}"
  logInfo m!"GATE_SCAN declarations={count} nonstandard={bad}"
  unless bad.isEmpty do
    throwError "nonstandard module axioms: {bad}"
