import Poincare.Global.FiniteAtlasParabolicTensorSpace
#check Poincare.FiniteAtlasParabolicTensorSpace.change_chart
#print axioms Poincare.FiniteAtlasParabolicTensorSpace.change_chart
#check Poincare.FiniteAtlasParabolicTensorSpace.change_cocycle
#print axioms Poincare.FiniteAtlasParabolicTensorSpace.change_cocycle
#check Poincare.FiniteAtlasParabolicTensorSpace.partition_zero_of_not_source
#print axioms Poincare.FiniteAtlasParabolicTensorSpace.partition_zero_of_not_source
#check Poincare.FiniteAtlasParabolicTensorSpace.sum_partition
#print axioms Poincare.FiniteAtlasParabolicTensorSpace.sum_partition
#check Poincare.FiniteAtlasParabolicTensorSpace.localized_transport_eq
#print axioms Poincare.FiniteAtlasParabolicTensorSpace.localized_transport_eq
#check Poincare.FiniteAtlasParabolicTensorSpace.sum_localized_transport
#print axioms Poincare.FiniteAtlasParabolicTensorSpace.sum_localized_transport
#check Poincare.FiniteAtlasParabolicTensorSpace.sum_reweighted_localized_transport
#print axioms Poincare.FiniteAtlasParabolicTensorSpace.sum_reweighted_localized_transport
#check Poincare.FiniteAtlasParabolicTensorSpace.sum_partition_sq_lt_one
#print axioms Poincare.FiniteAtlasParabolicTensorSpace.sum_partition_sq_lt_one
#check Poincare.FiniteAtlasParabolicTensorSpace.reweighted_transport_ne_entry
#print axioms Poincare.FiniteAtlasParabolicTensorSpace.reweighted_transport_ne_entry
#check Poincare.FiniteAtlasParabolicTensorSpace.unweighted_transport_not_mem
#print axioms Poincare.FiniteAtlasParabolicTensorSpace.unweighted_transport_not_mem

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let some idx := env.getModuleIdx? `Poincare.Global.FiniteAtlasParabolicTensorSpace
    | throwError "module not found"
  let mut bad : Array String := #[]
  let mut count := 0
  for (n, _) in env.constants.map₁.toList do
    if env.getModuleIdxFor? n == some idx then
      let axs ← liftCoreM (collectAxioms n)
      count := count + 1
      logInfo m!"EMITTED_DECL {n}: {axs}"
      if axs.size != 3 || !axs.contains ``propext || !axs.contains ``Classical.choice || !axs.contains ``Quot.sound then
        bad := bad.push s!"{n}: {axs}"
  logInfo m!"EXACT_EMITTED_SCAN declarations={count} bad={bad}"
  unless bad.isEmpty do throwError "unexpected dependency set"
