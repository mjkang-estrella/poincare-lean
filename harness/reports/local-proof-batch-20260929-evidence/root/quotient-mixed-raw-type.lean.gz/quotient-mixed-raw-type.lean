import Poincare.Global.HamiltonScalarGradientEstimate
universe u
#check (∀ {M : Type u} [TopologicalSpace M] [T2Space M] [ChartedSpace (Poincare.ClosedSmoothModel 3) M] [IsManifold (Poincare.closedSmoothModelWithCorners 3) ∞ M], ∀ (g : Poincare.ClosedSmoothRiemannianMetric 3 M) [CovariantDerivative.ContMDiffCovariantDerivative g.leviCivita 1] (x : M), 2 * g.scalarAt x * g.inner x (g.gradientAt (fun y ↦ g.scalarAt y) x) (g.gradientAt (fun y ↦ g.ricciNormSqAt y) x) ≤ 4 * g.scalarAt x ^ 2 * Poincare.covRicciNormSqAt g x + g.scalarGradNormSqAt x * g.ricciNormSqAt x : Prop)
