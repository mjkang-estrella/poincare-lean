import Lean
import Poincare.Global.HamiltonScalarGradientQuotientBound
open Lean Elab Command Meta
set_option autoImplicit false
run_cmd do
  let name := "Poincare.HamiltonScalarGradientQuotientBound.quotient_reaction_le_eight_of_square_completions".toName
  let _ ← getConstInfo name
  let environment := (← getEnv).setExporting false
  let mut pending : List Name := [name]
  let mut seen : NameSet := {}
  while !pending.isEmpty do
    let current := pending.head!
    pending := pending.tail!
    if !seen.contains current then
      seen := seen.insert current
      let some info := environment.find? current |
        throwError "missing dependency {current} in {name}"
      if info.isUnsafe || info.isPartial then
        throwError "unsafe or partial declaration {current} in {name}"
      pending := info.getUsedConstantsAsSet.toList ++ pending
      match info with
      | .recInfo value =>
        for rule in value.rules do
          pending := rule.rhs.getUsedConstants.toList ++ pending
      | .inductInfo value => pending := value.ctors ++ pending
      | _ => pure ()
  let allowed : List Name := ["propext".toName, "Classical.choice".toName, "Quot.sound".toName]
  let footprint ← collectAxioms name
  for dependency in footprint do
    unless allowed.contains dependency do
      throwError "forbidden axiom {dependency} in {name}"
  logInfo "AXIOM_CONTRACT_OK: Poincare.HamiltonScalarGradientQuotientBound.quotient_reaction_le_eight_of_square_completions"
run_cmd liftTermElabM do
  let info ← getConstInfo "Poincare.HamiltonScalarGradientQuotientBound.quotient_reaction_le_eight_of_square_completions".toName
  let levels : List Level := []
  unless info.levelParams.length == levels.length do
    throwError "frozen universe arity mismatch for {info.name}"
  let parsedType ← match Parser.runParserCategory (← getEnv) `term "∀ {R S H P N A G r Q : ℝ}, 0 < R → 2 * R * P ≤ 4 * R ^ 2 * A + S * N → 0 ≤ R ^ 2 * H - R * G + S ^ 2 → -2 * H / R + 4 * P / R - 2 * S * N / R ^ 2 + 2 * G / R ^ 2 - 2 * S ^ 2 / R ^ 3 - (4 / 3 : ℝ) * r * Q ≤ 8 * A - (4 / 3 : ℝ) * r * Q" with
    | .ok parsedType => pure parsedType
    | .error error => throwError error
  let expected ← Term.elabType parsedType
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then
    throwError "unresolved metavariables in frozen type for {info.name}"
  let actual := info.type.instantiateLevelParams info.levelParams levels
  unless ← isDefEq actual expected do
    throwError "frozen type mismatch for {info.name}: actual {actual}, expected {expected}"
  logInfo "FROZEN_CONTRACT_OK: Poincare.HamiltonScalarGradientQuotientBound.quotient_reaction_le_eight_of_square_completions"
