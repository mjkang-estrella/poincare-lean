# Independent recovered atlas verification

Date: 2026-09-29. This is a Codex orchestrator helper verification report, not a registered Leanstral/Pi Job and not an acceptance or merge.

Base: `2da86427638e6dbaa0288bc16af004f4eefec840`. Recovered proof HEAD: `8d45c1343724ffd01571ce6cf9290b8c4b2223ec`.
Worktree: `/Users/mjkang/.codex/worktrees/recover-finite-atlas/poincare`. Branch: `codex/recover-finite-atlas-20260929`.

The only base-relative tracked diff is 143 append-only lines in `Poincare/Global/FiniteAtlasParabolicTensorSpace.lean`. The original module is a byte-identical prefix. Tracked worktree remains clean after verification.

## Actual verification

| Check | Exit | Elapsed seconds |
|---|---:|---:|
| fresh-source | 0 | 15.014 |
| forbidden-scan | 1 | 0.006 |
| diff-check | 0 | 0.014 |
| targeted-build | 0 | 9.737 |
| declarations-and-axioms | 0 | 2.65 |

The forbidden scan includes `opaque` in addition to the required tokens. Exit 1 means no matches. Base-relative whitespace check is clean. The targeted module build completed successfully (3,223 dependency/artifact jobs), with one changed-module build entry. Replayed dependency linter warnings are preserved in the full build log; the fresh changed-file source compilation produced no output.

Explicit `#check` and `#print axioms` passed for all ten recovered names. A module-index scan includes internal and generated declarations and found 130 declarations, each with exactly `propext`, `Classical.choice`, and `Quot.sound`, and no other dependencies.

## Verified names

- `Poincare.FiniteAtlasParabolicTensorSpace.change_chart`
- `Poincare.FiniteAtlasParabolicTensorSpace.change_cocycle`
- `Poincare.FiniteAtlasParabolicTensorSpace.partition_zero_of_not_source`
- `Poincare.FiniteAtlasParabolicTensorSpace.sum_partition`
- `Poincare.FiniteAtlasParabolicTensorSpace.localized_transport_eq`
- `Poincare.FiniteAtlasParabolicTensorSpace.sum_localized_transport`
- `Poincare.FiniteAtlasParabolicTensorSpace.sum_reweighted_localized_transport`
- `Poincare.FiniteAtlasParabolicTensorSpace.sum_partition_sq_lt_one`
- `Poincare.FiniteAtlasParabolicTensorSpace.reweighted_transport_ne_entry`
- `Poincare.FiniteAtlasParabolicTensorSpace.unweighted_transport_not_mem`

## Mathematical scope

The recovered results prove actual-source coordinate substitution/cocycles, partition localization and value reconstruction, and conditional obstructions to weighting stored entries twice or using ordinary unweighted transport in this weighted carrier. These use the current actual atlas, Jacobian and carrier definitions. They do not construct a bounded nonlinear graph pullback, a bounded tensor push-forward, or a global parametrix.

The historical task remains blocked in its literal form: its C² sup bounds do not control the Hessian Hölder term, its ordinary transported families omit destination partition weights, and its proposed extraction multiplies already weighted stored entries again. No frozen task statement was changed. No root build, root audit, final theorem probe, Task acceptance, merge or commit was performed by this verifier.

Next action for the orchestrator: review the append-only diff and integrate these independently verified prerequisite/obstruction lemmas if appropriate, then run the root integration checkpoint serially.
