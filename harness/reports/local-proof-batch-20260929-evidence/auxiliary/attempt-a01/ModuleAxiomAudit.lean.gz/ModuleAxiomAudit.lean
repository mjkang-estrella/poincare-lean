import Poincare.Global.HamiltonScalarGradientAuxiliaryEstimate
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let some idx := env.getModuleIdx? `Poincare.Global.HamiltonScalarGradientAuxiliaryEstimate
    | throwError "module missing"
  let allowed := [``propext, ``Classical.choice, ``Quot.sound]
  let mut checked := 0
  for (n, _) in env.constants.map₁.toList do
    if env.getModuleIdxFor? n == some idx then
      let axs ← liftCoreM (collectAxioms n)
      if axs.any (fun ax => !allowed.contains ax) then
        throwError "forbidden axiom dependency in {n}: {axs}"
      logInfo m!"{n}: {axs}"
      checked := checked + 1
  if checked == 0 then
    throwError "empty module inventory"
  logInfo m!"PASS: {checked} module declarations, including internal declarations"
