# Hamilton auxiliary estimate: worker gate passed

Date: 2026-09-29T21:17:33.606897+00:00
Base: `3fbec21aecc78d1161e5cc18230b78d8c6ad75c7`
Branch: `codex/proof-hamilton-auxiliary-a01`
Sealed proof commit: `67635cce171f00d50bcbc35c58156fc9795f0f29`
Kind: Codex orchestrator helper, not a registered Pi/Leanstral runtime Job.
Status: Passed worker gates; independent acceptance and integration belong to the root orchestrator.

## Result

The exact frozen declaration
`Poincare.HamiltonScalarGradientAuxiliaryEstimate.auxiliary_evolution_le_cubic_of_normalizedFlow`
is proved. For the supplied normalized flow, joint C5 metric entries,
positive scalar slice, local pinching quotient at most one and eta >= 0,
it bounds the actual heat operator of F=S/R-eta R^2+(84+60eta)U with
+(4/3)meanScalar*F retained on the left.

The proof constructs time differentiability of S/R, R^2 and U from the
existing actual evolution producers. It reconstructs spatial C2 regularity
and proves Laplacian linearity for their weighted combination. It then
uses the geometric quotient-eight theorem, Bianchi S <= (20/7)A,
traceless derivative damping -(2/21)A and the local cubic bound T <= 4RU.
The choice K=84+60eta cancels the A contribution including +2eta S.
The scalar trace inequality R^2 <= 3N yields the negative scalar cubic term.
No derivative bounds are supplied as hypotheses.

## Actual verification

- Both scoped source compilation attempts exited 0; attempt 1 contained one
  unused-tactic warning which was removed in attempt 2.
- The frozen contract command exited 0, including a targeted Lake build
  (3,582 jobs, one newly built auxiliary module) and rigid exact type/axiom probes.
- The module-index axiom audit covered both emitted declarations, including
  internal declarations by the same criterion. Both have exactly propext,
  Classical.choice and Quot.sound.
- Forbidden-token scan, unstaged and staged whitespace checks exited 0.

Raw compiler output, source snapshots, acceptance commands/results,
module-index audit source/output and final base-relative diff are retained
beside this report. No blocker remains for this Task. This differential
estimate does not construct a flow, a uniform maximum bound, a convergence
producer or the reserved final Poincare declaration. Root imports, Task
acceptance, main and services were not modified by this helper.
