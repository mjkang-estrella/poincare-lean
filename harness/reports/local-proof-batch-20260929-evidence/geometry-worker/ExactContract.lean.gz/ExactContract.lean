import Lean
import Poincare.Global.HamiltonScalarGradientQuotientBound
open Lean Elab Command Meta
set_option autoImplicit false
run_cmd do
  let name := "Poincare.HamiltonScalarGradientQuotientBound.quotient_evolution_le_eight_covRicci".toName
  let _ ← getConstInfo name
  let environment := (← getEnv).setExporting false
  let mut pending : List Name := [name]
  let mut seen : NameSet := {}
  while !pending.isEmpty do
    let current := pending.head!
    pending := pending.tail!
    if !seen.contains current then
      seen := seen.insert current
      let some info := environment.find? current |
        throwError "missing dependency {current} in {name}"
      if info.isUnsafe || info.isPartial then
        throwError "unsafe or partial declaration {current} in {name}"
      pending := info.getUsedConstantsAsSet.toList ++ pending
      match info with
      | .recInfo value =>
        for rule in value.rules do
          pending := rule.rhs.getUsedConstants.toList ++ pending
      | .inductInfo value => pending := value.ctors ++ pending
      | _ => pure ()
  let allowed : List Name := ["propext".toName, "Classical.choice".toName, "Quot.sound".toName]
  let footprint ← collectAxioms name
  for dependency in footprint do
    unless allowed.contains dependency do
      throwError "forbidden axiom {dependency} in {name}"
  logInfo "AXIOM_CONTRACT_OK: Poincare.HamiltonScalarGradientQuotientBound.quotient_evolution_le_eight_covRicci"
universe u
run_cmd liftTermElabM do
  let info ← getConstInfo "Poincare.HamiltonScalarGradientQuotientBound.quotient_evolution_le_eight_covRicci".toName
  let levels : List Level := [Level.param "u".toName]
  unless info.levelParams.length == levels.length do
    throwError "frozen universe arity mismatch for {info.name}"
  let parsedType ← match Parser.runParserCategory (← getEnv) `term "∀ {M : Type u} [TopologicalSpace M] [T2Space M] [ChartedSpace (Poincare.ClosedSmoothModel 3) M] [IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M] [CompactSpace M] [ConnectedSpace M] [MeasurableSpace M] [BorelSpace M] [SecondCountableTopology M] {gt : ℝ → Poincare.ClosedSmoothRiemannianMetric 3 M} {t : ℝ} (x : M), (∀ s y, Poincare.MetricEntriesJointContDiffAt gt s y 5) → (∀ y, Poincare.IsClosedNormalizedRicciFlowSolutionAt gt t y) → (∀ y, 0 < (gt t).scalarAt y) → deriv (fun s ↦ (gt s).scalarGradNormSqAt x / (gt s).scalarAt x) t - (gt t).laplacianAt (fun y ↦ (gt t).scalarGradNormSqAt y / (gt t).scalarAt y) x ≤ 8 * Poincare.covRicciNormSqAt (gt t) x - (4/3 : ℝ) * Poincare.meanScalar (gt t) * ((gt t).scalarGradNormSqAt x / (gt t).scalarAt x)" with
    | .ok parsedType => pure parsedType
    | .error error => throwError error
  let expected ← Term.elabType parsedType
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then
    throwError "unresolved metavariables in frozen type for {info.name}"
  let actual := info.type.instantiateLevelParams info.levelParams levels
  unless ← isDefEq actual expected do
    throwError "frozen type mismatch for {info.name}: actual {actual}, expected {expected}"
  logInfo "FROZEN_CONTRACT_OK: Poincare.HamiltonScalarGradientQuotientBound.quotient_evolution_le_eight_covRicci"
