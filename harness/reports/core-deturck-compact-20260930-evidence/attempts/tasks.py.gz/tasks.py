import json,hashlib,subprocess
from pathlib import Path
from harness.v2.runtime.validation import validate_task,validate_statement_contract,validate_statement_readback
r=Path.cwd();folder=r/'harness/v2/contracts/core-deturck-compact-20260930';state=r/'harness/v2/state/core-deturck-compact-20260930'
mods={'extension':'DeTurckCompactCoefficientExtension','forcing':'DeTurckCoupledForcing','jet':'DeTurckTensorGraphJet'}
import sys
selected=sys.argv[1:] or ['extension','forcing']
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for slug in selected:
 mod=mods[slug]
 p=folder/f'{slug}.contract.json';m=json.loads(p.read_text());c=m['statement_contract'];raw=(r/c['review']['report_path']).read_bytes();readback=json.loads(raw);c['review'].update(verdict=readback['verdict'],report_sha256=hashlib.sha256(raw).hexdigest());validate_statement_contract(c);validate_statement_readback(c,raw)
 p.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
 t=json.loads((r/'harness/v2/tasks/core-input-20260930-coeff-actual.json').read_text());t.pop('accepted_commit',None);t['id']='core-input-20260930-compact-'+slug;t['status']='ready';t['base_commit']=base
 t['objective']={'title':'Construct actual compact coefficients and coupled forcing: '+slug,'statement':'Core assumption helped: UniversalHamiltonConvergenceStatement through genuine physical Ricci-flow construction. Subsequent consumer: actual global L=dt-DQ(g0), differentiated covariance and signed L/P/R contraction. Construct actual inputs; preserve both universal cores and frozen final target. Extension produces eta and actual Y carriers with common bounds before T; forcing consumes those exact actual arrays and constructs the nine-input bounded CLM with full actual action and two time powers. No flow/limit/coefficient-bound package or recognition premise may bypass construction.','deliverables':[x['name'] for x in c['declarations']]}
 t['scope']['allowed_paths']=['Poincare/Global/'+mod+'.lean'];t['scope']['forbidden_paths']+=['Poincare/Global/DeTurckCompactCoefficientDefinitions.lean','Poincare/Global/DeTurckCoupledForcingDefinitions.lean']
 common=['README.md','HANDOFF.md','docs/PROJECT_MAP.md','AGENTS.md','harness/v2/SPEC.md',c['review']['report_path'],'harness/v2/contracts/core-deturck-compact-20260930/context.md','harness/reports/core-deturck-coefficients-20260930.md','Poincare/Global/DeTurckCompactCoefficientDefinitions.lean','Poincare/Global/DeTurckCoupledForcingDefinitions.lean','Poincare/Global/DeTurckActualSpatialCoefficients.lean','Poincare/Global/DeTurckTensorBasisReconstruction.lean','Poincare/Global/ParabolicCutoffCommutator.lean','Poincare/Global/ParabolicSolutionGraph.lean']
 if slug=='jet':common+=['harness/v2/contracts/core-deturck-compact-20260930/jet-context.md']
 if slug=='extension':common+=['Poincare/Global/BufferedFrozenParabolicSolver.lean','Poincare/Global/ClosedLaplacianStokesGlobalCoefficients.lean','Poincare/Global/MetricAdaptedLocalParametrix.lean']
 if slug=='jet':t['objective']['statement']='Core helped: UniversalHamiltonConvergenceStatement. Subsequent consumer: actual coupled lower forcing Z(h)+F(Dh) and true L=dt-DQ(g0). Identify the reconstructed tensorJet as the ordinary spatial derivative of the same tensorValue from actual Graph certificates, with no new alpha/time/symmetry/support/norm premise.'
 t['context']={'files':common,'symbols':t['objective']['deliverables'],'depends_on':[]}
 t['acceptance']['commands'][0][-1]=t['scope']['allowed_paths'][0];t['acceptance']['commands'][1][-1]=t['scope']['allowed_paths'][0];t['acceptance']['commands'][3][-1]=str(p.relative_to(r));t['acceptance']['required_declarations']=t['objective']['deliverables'];t['statement_contract']=c
 validate_task(t);(r/f"harness/v2/tasks/{t['id']}.json").write_text(json.dumps(t,ensure_ascii=False,indent=2)+'\n')
 print(t['id'],base)
