import Poincare.Global.DeTurckCoupledForcingDefinitions

noncomputable section
set_option autoImplicit false
open scoped BigOperators

namespace Poincare.DeTurckCoupledForcingAdvice
open DeTurckPrincipalSecondJet DeTurckTensorBasis DeTurckCoupledForcing

local instance : NormedAddCommGroup Jet1 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance : NormedSpace ℝ Jet1 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

theorem smulRight_expansion (f : E →L[ℝ] ℝ) (a b : Fin 3) :
    f.smulRight (tensor a b) =
      ∑ p : Fin 3, f (basis3 p) • firstJet p a b := by
  ext r v w
  have hr : (∑ p : Fin 3, r p • basis3 p) = r :=
    (EuclideanSpace.basisFun (Fin 3) ℝ).sum_repr r
  calc
    f r * tensor a b v w =
      f (∑ p : Fin 3, r p • basis3 p) * tensor a b v w := by rw [hr]
    _ = _ := by
      simp only [map_sum, map_smul, ContinuousLinearMap.sum_apply,
        ContinuousLinearMap.smul_apply, smul_eq_mul, Finset.sum_mul,
        firstJet, ContinuousLinearMap.smulRight_apply]
      apply Finset.sum_congr rfl
      intro p _
      change r p * f (basis3 p) * tensor a b v w =
        f (basis3 p) * (r p * tensor a b v w)
      ring

theorem tensorJet_expansion {α T : ℝ} (W : Inputs α T) (q : ℝ × E) :
    tensorJet W q = ∑ a : Fin 3, ∑ b : Fin 3, ∑ p : Fin 3,
      (W (a,b)).du q (basis3 p) • firstJet p a b := by
  unfold tensorJet
  apply Finset.sum_congr rfl
  intro a _
  apply Finset.sum_congr rfl
  intro b _
  exact smulRight_expansion _ a b

theorem action {α T : ℝ} (c0 : Coeff0 α T) (c1 : Coeff1 α T)
    (W : Inputs α T) (q : ℝ × E) (η : ℝ)
    (L0 : Bilin →L[ℝ] Bilin) (L1 : Jet1 →L[ℝ] Bilin) (c d : Fin 3)
    (h0 : ∀ a b, c0 a b q = η *
      DeTurckInverseEntryDerivative.entryCLM c d (L0 (tensor a b)))
    (h1 : ∀ p a b, c1 p a b q = η *
      DeTurckInverseEntryDerivative.entryCLM c d (L1 (firstJet p a b))) :
    value c0 c1 W q = η * DeTurckInverseEntryDerivative.entryCLM c d
      (L0 (tensorValue W q) + L1 (tensorJet W q)) := by
  rw [tensorJet_expansion]
  simp only [value, tensorValue, map_add, map_sum, map_smul, smul_eq_mul]
  simp_rw [h0, h1, mul_add, Finset.mul_sum, Finset.sum_add_distrib]
  congr 1
  · apply Finset.sum_congr rfl
    intro a _
    apply Finset.sum_congr rfl
    intro b _
    ring
  · apply Finset.sum_congr rfl
    intro a _
    apply Finset.sum_congr rfl
    intro b _
    apply Finset.sum_congr rfl
    intro p _
    ring

end Poincare.DeTurckCoupledForcingAdvice

