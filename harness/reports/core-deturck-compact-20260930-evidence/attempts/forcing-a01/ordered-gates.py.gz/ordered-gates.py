from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path("/Users/mjkang/.codex/worktrees/core-coupled-forcing/poincare")
evidence=Path("/Users/mjkang/.codex/worktrees/incremental-verification/poincare/harness/v2/state/core-deturck-compact-20260930/forcing-a01")
task=json.loads((evidence/"task.snapshot.json").read_text())
folder=evidence/"ordered-gates-01"
folder.mkdir()
source=root/"Poincare/Global/DeTurckCoupledForcing.lean"
(folder/"source.lean").write_bytes(source.read_bytes())
(folder/"diff.patch").write_bytes(subprocess.check_output(["git","diff","--","Poincare/Global/DeTurckCoupledForcing.lean"],cwd=root))
results=[]
for n,cmd in enumerate(task["acceptance"]["commands"],1):
 start=time.time()
 with (folder/f"gate-{n}.log").open("w") as log:
  result=subprocess.run(cmd,cwd=root,env=dict(os.environ,LEAN_NUM_THREADS="1"),stdout=log,stderr=subprocess.STDOUT)
 receipt={"command":cmd,"exit_code":result.returncode,"elapsed_seconds":time.time()-start,"source_sha256":hashlib.sha256(source.read_bytes()).hexdigest()}
 (folder/f"gate-{n}.json").write_text(json.dumps(receipt,indent=2)+"\n")
 results.append(receipt)
 print(json.dumps(receipt),flush=True)
 print((folder/f"gate-{n}.log").read_text()[-10000:],flush=True)
 if result.returncode:
  sys.exit(result.returncode)
(folder/"result.json").write_text(json.dumps({"status":"all-four-gates-passed","gates":results},indent=2)+"\n")
