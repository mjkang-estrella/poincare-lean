import Poincare.Global.DeTurckCoupledForcingDefinitions

noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 100
open scoped BigOperators Manifold

universe u
namespace Poincare.DeTurckCoupledForcing
open DeTurckPrincipalSecondJet

local instance : NormedAddCommGroup Jet1 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance : NormedSpace ℝ Jet1 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

variable {α T : ℝ}

/-- Sum the actual scalar graph actions over every ordered input tensor slot. -/
private def coupledLinearMap (c0 : Coeff0 α T) (c1 : Coeff1 α T) :
    Inputs α T →ₗ[ℝ] ParabolicHolder.Y (E := E) α T ℝ :=
  ∑ a : Fin 3, ∑ b : Fin 3,
    (ParabolicCutoffCommutator.firstOrderLinearMap
      (fun p => c1 p a b) (c0 a b)).comp (LinearMap.proj (a,b))

private theorem coupledLinearMap_apply (c0 : Coeff0 α T) (c1 : Coeff1 α T)
    (W : Inputs α T) (q : ℝ × E) :
    coupledLinearMap c0 c1 W q = value c0 c1 W q := by
  simp only [coupledLinearMap, LinearMap.sum_apply, LinearMap.comp_apply,
    LinearMap.proj_apply, ParabolicHolderMultiplier.sum_apply,
    ParabolicCutoffCommutator.firstOrderLinearMap,
    LinearMap.coe_mk, AddHom.coe_mk,
    ParabolicCutoffCommutator.firstOrderForcing_apply, value]
  apply Finset.sum_congr rfl
  intro a _
  apply Finset.sum_congr rfl
  intro b _
  exact add_comm _ _

/-- The original Pi maximum controls each original Graph norm. -/
private theorem coupledLinearMap_bound (c0 : Coeff0 α T) (c1 : Coeff1 α T)
    (hα : 0 < α) (hα1 : α < 1) (hT : 0 < T) (hT1 : T ≤ 1)
    (W : Inputs α T) :
    ‖coupledLinearMap c0 c1 W‖ ≤ timeBound c0 c1 * ‖W‖ := by
  change ‖∑ a : Fin 3, ∑ b : Fin 3,
    ParabolicCutoffCommutator.firstOrderForcing
      (fun p => c1 p a b) (c0 a b) (W (a,b))‖ ≤ _
  calc
    _ ≤ ∑ a : Fin 3, ‖∑ b : Fin 3,
        ParabolicCutoffCommutator.firstOrderForcing
          (fun p => c1 p a b) (c0 a b) (W (a,b))‖ := norm_sum_le _ _
    _ ≤ ∑ a : Fin 3, ∑ b : Fin 3,
        ‖ParabolicCutoffCommutator.firstOrderForcing
          (fun p => c1 p a b) (c0 a b) (W (a,b))‖ := by
      apply Finset.sum_le_sum
      intro a _
      exact norm_sum_le _ _
    _ ≤ ∑ a : Fin 3, ∑ b : Fin 3,
        24 * ((∑ p : Fin 3, ‖c1 p a b‖) * T ^ ((1 - α) / 2) +
          ‖c0 a b‖ * T ^ (1 - α / 2)) * ‖W‖ := by
      apply Finset.sum_le_sum
      intro a _
      apply Finset.sum_le_sum
      intro b _
      exact (ParabolicCutoffCommutator.firstOrder_time_bound
        (fun p => c1 p a b) (c0 a b) (W (a,b)) hα hα1 hT hT1).trans
          (mul_le_mul_of_nonneg_left (norm_le_pi_norm W (a,b)) (by positivity))
    _ = _ := by
      simp only [timeBound, mul_add, add_mul, Finset.sum_add_distrib,
        ← Finset.mul_sum, ← Finset.sum_mul]
      ring

end Poincare.DeTurckCoupledForcing
