from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path("/Users/mjkang/.codex/worktrees/core-coupled-forcing/poincare")
evidence=Path("/Users/mjkang/.codex/worktrees/incremental-verification/poincare/harness/v2/state/core-deturck-compact-20260930/forcing-a01")
label=sys.argv[1]
folder=evidence/label
folder.mkdir()
source=root/"Poincare/Global/DeTurckCoupledForcing.lean"
(folder/"source.lean").write_bytes(source.read_bytes())
cmd=["lake","env","lean","Poincare/Global/DeTurckCoupledForcing.lean"]
start=time.time()
with (folder/"compiler.log").open("w") as log:
 result=subprocess.run(cmd,cwd=root,env=dict(os.environ,LEAN_NUM_THREADS="1"),stdout=log,stderr=subprocess.STDOUT)
receipt={"command":cmd,"exit_code":result.returncode,"elapsed_seconds":time.time()-start,"source_sha256":hashlib.sha256(source.read_bytes()).hexdigest()}
(folder/"result.json").write_text(json.dumps(receipt,indent=2)+"\n")
print((folder/"compiler.log").read_text())
print(json.dumps(receipt))
sys.exit(result.returncode)
