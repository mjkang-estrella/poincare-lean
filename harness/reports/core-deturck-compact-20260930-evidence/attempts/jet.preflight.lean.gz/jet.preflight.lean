import Poincare.Global.DeTurckCoupledForcingDefinitions
import Lean
set_option maxHeartbeats 1000000
set_option synthInstance.maxHeartbeats 100000
universe u
open Lean Elab Command Term
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (α T : ℝ) (W : Poincare.DeTurckCoupledForcing.Inputs α T) (t : ℝ)\n(z : Poincare.DeTurckPrincipalSecondJet.E), t ∈ Set.Icc 0 T →\nHasFDerivAt (fun y : Poincare.DeTurckPrincipalSecondJet.E => Poincare.DeTurckCoupledForcing.tensorValue W (t,y))\n (Poincare.DeTurckCoupledForcing.tensorJet W (t,z)) z" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: jet"
