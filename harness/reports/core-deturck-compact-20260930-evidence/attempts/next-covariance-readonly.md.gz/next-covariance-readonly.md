Read-only atlas_target_review findings. CoreH; consumer true global L/P/R.

Existing DeTurckBUCChartCovariance.deTurckChartMetricEvolutionBilin_chartTransitionDeriv (line255) proves full nonlinear covariance for actual smooth metrics/families on true overlaps. No full linearized transformation law was found in the nearest jet/atlas sources.

First missing covariance shape: for phi=change A i j, actual g0/bg jets in both charts, symmetric C2 perturbation germ h_j and h_i(y)(v,w)=h_j(phi y)(Dphi(y)v,Dphi(y)w), prove DQ_i[g0]((h_i,Dh_i),D2h_i)(v,w)=DQ_j[g0]((h_j,Dh_j),D2h_j)(Dphi v,Dphi w) at a genuine overlap with both cutoff-one germs. Retain differentiated Jacobian weights through D3phi. Smooth coefficient fields and value compatibility alone do not imply this.

Possible route: compact smooth realization of each symmetric2jet, a small actual Riemannian metric variation using g0 positivity, differentiate the existing nonlinear covariance, transfer by derivative uniqueness/jet matching. Smooth-family covariance alone is insufficient for arbitrary Graph germs. Do not assume density in the unchanged full Holder norm.

Independent concrete localization obstacle: stored entries are chi_i*h_i. Full L_i(chi_i*h_i) differs from chi_i*Lh by principal mixed/Hessian cutoff terms AND firstOrder((Dchi_i).smulRight h_i), with the negative lower-action sign in L. This exact product identity is needed before identifying stored forcing and actual signed L/P/R residual.

No source edits or builds performed. These are unresolved theorem shapes/proposed routes, not completed covariance/localization proofs.
