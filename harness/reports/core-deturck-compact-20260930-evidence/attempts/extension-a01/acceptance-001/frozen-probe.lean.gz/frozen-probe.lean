import Lean
import Poincare.Global.DeTurckCompactCoefficientExtension
open Lean Elab Command Meta
set_option autoImplicit false
run_cmd do
  let name := "Poincare.DeTurckCompactCoefficients.exists_actual_compact_carriers".toName
  let _ ← getConstInfo name
  let environment := (← getEnv).setExporting false
  let mut pending : List Name := [name]
  let mut seen : NameSet := {}
  while !pending.isEmpty do
    let current := pending.head!
    pending := pending.tail!
    if !seen.contains current then
      seen := seen.insert current
      let some info := environment.find? current |
        throwError "missing dependency {current} in {name}"
      if info.isUnsafe || info.isPartial then
        throwError "unsafe or partial declaration {current} in {name}"
      pending := info.getUsedConstantsAsSet.toList ++ pending
      match info with
      | .recInfo value =>
        for rule in value.rules do
          pending := rule.rhs.getUsedConstants.toList ++ pending
      | .inductInfo value => pending := value.ctors ++ pending
      | _ => pure ()
  let allowed : List Name := ["propext".toName, "Classical.choice".toName, "Quot.sound".toName]
  let footprint ← collectAxioms name
  for dependency in footprint do
    unless allowed.contains dependency do
      throwError "forbidden axiom {dependency} in {name}"
  logInfo "AXIOM_CONTRACT_OK: Poincare.DeTurckCompactCoefficients.exists_actual_compact_carriers"
universe u
run_cmd liftTermElabM do
  let info ← getConstInfo "Poincare.DeTurckCompactCoefficients.exists_actual_compact_carriers".toName
  let levels : List Level := [Level.param "u".toName]
  unless info.levelParams.length == levels.length do
    throwError "frozen universe arity mismatch for {info.name}"
  let parsedType ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M] [T2Space M]\n[ChartedSpace Poincare.DeTurckPrincipalSecondJet.E M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(g0 bg : Poincare.ClosedSmoothRiemannianMetric 3 M) (anchor : M)\n(ξ : Poincare.DeTurckPrincipalSecondJet.E → ℝ) (α : ℝ), HasCompactSupport ξ → tsupport ξ ⊆ Poincare.DeTurckCompactCoefficients.zone anchor →\n0 < α → α < 1 →\n∃ η : Poincare.DeTurckPrincipalSecondJet.E → ℝ,\nContDiff ℝ ((⊤ : ENat) : WithTop ENat) η ∧ HasCompactSupport η ∧\ntsupport η ⊆ Poincare.DeTurckCompactCoefficients.zone anchor ∧\n(∀ z ∈ tsupport ξ, Filter.Eventually (fun y => η y = 1) (nhds z)) ∧\n(∀ z, η z ∈ Set.Icc 0 1) ∧\n(∀ a b c d : Fin 3,\n ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (fun z => η z * Poincare.DeTurckCompactCoefficients.raw0 g0 bg anchor a b c d z) ∧\n HasCompactSupport (fun z => η z * Poincare.DeTurckCompactCoefficients.raw0 g0 bg anchor a b c d z) ∧\n (∀ z ∈ tsupport ξ, Filter.Eventually (fun y => η y * Poincare.DeTurckCompactCoefficients.raw0 g0 bg anchor a b c d y = Poincare.DeTurckCompactCoefficients.raw0 g0 bg anchor a b c d y) (nhds z))) ∧\n(∀ p a b c d : Fin 3,\n ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (fun z => η z * Poincare.DeTurckCompactCoefficients.raw1 g0 bg anchor p a b c d z) ∧\n HasCompactSupport (fun z => η z * Poincare.DeTurckCompactCoefficients.raw1 g0 bg anchor p a b c d z) ∧\n (∀ z ∈ tsupport ξ, Filter.Eventually (fun y => η y * Poincare.DeTurckCompactCoefficients.raw1 g0 bg anchor p a b c d y = Poincare.DeTurckCompactCoefficients.raw1 g0 bg anchor p a b c d y) (nhds z))) ∧\n∃ C0 C1 : ℝ, 0 ≤ C0 ∧ 0 ≤ C1 ∧ ∀ T : ℝ,\n ∃ c0 : Fin 3 → Fin 3 → Fin 3 → Fin 3 → (Poincare.ParabolicHolder.Y (E := Poincare.DeTurckPrincipalSecondJet.E) α T ℝ),\n ∃ c1 : Fin 3 → Fin 3 → Fin 3 → Fin 3 → Fin 3 → (Poincare.ParabolicHolder.Y (E := Poincare.DeTurckPrincipalSecondJet.E) α T ℝ),\n (∀ a b c d : Fin 3, ∀ q ∈ Poincare.ParabolicHolder.cylinder T, c0 a b c d q = η q.2 * Poincare.DeTurckCompactCoefficients.raw0 g0 bg anchor a b c d q.2) ∧\n (∀ p a b c d : Fin 3, ∀ q ∈ Poincare.ParabolicHolder.cylinder T, c1 p a b c d q = η q.2 * Poincare.DeTurckCompactCoefficients.raw1 g0 bg anchor p a b c d q.2) ∧\n ∀ c d : Fin 3, (∑ a : Fin 3, ∑ b : Fin 3, ‖c0 a b c d‖) ≤ C0 ∧\n (∑ a : Fin 3, ∑ b : Fin 3, ∑ p : Fin 3, ‖c1 p a b c d‖) ≤ C1" with
    | .ok parsedType => pure parsedType
    | .error error => throwError error
  let expected ← Term.elabType parsedType
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then
    throwError "unresolved metavariables in frozen type for {info.name}"
  let actual := info.type.instantiateLevelParams info.levelParams levels
  unless ← isDefEq actual expected do
    throwError "frozen type mismatch for {info.name}: actual {actual}, expected {expected}"
  logInfo "FROZEN_CONTRACT_OK: Poincare.DeTurckCompactCoefficients.exists_actual_compact_carriers"
