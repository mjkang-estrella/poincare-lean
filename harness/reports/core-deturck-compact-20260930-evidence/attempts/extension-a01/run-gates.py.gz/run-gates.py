import json,os,subprocess,sys,time
from pathlib import Path
wt=Path("/Users/mjkang/.codex/worktrees/core-compact-extension/poincare")
store=Path("/Users/mjkang/.codex/worktrees/incremental-verification/poincare/harness/v2/state/core-deturck-compact-20260930/extension-a01")
label=sys.argv[1]
d=store/label
d.mkdir(exist_ok=False)
src=wt/"Poincare/Global/DeTurckCompactCoefficientExtension.lean"
(d/"source.lean").write_bytes(src.read_bytes())
(d/"final.diff").write_bytes(subprocess.check_output(["git","diff","--","Poincare/Global/DeTurckCompactCoefficientExtension.lean"],cwd=wt))
manifest="harness/v2/contracts/core-deturck-compact-20260930/extension.contract.json"
render=subprocess.run(["python3","scripts/frozen_contract_audit.py","--manifest",manifest,"--render"],cwd=wt,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(d/"frozen-probe.lean").write_bytes(render.stdout)
(d/"render.stderr").write_bytes(render.stderr)
(d/"render.exit.json").write_text(json.dumps({"exit_code":render.returncode},indent=2)+"\n")
commands=[
["env","LEAN_NUM_THREADS=1","lake","env","lean","Poincare/Global/DeTurckCompactCoefficientExtension.lean"],
["rg","--files-without-match",r"\b(sorry|admit|axiom|opaque|postulate)\b|native_decide","Poincare/Global/DeTurckCompactCoefficientExtension.lean"],
["git","diff","--check"],
["python3","scripts/frozen_contract_audit.py","--manifest",manifest]]
for i,cmd in enumerate(commands,1):
 start=time.time()
 with (d/f"gate-{i}.log").open("w") as f:
  r=subprocess.run(cmd,cwd=wt,env={**os.environ,"LEAN_NUM_THREADS":"1"},stdout=f,stderr=subprocess.STDOUT)
 (d/f"gate-{i}.exit.json").write_text(json.dumps({"cwd":str(wt),"argv":cmd,"exit_code":r.returncode,"elapsed_seconds":time.time()-start},indent=2)+"\n")
 print(f"gate {i} exit {r.returncode}",flush=True)
 print((d/f"gate-{i}.log").read_text(),flush=True)
 if r.returncode:sys.exit(r.returncode)
