import json,os,subprocess,sys,time
from pathlib import Path
wt=Path("/Users/mjkang/.codex/worktrees/core-compact-extension/poincare")
store=Path("/Users/mjkang/.codex/worktrees/incremental-verification/poincare/harness/v2/state/core-deturck-compact-20260930/extension-a01")
label=sys.argv[1]
d=store/label
d.mkdir(exist_ok=False)
src=wt/"Poincare/Global/DeTurckCompactCoefficientExtension.lean"
(d/"source.lean").write_bytes(src.read_bytes())
cmd=["lake","env","lean","Poincare/Global/DeTurckCompactCoefficientExtension.lean"]
start=time.time()
with (d/"compiler.log").open("w") as f:
 r=subprocess.run(cmd,cwd=wt,env={**os.environ,"LEAN_NUM_THREADS":"1"},stdout=f,stderr=subprocess.STDOUT)
(d/"exit.json").write_text(json.dumps({"command":cmd,"LEAN_NUM_THREADS":1,"exit_code":r.returncode,"elapsed_seconds":time.time()-start},indent=2)+"\n")
print((d/"compiler.log").read_text())
print("exit_code",r.returncode)
sys.exit(r.returncode)
