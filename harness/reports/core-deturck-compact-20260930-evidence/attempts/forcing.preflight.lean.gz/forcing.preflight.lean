import Poincare.Global.DeTurckCoupledForcingDefinitions
import Lean
set_option maxHeartbeats 1000000
set_option synthInstance.maxHeartbeats 100000
universe u
open Lean Elab Command Term
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M] [T2Space M]\n[ChartedSpace Poincare.DeTurckPrincipalSecondJet.E M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(g0 bg : Poincare.ClosedSmoothRiemannianMetric 3 M) (anchor : M)\n(η : Poincare.DeTurckPrincipalSecondJet.E → ℝ) (c d : Fin 3) (α T : ℝ)\n(c0 : Poincare.DeTurckCoupledForcing.Coeff0 α T) (c1 : Poincare.DeTurckCoupledForcing.Coeff1 α T),\n0 < α → α < 1 → 0 < T → T ≤ 1 →\n(∀ a b : Fin 3, ∀ q ∈ Poincare.ParabolicHolder.cylinder T, c0 a b q = η q.2 * Poincare.DeTurckCompactCoefficients.raw0 g0 bg anchor a b c d q.2) →\n(∀ p a b : Fin 3, ∀ q ∈ Poincare.ParabolicHolder.cylinder T, c1 p a b q = η q.2 * Poincare.DeTurckCompactCoefficients.raw1 g0 bg anchor p a b c d q.2) →\n∃ K : Poincare.DeTurckCoupledForcing.Inputs α T →L[ℝ] (Poincare.ParabolicHolder.Y (E := Poincare.DeTurckPrincipalSecondJet.E) α T ℝ),\n (∀ W q, (K W) q = Poincare.DeTurckCoupledForcing.value c0 c1 W q) ∧\n ‖K‖ ≤ Poincare.DeTurckCoupledForcing.timeBound c0 c1 ∧\n ∀ W q, q ∈ Poincare.ParabolicHolder.cylinder T →\n (K W) q = η q.2 * Poincare.DeTurckInverseEntryDerivative.entryCLM c d\n  (Poincare.DeTurckCompactCoefficients.field0 g0 bg anchor q.2 (Poincare.DeTurckCoupledForcing.tensorValue W q) +\n   Poincare.DeTurckCompactCoefficients.field1 g0 bg anchor q.2 (Poincare.DeTurckCoupledForcing.tensorJet W q))" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: forcing"
