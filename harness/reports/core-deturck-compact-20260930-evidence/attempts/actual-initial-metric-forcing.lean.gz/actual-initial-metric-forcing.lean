import Poincare.Global.DeTurckCompactCoefficientExtension
import Poincare.Global.DeTurckCoupledForcing
import Poincare.Global.DeTurckTensorGraphJet
import Poincare.Global.SmoothInitialMetricExistence
import Poincare.Global.MetricAdaptedLocalParametrix
noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 100
open Set Filter
open scoped Manifold ContDiff Topology BigOperators
universe u
namespace Poincare
open DeTurckPrincipalSecondJet DeTurckCompactCoefficients DeTurckCoupledForcing
local instance : NormedAddCommGroup Poincare.DeTurckPrincipalSecondJet.Jet1 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin)
    (σ₁₂ := RingHom.id ℝ)
local instance : NormedSpace ℝ Poincare.DeTurckPrincipalSecondJet.Jet1 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ)
local instance : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ)
local instance : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance : NormedAddCommGroup Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedAddCommGroup
 (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ)
local instance : NormedSpace ℝ Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedSpace
 (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.normedAddCommGroup
local instance : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.normedSpace
local instance : NormedAddCommGroup Poincare.DeTurckJetLinearization.Variables := Prod.normedAddCommGroup
local instance : NormedSpace ℝ Poincare.DeTurckJetLinearization.Variables := Prod.normedSpace
local instance : AddCommMonoid (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.instAddCommMonoid
local instance : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.Bilin →L[ℝ] Poincare.DeTurckPrincipalSecondJet.Bilin) := ContinuousLinearMap.toNormedAddCommGroup
 (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.Bilin) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ)
local instance : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.Bilin →L[ℝ] Poincare.DeTurckPrincipalSecondJet.Bilin) := ContinuousLinearMap.toNormedSpace
 (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.Bilin) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.Jet1 →L[ℝ] Poincare.DeTurckPrincipalSecondJet.Bilin) := ContinuousLinearMap.toNormedAddCommGroup
 (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.Jet1) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ)
local instance : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.Jet1 →L[ℝ] Poincare.DeTurckPrincipalSecondJet.Bilin) := ContinuousLinearMap.toNormedSpace
 (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.Jet1) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)


private theorem initial_metric_lower_forcing : ∀ (M : Type u) [TopologicalSpace M] [T2Space M] [CompactSpace M]
[ChartedSpace E M] [IsManifold (closedSmoothModelWithCorners 3) ∞ M]
(α : ℝ), 0 < α → α < 1 →
∃ g0 : ClosedSmoothRiemannianMetric 3 M,
∀ (anchor : M) (ξ : E → ℝ), HasCompactSupport ξ → tsupport ξ ⊆ zone anchor →
∃ (η : E → ℝ) (C0 C1 : ℝ), 0 ≤ C0 ∧ 0 ≤ C1 ∧
(∀ z ∈ tsupport ξ, ∀ᶠ y in nhds z, η y = 1) ∧
∀ T : ℝ, 0 < T → T ≤ 1 → ∀ c d : Fin 3,
∃ K : Inputs α T →L[ℝ] ParabolicHolder.Y (E := E) α T ℝ,
 ‖K‖ ≤ 24 * (C1 * T ^ ((1-α)/2) + C0 * T ^ (1-α/2)) ∧
 ∀ (W : Inputs α T) (t : ℝ), t ∈ Icc 0 T → ∀ z : E,
 (K W) (t,z) = η z * DeTurckInverseEntryDerivative.entryCLM c d
  (field0 g0 g0 anchor z (tensorValue W (t,z)) +
   field1 g0 g0 anchor z (fderiv ℝ (fun y : E => tensorValue W (t,y)) z)) := by
  intro M _ _ _ _ _ α hα hα1
  obtain ⟨g0⟩ := SmoothInitialMetricExistence.exists_initial_metric (M := M)
  refine ⟨g0, ?_⟩
  intro anchor ξ hcξ hξU
  obtain ⟨η, _hη, _hcη, _hηU, hηξ, _hη01, _h0, _h1,
    C0, C1, hC0, hC1, hcarriers⟩ :=
    exists_actual_compact_carriers M g0 g0 anchor ξ α hcξ hξU hα hα1
  refine ⟨η, C0, C1, hC0, hC1, hηξ, ?_⟩
  intro T hT hT1 c d
  obtain ⟨c0, c1, h0, h1, hbounds⟩ := hcarriers T
  obtain ⟨K, _hvalue, hK, hactual⟩ := exists_actual_coupled_forcing M g0 g0 anchor η c d α T
    (fun a b => c0 a b c d) (fun p a b => c1 p a b c d)
    hα hα1 hT hT1 (h0 · · c d) (h1 · · · c d)
  refine ⟨K, hK.trans ?_, ?_⟩
  · unfold timeBound
    exact mul_le_mul_of_nonneg_left
      (add_le_add
        (mul_le_mul_of_nonneg_right (hbounds c d).2 (Real.rpow_nonneg hT.le _))
        (mul_le_mul_of_nonneg_right (hbounds c d).1 (Real.rpow_nonneg hT.le _))) (by norm_num)
  · intro W t ht z
    have hjet := tensorJet_hasFDerivAt α T W t z ht
    simpa only [hjet.fderiv] using hactual W (t,z) ⟨ht, mem_univ z⟩

example : ∀ (M : Type u) [TopologicalSpace M] [T2Space M] [CompactSpace M]
[ChartedSpace E M] [IsManifold (closedSmoothModelWithCorners 3) ∞ M]
(α : ℝ), 0 < α → α < 1 →
∃ (g0 : ClosedSmoothRiemannianMetric 3 M)
  (A : FiniteAtlasParabolicTensorSpace.AtlasData M)
  (ψ ξ : Fin A.cover.chartCount → E → ℝ),
(∀ i, HasCompactSupport (ξ i) ∧ tsupport (ξ i) ⊆ zone (A.cover.anchor i)) ∧
∀ i : Fin A.cover.chartCount,
let anchor := A.cover.anchor i
let ξ := ξ i
∃ (η : E → ℝ) (C0 C1 : ℝ), 0 ≤ C0 ∧ 0 ≤ C1 ∧
(∀ z ∈ tsupport ξ, ∀ᶠ y in nhds z, η y = 1) ∧
∀ T : ℝ, 0 < T → T ≤ 1 → ∀ c d : Fin 3,
∃ K : Inputs α T →L[ℝ] ParabolicHolder.Y (E := E) α T ℝ,
 ‖K‖ ≤ 24 * (C1 * T ^ ((1-α)/2) + C0 * T ^ (1-α/2)) ∧
 ∀ (W : Inputs α T) (t : ℝ), t ∈ Icc 0 T → ∀ z : E,
 (K W) (t,z) = η z * DeTurckInverseEntryDerivative.entryCLM c d
  (field0 g0 g0 anchor z (tensorValue W (t,z)) +
   field1 g0 g0 anchor z (fderiv ℝ (fun y : E => tensorValue W (t,y)) z)) := by
  intro M _ _ _ _ _ α hα hα1
  obtain ⟨g0, hlower⟩ := initial_metric_lower_forcing M α hα hα1
  obtain ⟨A, ψ, ξ, hbuffer, _Cψ, _CP, _τ, _hCψ, _hCP, _hτ, _hτ1, _hoperators⟩ :=
    MetricAdaptedLocalParametrix.exists_metric_adapted_local_parametrix g0 α hα hα1
  have hξ (i : Fin A.cover.chartCount) : HasCompactSupport (ξ i) ∧
      tsupport (ξ i) ⊆ zone (A.cover.anchor i) := by
    rcases hbuffer i with ⟨_hψ, _hcψ, _hψone, _hψrange,
      _hξ, hcξ, _hξrange, _hξψ, htarget, houter⟩
    exact ⟨hcξ, fun z hz => ⟨htarget hz, houter z hz⟩⟩
  refine ⟨g0, A, ψ, ξ, hξ, ?_⟩
  intro i
  exact hlower (A.cover.anchor i) (ξ i) (hξ i).1 (hξ i).2
end Poincare
