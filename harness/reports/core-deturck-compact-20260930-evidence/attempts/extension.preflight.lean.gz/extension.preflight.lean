import Poincare.Global.DeTurckCoupledForcingDefinitions
import Lean
set_option maxHeartbeats 1000000
set_option synthInstance.maxHeartbeats 100000
universe u
open Lean Elab Command Term
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M] [T2Space M]\n[ChartedSpace Poincare.DeTurckPrincipalSecondJet.E M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(g0 bg : Poincare.ClosedSmoothRiemannianMetric 3 M) (anchor : M)\n(ξ : Poincare.DeTurckPrincipalSecondJet.E → ℝ) (α : ℝ), HasCompactSupport ξ → tsupport ξ ⊆ Poincare.DeTurckCompactCoefficients.zone anchor →\n0 < α → α < 1 →\n∃ η : Poincare.DeTurckPrincipalSecondJet.E → ℝ,\nContDiff ℝ ((⊤ : ENat) : WithTop ENat) η ∧ HasCompactSupport η ∧\ntsupport η ⊆ Poincare.DeTurckCompactCoefficients.zone anchor ∧\n(∀ z ∈ tsupport ξ, Filter.Eventually (fun y => η y = 1) (nhds z)) ∧\n(∀ z, η z ∈ Set.Icc 0 1) ∧\n(∀ a b c d : Fin 3,\n ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (fun z => η z * Poincare.DeTurckCompactCoefficients.raw0 g0 bg anchor a b c d z) ∧\n HasCompactSupport (fun z => η z * Poincare.DeTurckCompactCoefficients.raw0 g0 bg anchor a b c d z) ∧\n (∀ z ∈ tsupport ξ, Filter.Eventually (fun y => η y * Poincare.DeTurckCompactCoefficients.raw0 g0 bg anchor a b c d y = Poincare.DeTurckCompactCoefficients.raw0 g0 bg anchor a b c d y) (nhds z))) ∧\n(∀ p a b c d : Fin 3,\n ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (fun z => η z * Poincare.DeTurckCompactCoefficients.raw1 g0 bg anchor p a b c d z) ∧\n HasCompactSupport (fun z => η z * Poincare.DeTurckCompactCoefficients.raw1 g0 bg anchor p a b c d z) ∧\n (∀ z ∈ tsupport ξ, Filter.Eventually (fun y => η y * Poincare.DeTurckCompactCoefficients.raw1 g0 bg anchor p a b c d y = Poincare.DeTurckCompactCoefficients.raw1 g0 bg anchor p a b c d y) (nhds z))) ∧\n∃ C0 C1 : ℝ, 0 ≤ C0 ∧ 0 ≤ C1 ∧ ∀ T : ℝ,\n ∃ c0 : Fin 3 → Fin 3 → Fin 3 → Fin 3 → (Poincare.ParabolicHolder.Y (E := Poincare.DeTurckPrincipalSecondJet.E) α T ℝ),\n ∃ c1 : Fin 3 → Fin 3 → Fin 3 → Fin 3 → Fin 3 → (Poincare.ParabolicHolder.Y (E := Poincare.DeTurckPrincipalSecondJet.E) α T ℝ),\n (∀ a b c d : Fin 3, ∀ q ∈ Poincare.ParabolicHolder.cylinder T, c0 a b c d q = η q.2 * Poincare.DeTurckCompactCoefficients.raw0 g0 bg anchor a b c d q.2) ∧\n (∀ p a b c d : Fin 3, ∀ q ∈ Poincare.ParabolicHolder.cylinder T, c1 p a b c d q = η q.2 * Poincare.DeTurckCompactCoefficients.raw1 g0 bg anchor p a b c d q.2) ∧\n ∀ c d : Fin 3, (∑ a : Fin 3, ∑ b : Fin 3, ‖c0 a b c d‖) ≤ C0 ∧\n (∑ a : Fin 3, ∑ b : Fin 3, ∑ p : Fin 3, ‖c1 p a b c d‖) ≤ C1" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: extension"
