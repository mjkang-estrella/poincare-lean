import json,hashlib
from pathlib import Path
from harness.v2.runtime.validation import statement_contract_snapshot
r=Path.cwd();folder=r/'harness/v2/contracts/core-deturck-compact-20260930';folder.mkdir(exist_ok=True);d=r/'harness/v2/state/core-deturck-compact-20260930'
E='Poincare.DeTurckPrincipalSecondJet.E';D='Poincare.DeTurckCompactCoefficients';F='Poincare.DeTurckCoupledForcing';Y=f'Poincare.ParabolicHolder.Y (E := {E}) α T ℝ';cyl='Poincare.ParabolicHolder.cylinder T';entry='Poincare.DeTurckInverseEntryDerivative.entryCLM'
pre=f'''∀ (M : Type u) [TopologicalSpace M] [T2Space M]
[ChartedSpace {E} M]
[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]
(g0 bg : Poincare.ClosedSmoothRiemannianMetric 3 M) (anchor : M)'''
compact=pre+f'''
(ξ : {E} → ℝ) (α : ℝ), HasCompactSupport ξ → tsupport ξ ⊆ {D}.zone anchor →
0 < α → α < 1 →
∃ η : {E} → ℝ,
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) η ∧ HasCompactSupport η ∧
tsupport η ⊆ {D}.zone anchor ∧
(∀ z ∈ tsupport ξ, Filter.Eventually (fun y => η y = 1) (nhds z)) ∧
(∀ z, η z ∈ Set.Icc 0 1) ∧
(∀ a b c d : Fin 3,
 ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (fun z => η z * {D}.raw0 g0 bg anchor a b c d z) ∧
 HasCompactSupport (fun z => η z * {D}.raw0 g0 bg anchor a b c d z) ∧
 (∀ z ∈ tsupport ξ, Filter.Eventually (fun y => η y * {D}.raw0 g0 bg anchor a b c d y = {D}.raw0 g0 bg anchor a b c d y) (nhds z))) ∧
(∀ p a b c d : Fin 3,
 ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (fun z => η z * {D}.raw1 g0 bg anchor p a b c d z) ∧
 HasCompactSupport (fun z => η z * {D}.raw1 g0 bg anchor p a b c d z) ∧
 (∀ z ∈ tsupport ξ, Filter.Eventually (fun y => η y * {D}.raw1 g0 bg anchor p a b c d y = {D}.raw1 g0 bg anchor p a b c d y) (nhds z))) ∧
∃ C0 C1 : ℝ, 0 ≤ C0 ∧ 0 ≤ C1 ∧ ∀ T : ℝ,
 ∃ c0 : Fin 3 → Fin 3 → Fin 3 → Fin 3 → ({Y}),
 ∃ c1 : Fin 3 → Fin 3 → Fin 3 → Fin 3 → Fin 3 → ({Y}),
 (∀ a b c d : Fin 3, ∀ q ∈ {cyl}, c0 a b c d q = η q.2 * {D}.raw0 g0 bg anchor a b c d q.2) ∧
 (∀ p a b c d : Fin 3, ∀ q ∈ {cyl}, c1 p a b c d q = η q.2 * {D}.raw1 g0 bg anchor p a b c d q.2) ∧
 ∀ c d : Fin 3, (∑ a : Fin 3, ∑ b : Fin 3, ‖c0 a b c d‖) ≤ C0 ∧
 (∑ a : Fin 3, ∑ b : Fin 3, ∑ p : Fin 3, ‖c1 p a b c d‖) ≤ C1'''
forcing=pre+f'''
(η : {E} → ℝ) (c d : Fin 3) (α T : ℝ)
(c0 : {F}.Coeff0 α T) (c1 : {F}.Coeff1 α T),
0 < α → α < 1 → 0 < T → T ≤ 1 →
(∀ a b : Fin 3, ∀ q ∈ {cyl}, c0 a b q = η q.2 * {D}.raw0 g0 bg anchor a b c d q.2) →
(∀ p a b : Fin 3, ∀ q ∈ {cyl}, c1 p a b q = η q.2 * {D}.raw1 g0 bg anchor p a b c d q.2) →
∃ K : {F}.Inputs α T →L[ℝ] ({Y}),
 (∀ W q, (K W) q = {F}.value c0 c1 W q) ∧
 ‖K‖ ≤ {F}.timeBound c0 c1 ∧
 ∀ W q, q ∈ {cyl} →
 (K W) q = η q.2 * {entry} c d
  ({D}.field0 g0 bg anchor q.2 ({F}.tensorValue W q) +
   {D}.field1 g0 bg anchor q.2 ({F}.tensorJet W q))'''
mods={'extension':('DeTurckCompactCoefficientExtension',D+'.exists_actual_compact_carriers',compact),'forcing':('DeTurckCoupledForcing',F+'.exists_actual_coupled_forcing',forcing)}
pins=['Poincare/Global/RiemannianContext.lean','Poincare/Global/DeTurckPrincipalSecondJet.lean','Poincare/Global/DeTurckSpatialCoefficientDefinitions.lean','Poincare/Global/DeTurckTensorBasisDefinitions.lean','Poincare/Global/DeTurckCompactCoefficientDefinitions.lean','Poincare/Global/DeTurckCoupledForcingDefinitions.lean','Poincare/Global/ParabolicHolderSpace.lean','Poincare/Global/ParabolicSolutionGraph.lean']
for slug,(mod,name,t) in mods.items():
 c={'imports':['Poincare.Global.'+mod],'declarations':[{'name':name,'lean_type':t,'universes':['u']}],'definition_files':[{'path':p,'sha256':hashlib.sha256((r/p).read_bytes()).hexdigest()} for p in pins],'author':'root-orchestrator'}
 c['review']={'reviewer':'deturck-compact-readback','method':'blind-readback','snapshot_sha256':statement_contract_snapshot(c),'verdict':'pending','report_path':str((folder/f'{slug}.readback.json').relative_to(r)),'report_sha256':'0'*64}
 (folder/f'{slug}.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
 s='import Poincare.Global.DeTurckCoupledForcingDefinitions\nimport Lean\nset_option maxHeartbeats 1000000\nset_option synthInstance.maxHeartbeats 100000\nuniverse u\nopen Lean Elab Command Term\n'
 s+=f'''run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(t,ensure_ascii=False)} with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: {slug}"
'''
 (d/f'{slug}.preflight.lean').write_text(s)
(folder/'context.md').write_text('''# Actual compact coefficient carriers and coupled forcing

Every task helps UniversalHamiltonConvergenceStatement by constructing real Ricci-flow inputs; consumer is the actual full global L=dt-DQ(g0), its covariance and signed L/P/R contraction. Both universal cores remain open. No sphere recognition/favorable curvature/flow/limit package may be assumed.

The frozen definitions construct G,DG,D2G,B,DB and actual fields Z/F from g0/bg. Raw0=entry_cd(Z tensor_ab), Raw1=entry_cd(F firstJet_pab). All9/27 ordered slots and inverse variation against D2g0 remain. Canonical instances retain original operator norms and actions. No symmetric-six convention.

Extension: actual local-solver atlas supplies compact tsupport xi inside the true chart-target/cutoff-one-germ zone. BufferedFrozenParabolicSolver.exists_buffered_cutoff constructs eta smooth compact supported in that zone and equal1 near ALL tsupport xi. ActualSpatialCoefficients supplies open zone and C∞ Z/F; fixed-generator CLM evaluation yields raw smoothness there. ClosedLaplacianStokesGlobalCoefficients.contDiff_cutoff_mul supplies global eta*raw smoothness; hceta.mul_right gives compactness. ParabolicCutoffCommutator.exists_cutoff_carrier constructs each scalar Y carrier uniformly for ALL T; finite sums of constants choose C0/C1 before T, common across outputcd. This constructor receives no coefficient or bound package.

Forcing: construct nine-input Pi Graph ->L scalar Y by summing firstOrderLinearMap(c1_pab,c0_ab) after LinearMap.proj(a,b), then mkContinuous. firstOrder_time_bound/interpolation preserves norm<=24*(sum_abp norm(c1)*T^((1-alpha)/2)+sum_ab norm(c0)*T^(1-alpha/2)). Retain separate time powers, ordinary Pi maximum and original Graph sum norm/derivative carriers/zero trace. Carrier realization premises are exact eta*ACTUAL raw arrays supplied by the extension producer of this same batch, not unproved flow/coefficient packages. Prove whole actual action eta*entry_cd(Z(tensorValueW)+F(tensorJetW)) on cylinder by finite basis reconstruction/linearity, all-point explicit forcing values. Positive lower action K will be SUBTRACTED in L=dt-principal-K.

Preserve every failed source/log and finaldiff append-only. Local Codex helpers are not registered Pi/Leanstral Jobs. Workers own only taskfile, are not alone, never revert others/edit main/merge/selfaccept/fullbuild/manage services. Full final target/cores/norms unchanged.
''')
