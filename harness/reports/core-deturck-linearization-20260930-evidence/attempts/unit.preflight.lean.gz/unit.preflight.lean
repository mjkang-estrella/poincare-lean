import Poincare.Global.DeTurckInverseEntryDerivativeDefinitions
import Lean
open Lean Elab Command Term
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ G0 : Poincare.DeTurckPrincipalSecondJet.Bilin, G0.IsInvertible →\nIsUnit (fun i j : Fin 3 => G0 (Poincare.DeTurckPrincipalSecondJet.basis3 i) (Poincare.DeTurckPrincipalSecondJet.basis3 j) : Matrix (Fin 3) (Fin 3) ℝ)" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"
  logInfo "PREFLIGHT_OK: coordinate_matrix_isUnit"
