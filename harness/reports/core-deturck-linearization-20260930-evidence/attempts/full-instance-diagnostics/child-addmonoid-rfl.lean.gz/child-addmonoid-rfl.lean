import Poincare.Global.DeTurckJetLinearizationDefinitions
open Poincare.DeTurckPrincipalSecondJet Poincare.DeTurckJetLinearization
noncomputable section
local instance jGroup : NormedAddCommGroup Jet1 :=
  ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance jSpace : NormedSpace ℝ Jet1 :=
  ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
example : (Prod.instAddCommMonoid : AddCommMonoid (Bilin × Jet1)) =
  (Prod.normedAddCommGroup : NormedAddCommGroup (Bilin × Jet1)).toAddCommGroup.toAddCommMonoid := rfl
private def originalPairNorm : Norm (Bilin × Jet1) := inferInstance
example (p : Bilin × Jet1) :
    letI : AddCommMonoid (Bilin × Jet1) := Prod.instAddCommMonoid
    @Norm.norm (Bilin × Jet1) originalPairNorm p = ‖p‖ := rfl
