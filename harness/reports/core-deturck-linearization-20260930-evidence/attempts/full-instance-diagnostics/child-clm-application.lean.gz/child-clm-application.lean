import Poincare.Global.DeTurckJetLinearizationDefinitions
open Poincare.DeTurckPrincipalSecondJet Poincare.DeTurckJetLinearization
noncomputable section
local instance jGroup : NormedAddCommGroup Jet1 :=
  ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance jSpace : NormedSpace ℝ Jet1 :=
  ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance pGroup : NormedAddCommGroup (Bilin × Jet1) := Prod.normedAddCommGroup
local instance pSpace : NormedSpace ℝ (Bilin × Jet1) := Prod.normedSpace
#check @ContinuousLinearMap.toLinearMap
#check @LinearMap.toFun
#check @ContinuousLinearMap.funLike
variable (B : E →L[ℝ] E →L[ℝ] E) (DB : E →L[ℝ] E →L[ℝ] E →L[ℝ] E)
variable (G : Bilin) (J : Jet1) (h : Bilin × Jet1) (v w : E)
#check lowerDifferential B DB G J
#check (lowerDifferential B DB G J).toFun h
#check (lowerDifferential B DB G J).toLinearMap.toFun h
#check ((lowerDifferential B DB G J : (Bilin × Jet1) → Bilin) h) v w
#check (lowerDifferential B DB G J h) v w
example : (lowerDifferential B DB G J).toFun h = lowerDifferential B DB G J h := rfl
