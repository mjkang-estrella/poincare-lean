import Poincare.Global.DeTurckJetLinearizationDefinitions
import Poincare.Global.DeTurckInverseEntryDerivative
noncomputable section
open scoped BigOperators
set_option autoImplicit false
set_option maxHeartbeats 50000

theorem scalar_sum_algebra_probe (c u d v : Fin 3 → Fin 3 → ℝ) (l : ℝ) :
    ((∑ i : Fin 3, ∑ j : Fin 3, (c i j * u i j + d i j * v i j)) + l) =
    ((∑ i : Fin 3, ∑ j : Fin 3, d i j * v i j) +
      (∑ i : Fin 3, ∑ j : Fin 3, c i j * u i j)) + l := by
  simp only [Finset.sum_add_distrib]
  ring
