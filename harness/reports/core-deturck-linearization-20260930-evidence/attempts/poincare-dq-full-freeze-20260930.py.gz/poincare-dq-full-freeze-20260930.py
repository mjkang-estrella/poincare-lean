import json,hashlib
from pathlib import Path
from harness.v2.runtime.validation import statement_contract_snapshot
root=Path.cwd();folder=root/'harness/v2/contracts/core-deturck-linearization-20260930';state=root/'harness/v2/state/core-deturck-linearization-20260930'
E='Poincare.DeTurckPrincipalSecondJet.E';G='Poincare.DeTurckPrincipalSecondJet.Bilin';J='Poincare.DeTurckPrincipalSecondJet.Jet1';F='Poincare.DeTurckJetLinearization';H=F+'.Jet2';V=F+'.Variables';A='Poincare.DeTurckPrincipalSecondJet.inverseEntries';e='Poincare.DeTurckPrincipalSecondJet.basis3'
cj=json.loads((folder/'joint.contract.json').read_text())['statement_contract'];pre=cj['declarations'][0]['lean_type'].split('∀ (B',1)[0]+f'''letI : NormedAddCommGroup {H} := ContinuousLinearMap.toNormedAddCommGroup
 (𝕜 := ℝ) (𝕜₂ := ℝ) (E := {E}) (F := {J}) (σ₁₂ := RingHom.id ℝ);
letI : NormedSpace ℝ {H} := ContinuousLinearMap.toNormedSpace
 (𝕜 := ℝ) (𝕜₂ := ℝ) (E := {E}) (F := {J}) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);
'''
pre+=f'''letI : NormedAddCommGroup ({G} × {J}) := Prod.normedAddCommGroup;
letI : NormedSpace ℝ ({G} × {J}) := Prod.normedSpace;
letI : NormedAddCommGroup {V} := Prod.normedAddCommGroup;
letI : NormedSpace ℝ {V} := Prod.normedSpace;
'''
t=pre+f'''∀ (B : {E} →L[ℝ] {E} →L[ℝ] {E})
(DB : {E} →L[ℝ] {E} →L[ℝ] {E} →L[ℝ] {E})
(G0 : {G}) (J0 : {J}) (H0 : {H}), G0.IsInvertible →
HasFDerivAt ({F}.evolution B DB) ({F}.differential B DB G0 J0 H0) ((G0,J0),H0) ∧
∀ (h : {V}) (v w : {E}), ({F}.differential B DB G0 J0 H0 h) v w =
 (∑ i : Fin 3, ∑ j : Fin 3, {A} G0 i j * h.2 ({e} i) ({e} j) v w) +
 (∑ i : Fin 3, ∑ j : Fin 3,
   (-(∑ k : Fin 3, ∑ l : Fin 3,
     {A} G0 i k * h.1.1 ({e} k) ({e} l) * {A} G0 l j)) * H0 ({e} i) ({e} j) v w) +
 {F}.lowerDifferential B DB G0 J0 h.1 v w'''
pins=['Poincare/Global/RiemannianContext.lean','Poincare/Global/DeTurckPrincipalSecondJet.lean','Poincare/Global/DeTurckPrincipalIdentity.lean','Poincare/Global/DeTurckInverseEntryDerivativeDefinitions.lean','Poincare/Global/DeTurckJetLinearizationDefinitions.lean']
c={'imports':['Poincare.Global.DeTurckJetLinearization'],'declarations':[{'name':F+'.hasFDerivAt_evolution','lean_type':t,'universes':[]}],'definition_files':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in pins],'author':'root-orchestrator'};c['review']={'reviewer':'deturck-linearization-readback','method':'blind-readback','snapshot_sha256':statement_contract_snapshot(c),'verdict':'pending','report_path':'harness/v2/contracts/core-deturck-linearization-20260930/full.readback.json','report_sha256':'0'*64};(folder/'full.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
probe='import Poincare.Global.DeTurckJetLinearizationDefinitions\nimport Lean\nopen Lean Elab Command Term\n';probe+=f'run_cmd liftTermElabM do\n  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(t,ensure_ascii=False)} with\n    | .ok s => pure s\n    | .error e => throwError e\n  let expected ← Term.elabType stx\n  Term.synthesizeSyntheticMVarsNoPostponing\n  let expected ← instantiateMVars expected\n  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"\n  logInfo "PREFLIGHT_OK: hasFDerivAt_evolution"\n';(state/'full.preflight.lean').write_text(probe)
