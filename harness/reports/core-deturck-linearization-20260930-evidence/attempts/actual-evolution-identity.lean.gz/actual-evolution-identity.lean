import Poincare.Global.DeTurckJetLinearizationDefinitions
noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
open scoped Manifold ContDiff BigOperators
open Poincare Poincare.DeTurckPrincipalSecondJet Poincare.DeTurckPrincipalIdentity
local instance : NormedAddCommGroup Jet1 := ContinuousLinearMap.toNormedAddCommGroup
  (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance : NormedSpace ℝ Jet1 := ContinuousLinearMap.toNormedSpace
  (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance : NormedAddCommGroup (E →L[ℝ] E →L[ℝ] E) :=
  ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ)
    (E := E) (F := (E →L[ℝ] E)) (σ₁₂ := RingHom.id ℝ)
local instance : NormedSpace ℝ (E →L[ℝ] E →L[ℝ] E) :=
  ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ)
    (E := E) (F := (E →L[ℝ] E)) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
universe u
example {M : Type u} [TopologicalSpace M] [T2Space M]
    [ChartedSpace E M] [IsManifold (closedSmoothModelWithCorners 3) ∞ M]
    (g0 bg : ClosedSmoothRiemannianMetric 3 M) (anchor : M) (z : E)
    (hz : z ∈ (extChartAt (closedSmoothModelWithCorners 3) anchor).target)
    (hcut : Filter.Eventually
      (fun y => GeodesicTransport.cutoff (n := 3) anchor y = 1) (nhds z)) :
    let G := CovariantDerivative.chartMetric g0.inner anchor
    let B := GeodesicTransport.chartChristoffelField bg anchor
    (G z).IsInvertible ∧
      DeTurckJetLinearization.evolution (B z) (fderiv ℝ B z)
        ((G z, fderiv ℝ G z), fderiv ℝ (fderiv ℝ G) z) =
        deTurckChartMetricEvolutionBilin (fun _ => g0) bg anchor 0 z := by
  dsimp only
  refine ⟨chartMetric_isInvertible_of_cutoff g0 anchor z hcut, ?_⟩
  ext v w
  have hR := ricci_eq_secondJet_add_first g0 anchor z hz hcut v w
  have hL := lie_eq_secondJet_add_first g0 bg anchor z hz hcut v w
  have hcancel := chartMetric_secondJet_cancellation g0 anchor z hz v w
  rw [evolution_eq_coordinate_expression g0 bg anchor z hz hcut v w]
  simp only [DeTurckJetLinearization.evolution, DeTurckJetLinearization.principal,
    ContinuousLinearMap.add_apply, ContinuousLinearMap.sum_apply,
    ContinuousLinearMap.smul_apply, smul_eq_mul, lowerTerm_apply]
  dsimp only [spatialPrincipal] at hcancel
  linarith only [hR, hL, hcancel]
