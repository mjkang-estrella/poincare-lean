import json,hashlib
from pathlib import Path
from harness.v2.runtime.validation import statement_contract_snapshot
root=Path.cwd();folder=root/'harness/v2/contracts/core-deturck-linearization-20260930';state=root/'harness/v2/state/core-deturck-linearization-20260930'
E='Poincare.DeTurckPrincipalSecondJet.E';G='Poincare.DeTurckPrincipalSecondJet.Bilin';J='Poincare.DeTurckPrincipalSecondJet.Jet1';A='Poincare.DeTurckPrincipalSecondJet.inverseEntries';NS='Poincare.DeTurckInverseEntryDerivative';basis='Poincare.DeTurckPrincipalSecondJet.basis3'
old=json.loads((root/'harness/v2/contracts/core-global-parametrix-20260930/lower-smooth.contract.json').read_text())['statement_contract']['declarations'][0]['lean_type'];pre=old.split('∀ (B',1)[0]
BG=f'({E} →L[ℝ] {E} →L[ℝ] {E})';DB=f'({E} →L[ℝ] {E} →L[ℝ] {E} →L[ℝ] {E})'
unit=f'''∀ G0 : {G}, G0.IsInvertible →
IsUnit (fun i j : Fin 3 => G0 ({basis} i) ({basis} j) : Matrix (Fin 3) (Fin 3) ℝ)'''
bgpre=f'''letI : NormedAddCommGroup {BG} := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := {E}) (F := ({E} →L[ℝ] {E})) (σ₁₂ := RingHom.id ℝ);
letI : NormedSpace ℝ {BG} := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := {E}) (F := ({E} →L[ℝ] {E})) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);
letI : NormedAddCommGroup {DB} := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := {E}) (F := {BG}) (σ₁₂ := RingHom.id ℝ);
letI : NormedSpace ℝ {DB} := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := {E}) (F := {BG}) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);
'''
joint=pre+bgpre+f'''∀ (B : {BG}) (DB : {DB}) (G0 : {G}) (J0 : {J}),
G0.IsInvertible → ContDiffAt ℝ ((⊤ : ENat) : WithTop ENat)
 (fun p : ({BG} × {DB}) × ({G} × {J}) =>
   Poincare.DeTurckPrincipalIdentity.lowerTerm p.1.1 p.1.2 p.2.1 p.2.2)
 ((B,DB),(G0,J0))'''
inv=f'''∀ (G0 : {G}) (i j : Fin 3), G0.IsInvertible →
HasFDerivAt (fun G : {G} => {A} G i j) ({NS}.inverseEntryDerivative G0 i j) G0'''
pins=['Poincare/Global/RiemannianContext.lean','Poincare/Global/DeTurckPrincipalSecondJet.lean','Poincare/Global/DeTurckPrincipalIdentity.lean']
for slug,mod,name,t in [('unit','DeTurckMetricJetNonsingular','coordinate_matrix_isUnit',unit),('joint','DeTurckLowerJointSmoothness','contDiffAt_lowerTerm_joint',joint),('inverse','DeTurckInverseEntryDerivative','hasFDerivAt_inverseEntry',inv)]:
 pp=pins+(['Poincare/Global/DeTurckInverseEntryDerivativeDefinitions.lean'] if slug=='inverse' else [])
 namespace=NS if slug=='inverse' else 'Poincare.'+mod
 c={'imports':['Poincare.Global.'+mod],'declarations':[{'name':namespace+'.'+name,'lean_type':t,'universes':[]}],'definition_files':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in pp],'author':'root-orchestrator'}
 c['review']={'reviewer':'deturck-linearization-readback','method':'blind-readback','snapshot_sha256':statement_contract_snapshot(c),'verdict':'pending','report_path':f'harness/v2/contracts/core-deturck-linearization-20260930/{slug}.readback.json','report_sha256':'0'*64}
 (folder/f'{slug}.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
 probe='import Poincare.Global.DeTurckInverseEntryDerivativeDefinitions\nimport Lean\nopen Lean Elab Command Term\n'
 probe+=f'run_cmd liftTermElabM do\n  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(t,ensure_ascii=False)} with\n    | .ok s => pure s\n    | .error e => throwError e\n  let expected ← Term.elabType stx\n  Term.synthesizeSyntheticMVarsNoPostponing\n  let expected ← instantiateMVars expected\n  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"\n  logInfo "PREFLIGHT_OK: {name}"\n'
 (state/f'{slug}.preflight.lean').write_text(probe)
(folder/'construction-context.md').write_text('''# Actual finite-jet DeTurck differential toward core Hamilton existence

Every task helps UniversalHamiltonConvergenceStatement through true general Ricci-flow construction. The metric-jet unit task is consumed immediately by the inverse-entry derivative. That derivative and joint lower smoothness are consumed by the full finite-jet Q/DQ constructor, then coefficient spatial regularity, differentiated tensor covariance and actual bounded L=dt-DQ(g0), signed L/P/R contraction. Core smoothability and universal Hamilton existence remain open.

Metric jet nonsingularity must be constructed from actual G0.IsInvertible, with no symmetry or det/nonzero/unit premise added. The existing inverseEntries_eq_coordinates proof gives the raised-coordinate left inverse N*M=1 via G(G.inverse covector)=covector and basis.sum_repr. Use Matrix.isUnit_iff_isUnit_det + isUnit_det_of_left_inverse, not a circular coordinate-unit assumption.

The inverse-entry task constructs the actual CLM derivative, retaining both inverse factors and all k,l summands. Mathlib hasFDerivAt_ringInverse gives H->-a*H*a; Matrix.nonsing_inv_eq_ringInverse identifies actual Matrix.inv. Keep Matrix.Norms.Operator scoped internally; public scalar derivative has the unchanged Bilin domain norm and real codomain norm. Its metric-matrix unit input is supplied by the independent unit proof.

Joint lower smoothness targets actual Bilin-valued lowerTerm with B,DB,G,J all varying; fixed-background smoothness alone does not supply coefficient spatial regularity. The canonical Jet1 bindings are already verified to retain actual operator norm. Further canonical background map instance pins, if needed, must be proved norm-preserving before a revised type is frozen. No alternative norms or new supplied hypotheses are allowed. Reuse actual finite-dimensional CLM reconstruction and rational expressions from DeTurckLowerJetSmoothness.

The subsequent full differential must include a(G0):dH + Da(G0)[dG]:H0 + Dlower(B,DB,G0,J0)[dG,dJ]. The Da:H0 term is a required zero-order coefficient. The real nonlinear expression is the actual inverseEntries principal contraction plus explicit lowerTerm, not an unconstrained lower chosen from the existential principalIdentity and not Appendix/survey probes or assumed CLM packages. The actual chart-evolution identification follows the existing ricci/lie second-jet identities and cancellation.

Preserve all failed compiler/source attempts and final diffs. Local Codex helpers are not registered Pi/Leanstral runtime Jobs. Workers never full-build, self-accept, merge or alter services. The final theorem and both core statements are frozen.
''')
