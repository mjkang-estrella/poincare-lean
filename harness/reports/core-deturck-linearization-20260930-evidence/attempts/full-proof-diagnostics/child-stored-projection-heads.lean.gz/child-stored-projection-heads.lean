import Poincare.Global.DeTurckJetLinearizationDefinitions
import Lean
open Lean Meta Elab Command
private def headSummary (e : Expr) : String :=
  match e.getAppFn with
  | .const n _ => s!"{n} / {e.getAppArgs.size} args"
  | .fvar id => s!"fvar {id.name}"
  | _ => s!"other {e.getAppFn}"
run_cmd liftTermElabM do
  for name in [``Poincare.DeTurckJetLinearization.metricProjection,
      ``Poincare.DeTurckJetLinearization.secondJetEvaluation] do
    let ci ← getConstInfo name
    forallTelescopeReducing ci.type fun _ body => do
      let body ← whnf body
      logInfo m!"{name}: {headSummary body}"
      for i in [:body.getAppArgs.size] do
        let arg := body.getAppArgs[i]!
        logInfo m!"  arg {i}: {headSummary arg}"
        if i == 6 || i == 7 || i == 9 || i == 10 || i == 11 || i == 12 then
          for j in [:arg.getAppArgs.size] do
            logInfo m!"    subarg {j}: {headSummary (arg.getAppArgs[j]!)}"
