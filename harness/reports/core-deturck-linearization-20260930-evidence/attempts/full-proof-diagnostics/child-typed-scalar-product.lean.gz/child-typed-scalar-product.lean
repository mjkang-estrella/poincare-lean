import Poincare.Global.DeTurckJetLinearizationDefinitions
import Poincare.Global.DeTurckInverseEntryDerivative
import Poincare.Global.DeTurckLowerJointSmoothness

set_option autoImplicit false
set_option maxHeartbeats 6000000
set_option synthInstance.maxHeartbeats 100000

noncomputable section
open scoped ContDiff BigOperators

namespace Poincare.DeTurckJetLinearization
open DeTurckPrincipalSecondJet

local instance : NormedAddCommGroup Poincare.DeTurckPrincipalSecondJet.Jet1 :=
      ContinuousLinearMap.toNormedAddCommGroup
        (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin)
        (σ₁₂ := RingHom.id ℝ)

local instance : NormedSpace ℝ Poincare.DeTurckPrincipalSecondJet.Jet1 :=
      ContinuousLinearMap.toNormedSpace
        (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin)
        (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

local instance : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ)

local instance : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

local instance : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ)

local instance : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

local instance : NormedAddCommGroup Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedAddCommGroup
     (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ)

local instance : NormedSpace ℝ Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedSpace
     (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

local instance : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.normedAddCommGroup

local instance : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.normedSpace

local instance : NormedAddCommGroup Poincare.DeTurckJetLinearization.Variables := Prod.normedAddCommGroup

local instance : NormedSpace ℝ Poincare.DeTurckJetLinearization.Variables := Prod.normedSpace

local instance : AddCommMonoid (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.instAddCommMonoid

variable (G0 : Bilin) (J0 : Jet1) (H0 : Jet2) (hG0 : G0.IsInvertible)
example : HasFDerivAt (fun p : Variables => p.1.1) metricProjection ((G0,J0),H0) := by
  exact metricProjection.hasFDerivAt (x := ((G0,J0),H0))
private theorem inverseProjection (i j : Fin 3) :
    HasFDerivAt (fun p : Variables => inverseEntries p.1.1 i j)
      ((DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j).comp metricProjection)
      ((G0,J0),H0) := by
  have hP : HasFDerivAt (fun p : Variables => p.1.1) metricProjection ((G0,J0),H0) :=
    metricProjection.hasFDerivAt (x := ((G0,J0),H0))
  have hA : HasFDerivAt (fun G : Bilin => inverseEntries G i j)
      (DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j) G0 :=
    DeTurckInverseEntryDerivative.hasFDerivAt_inverseEntry G0 i j hG0
  exact HasFDerivAt.comp (𝕜 := ℝ) (E := Variables) (F := Bilin) (G := ℝ)
    (f := fun p : Variables => p.1.1) (f' := metricProjection)
    (g := fun G : Bilin => inverseEntries G i j)
    (g' := DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j)
    ((G0,J0),H0) hA hP

private theorem scalarProduct (i j : Fin 3) :
    HasFDerivAt (fun p : Variables => inverseEntries p.1.1 i j • p.2 (basis3 i) (basis3 j))
      (inverseEntries G0 i j • secondJetEvaluation i j +
        ((DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j).comp metricProjection).smulRight
          (H0 (basis3 i) (basis3 j))) ((G0,J0),H0) := by
  have hA := inverseProjection G0 J0 H0 hG0 i j
  have hE : HasFDerivAt (fun p : Variables => p.2 (basis3 i) (basis3 j))
      (secondJetEvaluation i j) ((G0,J0),H0) :=
    (secondJetEvaluation i j).hasFDerivAt (x := ((G0,J0),H0))
  exact HasFDerivAt.smul (𝕜 := ℝ) (𝕜' := ℝ) (E := Variables) (F := Bilin)
    (c := fun p : Variables => inverseEntries p.1.1 i j)
    (c' := (DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j).comp metricProjection)
    (f := fun p : Variables => p.2 (basis3 i) (basis3 j))
    (f' := secondJetEvaluation i j) (x := ((G0,J0),H0)) hA hE

example :
    HasFDerivAt (fun p : Variables => ∑ i : Fin 3, ∑ j : Fin 3,
      inverseEntries p.1.1 i j • p.2 (basis3 i) (basis3 j))
      (∑ i : Fin 3, ∑ j : Fin 3, inverseEntries G0 i j • secondJetEvaluation i j +
        ((DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j).comp metricProjection).smulRight
          (H0 (basis3 i) (basis3 j))) ((G0,J0),H0) := by
  exact HasFDerivAt.fun_sum (𝕜 := ℝ) (E := Variables) (F := Bilin) (u := Finset.univ)
    (A := fun i p => ∑ j : Fin 3, inverseEntries p.1.1 i j • p.2 (basis3 i) (basis3 j))
    (A' := fun i => ∑ j : Fin 3, inverseEntries G0 i j • secondJetEvaluation i j +
      ((DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j).comp metricProjection).smulRight
        (H0 (basis3 i) (basis3 j)))
    (x := ((G0,J0),H0))
    (fun i _ => HasFDerivAt.fun_sum (𝕜 := ℝ) (E := Variables) (F := Bilin) (u := Finset.univ)
      (A := fun j p => inverseEntries p.1.1 i j • p.2 (basis3 i) (basis3 j))
      (A' := fun j => inverseEntries G0 i j • secondJetEvaluation i j +
        ((DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j).comp metricProjection).smulRight
          (H0 (basis3 i) (basis3 j)))
      (x := ((G0,J0),H0)) (fun j _ => scalarProduct G0 J0 H0 hG0 i j))
end Poincare.DeTurckJetLinearization
