import Poincare.Global.DeTurckJetLinearizationDefinitions
import Poincare.Global.DeTurckInverseEntryDerivative
import Poincare.Global.DeTurckLowerJointSmoothness

set_option autoImplicit false
set_option maxHeartbeats 6000000
set_option synthInstance.maxHeartbeats 100000

noncomputable section
open scoped ContDiff BigOperators

namespace Poincare.DeTurckJetLinearization
open DeTurckPrincipalSecondJet

local instance : NormedAddCommGroup Poincare.DeTurckPrincipalSecondJet.Jet1 :=
      ContinuousLinearMap.toNormedAddCommGroup
        (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin)
        (σ₁₂ := RingHom.id ℝ)

local instance : NormedSpace ℝ Poincare.DeTurckPrincipalSecondJet.Jet1 :=
      ContinuousLinearMap.toNormedSpace
        (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin)
        (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

local instance : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ)

local instance : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

local instance : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ)

local instance : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

local instance : NormedAddCommGroup Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedAddCommGroup
     (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ)

local instance : NormedSpace ℝ Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedSpace
     (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

local instance : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.normedAddCommGroup

local instance : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.normedSpace

local instance : NormedAddCommGroup Poincare.DeTurckJetLinearization.Variables := Prod.normedAddCommGroup

local instance : NormedSpace ℝ Poincare.DeTurckJetLinearization.Variables := Prod.normedSpace

local instance : AddCommMonoid (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.instAddCommMonoid

variable (G0 : Bilin) (J0 : Jet1) (H0 : Jet2)
example
    (hTerm : ∀ i j : Fin 3, HasFDerivAt
      (fun p : Variables => inverseEntries p.1.1 i j • p.2 (basis3 i) (basis3 j))
      (inverseEntries G0 i j • secondJetEvaluation i j +
  ((DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j).comp metricProjection).smulRight (H0 (basis3 i) (basis3 j))) ((G0,J0),H0)) :
    HasFDerivAt (fun p : Variables => ∑ i : Fin 3, ∑ j : Fin 3, inverseEntries p.1.1 i j • p.2 (basis3 i) (basis3 j))
      (∑ i : Fin 3, ∑ j : Fin 3, inverseEntries G0 i j • secondJetEvaluation i j +
  ((DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j).comp metricProjection).smulRight (H0 (basis3 i) (basis3 j))) ((G0,J0),H0) := by
  have hRow (i : Fin 3) :
      HasFDerivAt (fun p : Variables => ∑ j : Fin 3, inverseEntries p.1.1 i j • p.2 (basis3 i) (basis3 j))
        (∑ j : Fin 3, inverseEntries G0 i j • secondJetEvaluation i j +
  ((DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j).comp metricProjection).smulRight (H0 (basis3 i) (basis3 j))) ((G0,J0),H0) := by
    simpa only [Finset.sum_const_zero] using
      HasFDerivAt.fun_sum (𝕜 := ℝ) (E := Variables) (F := Bilin)
        (A := fun j (p : Variables) => inverseEntries p.1.1 i j • p.2 (basis3 i) (basis3 j))
        (A' := fun j => inverseEntries G0 i j • secondJetEvaluation i j +
  ((DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j).comp metricProjection).smulRight (H0 (basis3 i) (basis3 j)))
        (x := ((G0,J0),H0)) (u := Finset.univ)
        (fun j (_ : j ∈ (Finset.univ : Finset (Fin 3))) => hTerm i j)
  simpa only [Finset.sum_const_zero] using
    HasFDerivAt.fun_sum (𝕜 := ℝ) (E := Variables) (F := Bilin)
      (A := fun i (p : Variables) => ∑ j : Fin 3, inverseEntries p.1.1 i j • p.2 (basis3 i) (basis3 j))
      (A' := fun i => ∑ j : Fin 3, inverseEntries G0 i j • secondJetEvaluation i j +
  ((DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j).comp metricProjection).smulRight (H0 (basis3 i) (basis3 j)))
      (x := ((G0,J0),H0)) (u := Finset.univ)
      (fun i (_ : i ∈ (Finset.univ : Finset (Fin 3))) => hRow i)

end Poincare.DeTurckJetLinearization
