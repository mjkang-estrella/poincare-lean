import Lean
import Poincare.Global.DeTurckPrincipalIdentity

noncomputable section
set_option autoImplicit false
open scoped BigOperators

namespace Poincare.DeTurckInverseEntryDerivative
open DeTurckPrincipalSecondJet

/-- Actual metric-coordinate evaluation as a bounded real linear map. -/
def entryCLM (k l : Fin 3) : Bilin →L[ℝ] ℝ :=
  (ContinuousLinearMap.apply ℝ ℝ (basis3 l)).comp
    (ContinuousLinearMap.apply ℝ (E →L[ℝ] ℝ) (basis3 k))

/-- The inverse-metric variation coefficient, retaining both inverse factors. -/
def inverseEntryDerivative (G0 : Bilin) (i j : Fin 3) : Bilin →L[ℝ] ℝ :=
  -(∑ k : Fin 3, ∑ l : Fin 3,
    (inverseEntries G0 i k * inverseEntries G0 l j) • entryCLM k l)

end Poincare.DeTurckInverseEntryDerivative

open Lean Elab Command Meta
run_cmd liftTermElabM do
  let literal : String := "∀ G0 : Poincare.DeTurckPrincipalSecondJet.Bilin, G0.IsInvertible →\nIsUnit (fun i j : Fin 3 => G0 (Poincare.DeTurckPrincipalSecondJet.basis3 i) (Poincare.DeTurckPrincipalSecondJet.basis3 j) : Matrix (Fin 3) (Fin 3) ℝ)"
  let parsed ← match Parser.runParserCategory (← getEnv) `term literal with
    | .ok parsed => pure parsed
    | .error err => throwError err
  let expected ← Term.elabType parsed
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then
    throwError "unresolved metavariables"
  logInfo "UNIT_LITERAL_OK"
run_cmd liftTermElabM do
  let literal : String := "∀ (G0 : Poincare.DeTurckPrincipalSecondJet.Bilin) (i j : Fin 3), G0.IsInvertible →\nHasFDerivAt (fun G : Poincare.DeTurckPrincipalSecondJet.Bilin => Poincare.DeTurckPrincipalSecondJet.inverseEntries G i j) (Poincare.DeTurckInverseEntryDerivative.inverseEntryDerivative G0 i j) G0"
  let parsed ← match Parser.runParserCategory (← getEnv) `term literal with
    | .ok parsed => pure parsed
    | .error err => throwError err
  let expected ← Term.elabType parsed
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then
    throwError "unresolved metavariables"
  logInfo "INVERSE_LITERAL_OK"
open Poincare.DeTurckPrincipalSecondJet
example (G : Bilin) : inverseEntries G =
    @Inv.inv (Matrix (Fin 3) (Fin 3) ℝ) Matrix.inv
      (fun i j => G (basis3 i) (basis3 j)) := by rfl
example (H : Bilin) (k l : Fin 3) :
    Poincare.DeTurckInverseEntryDerivative.entryCLM k l H = H (basis3 k) (basis3 l) := by rfl
