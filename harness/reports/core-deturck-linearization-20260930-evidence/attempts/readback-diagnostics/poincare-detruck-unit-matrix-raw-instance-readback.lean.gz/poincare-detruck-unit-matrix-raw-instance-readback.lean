import Lean
import Poincare.Global.DeTurckPrincipalIdentity
open Lean Elab Command Meta
open scoped BigOperators
set_option autoImplicit false
run_cmd liftTermElabM do
  let literal : String := "∀ G0 : Poincare.DeTurckPrincipalSecondJet.Bilin, G0.IsInvertible →\nIsUnit (fun i j : Fin 3 => G0 (Poincare.DeTurckPrincipalSecondJet.basis3 i) (Poincare.DeTurckPrincipalSecondJet.basis3 j) : Matrix (Fin 3) (Fin 3) ℝ)"
  let parsed ← match Parser.runParserCategory (← getEnv) `term literal with
    | .ok parsed => pure parsed
    | .error err => throwError err
  let ty ← Term.elabType parsed
  Term.synthesizeSyntheticMVarsNoPostponing
  let ty ← instantiateMVars ty
  if ty.hasMVar || ty.hasLevelMVar then
    throwError "unresolved metavariables"
  forallTelescope ty fun _ body => do
    unless body.getAppFn.isConstOf ``IsUnit do
      throwError "expected IsUnit body"
    let args := body.getAppArgs
    unless args.size == 3 do
      throwError "unexpected IsUnit arity"
    let canonical ← Term.elabTerm (← `(show Monoid (Matrix (Fin 3) (Fin 3) ℝ) from Matrix.semiring.toMonoidWithZero.toMonoid)) none
    Term.synthesizeSyntheticMVarsNoPostponing
    let canonical ← instantiateMVars canonical
    let actual := args[1]!
    let same ← isDefEq actual canonical
    unless same == false do
      throwError "unexpected monoid selection"
    let printed ← withOptions (fun opts => opts.setBool `pp.all true) (ppExpr actual)
    logInfo m!"unit monoid Expr: {printed}"
    logInfo m!"unit actual_matrix_monoid = {same}"
run_cmd liftTermElabM do
  let literal : String := "∀ G0 : Poincare.DeTurckPrincipalSecondJet.Bilin, G0.IsInvertible →\n@IsUnit (Matrix (Fin 3) (Fin 3) ℝ) Matrix.semiring.toMonoidWithZero.toMonoid\n(fun i j : Fin 3 => G0 (Poincare.DeTurckPrincipalSecondJet.basis3 i) (Poincare.DeTurckPrincipalSecondJet.basis3 j))"
  let parsed ← match Parser.runParserCategory (← getEnv) `term literal with
    | .ok parsed => pure parsed
    | .error err => throwError err
  let ty ← Term.elabType parsed
  Term.synthesizeSyntheticMVarsNoPostponing
  let ty ← instantiateMVars ty
  if ty.hasMVar || ty.hasLevelMVar then
    throwError "unresolved metavariables"
  forallTelescope ty fun _ body => do
    unless body.getAppFn.isConstOf ``IsUnit do
      throwError "expected IsUnit body"
    let args := body.getAppArgs
    unless args.size == 3 do
      throwError "unexpected IsUnit arity"
    let canonical ← Term.elabTerm (← `(show Monoid (Matrix (Fin 3) (Fin 3) ℝ) from Matrix.semiring.toMonoidWithZero.toMonoid)) none
    Term.synthesizeSyntheticMVarsNoPostponing
    let canonical ← instantiateMVars canonical
    let actual := args[1]!
    let same ← isDefEq actual canonical
    unless same == true do
      throwError "unexpected monoid selection"
    let printed ← withOptions (fun opts => opts.setBool `pp.all true) (ppExpr actual)
    logInfo m!"unit-matrix monoid Expr: {printed}"
    logInfo m!"unit-matrix actual_matrix_monoid = {same}"
abbrev Mat := Matrix (Fin 3) (Fin 3) ℝ
noncomputable def verifiedMatrixMonoid : Monoid Mat := Matrix.semiring.toMonoidWithZero.toMonoid
example (A B : Mat) (i j : Fin 3) :
    (@Mul.mul Mat verifiedMatrixMonoid.toMul A B) i j = ∑ k : Fin 3, A i k * B k j := by rfl
example (i j : Fin 3) :
    (@One.one Mat verifiedMatrixMonoid.toOne) i j = if i = j then 1 else 0 := by rfl
