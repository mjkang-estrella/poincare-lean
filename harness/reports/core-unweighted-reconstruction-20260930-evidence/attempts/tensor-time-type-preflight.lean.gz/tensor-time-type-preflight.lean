import Poincare.Global.DeTurckTensorGraphJet
import Poincare.Global.DeTurckChartIndependentPullback
open scoped BigOperators Topology
#check (
  ∀ (α T : ℝ) (U V : Poincare.DeTurckCoupledForcing.Inputs α T) (phi : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3)
  (J : Poincare.ClosedSmoothModel 3 →L[ℝ] Poincare.ClosedSmoothModel 3) (z : Poincare.ClosedSmoothModel 3) (t : ℝ),
  0 < T → t ∈ Set.Icc 0 T →
  Filter.Eventually
   (fun s => Poincare.DeTurckCoupledForcing.tensorValue U (s,z) =
    Poincare.pullbackBilinearForm
     (Poincare.DeTurckCoupledForcing.tensorValue V (s,phi z)) J)
   (nhdsWithin t (Set.Icc 0 T)) →
  let TT := fun (W : Poincare.DeTurckCoupledForcing.Inputs α T) (p : ℝ × Poincare.ClosedSmoothModel 3) =>
   ∑ a : Fin 3, ∑ b : Fin 3,
    (W (a,b)).ut p • Poincare.DeTurckTensorBasis.tensor a b
  TT U (t,z) = Poincare.pullbackBilinearForm (TT V (t,phi z)) J
)
