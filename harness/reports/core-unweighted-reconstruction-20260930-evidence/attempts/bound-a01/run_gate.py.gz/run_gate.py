from pathlib import Path
import subprocess,sys,json,datetime,time,hashlib,os
root=Path("/Users/mjkang/.codex/worktrees/core-unweighted-bound/poincare")
evidence=Path(__file__).resolve().parent
name=sys.argv[1]
argv=sys.argv[2:]
out=evidence/name
out.mkdir(exist_ok=False)
source=root/"Poincare/Global/BufferedUnweightedGraphTransport.lean"
(out/source.name).write_bytes(source.read_bytes())
(out/"diff.patch").write_bytes(subprocess.run(["git","diff","--",str(source.relative_to(root))],cwd=root,stdout=subprocess.PIPE,check=True).stdout)
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
clock=time.monotonic()
(out/"invocation.json").write_text(json.dumps({"cwd":str(root),"argv":argv,"environment":{"LEAN_NUM_THREADS":"1"},"started_utc":started,"source_sha256":hashlib.sha256(source.read_bytes()).hexdigest()},indent=2)+"\n")
print("Running "+name+": "+str(argv),flush=True)
with (out/"compiler.log").open("xb") as log:
 result=subprocess.run(argv,cwd=root,env=dict(os.environ,LEAN_NUM_THREADS="1"),stdout=log,stderr=subprocess.STDOUT,check=False)
receipt={"exit_code":result.returncode,"started_utc":started,"finished_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"elapsed_seconds":time.monotonic()-clock}
(out/"result.json").write_text(json.dumps(receipt,indent=2)+"\n")
print((out/"compiler.log").read_text(),end="",flush=True)
print(json.dumps(receipt),flush=True)
sys.exit(result.returncode)
