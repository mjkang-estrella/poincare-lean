import Poincare.Global.BufferedUnweightedGraphTransportGerm
import Poincare.Global.DeTurckPrincipalIdentity
import Poincare.Global.BufferedUnweightedGraphTransport
import Poincare.Global.ParabolicGraphTimeJets
import Poincare.Global.ParabolicGraphSupport
import Poincare.Global.MetricAdaptedGlobalParametrix
import Poincare.Global.SmoothInitialMetricExistence
noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 300000
open Set Filter
open scoped Manifold ContDiff Topology
universe u
namespace Poincare.ActualUnweightedTransportApplication
open FiniteAtlasParabolicTensorSpace
example (M : Type u) [TopologicalSpace M] [T2Space M] [CompactSpace M]
    [ChartedSpace (ClosedSmoothModel 3) M]
    [IsManifold (closedSmoothModelWithCorners 3) ∞ M]
    (α : ℝ) (hα : 0 < α) (hα1 : α < 1) :
    ∃ (g0 : ClosedSmoothRiemannianMetric 3 M) (A : AtlasData M)
      (ψ ξ : Fin A.cover.chartCount → ClosedSmoothModel 3 → ℝ)
      (θ : Fin A.cover.chartCount → Fin A.cover.chartCount → ClosedSmoothModel 3 → ℝ)
      (F : Fin A.cover.chartCount → Fin A.cover.chartCount → ClosedSmoothModel 3 → ClosedSmoothModel 3),
    (∀ i, ContDiff ℝ ∞ (ψ i) ∧
      (∀ z ∈ coordSupport A i, ∀ᶠ y in nhds z, ψ i y = 1) ∧
      ContDiff ℝ ∞ (ξ i) ∧ tsupport (ξ i) ⊆ (chart A i).target ∧
      (∀ z ∈ coordSupport A i, ξ i z = 1) ∧
      ∀ z ∈ tsupport (ξ i),
        (CovariantDerivative.chartMetric (I := closedSmoothModelWithCorners 3)
          g0.inner (A.cover.anchor i) z).IsInvertible) ∧
    (∀ i j,
      ContDiff ℝ ∞ (θ i j) ∧ HasCompactSupport (θ i j) ∧
      ContDiff ℝ ∞ (F i j) ∧ HasCompactSupport (F i j) ∧
      tsupport (θ i j) ⊆ ((chart A i).symm.trans (chart A j)).source ∧
      (∀ z ∈ tsupport (θ i j), ∀ᶠ y in nhds z, F i j y = change A i j y) ∧
      ∀ z ∈ (chart A i) '' (tsupport (A.partition i) ∩ (chart A j).symm '' tsupport (ξ j)),
        ∀ᶠ y in nhds z, θ i j y = 1) ∧
    ∃ C : Fin A.cover.chartCount → Fin A.cover.chartCount → Fin 3 → Fin 3 → ℝ,
      (∀ i j c d, 0 ≤ C i j c d) ∧ ∀ T ∈ Ioc (0 : ℝ) 1, ∀ i j c d,
      ∃ B : ((Fin 3 × Fin 3) → Jet α T) →L[ℝ] Jet α T,
        ‖B‖ ≤ C i j c d ∧
        (∀ w p, (B w).u p = ∑ a : Fin 3, ∑ b : Fin 3,
          BufferedUnweightedGraphTransport.weight (θ i j) (ψ i) (ξ j) (F i j) a b c d p.2 *
          (w (a,b)).u (p.1,F i j p.2)) ∧
        (∀ w, ∀ t ∈ Icc 0 T, ∀ z, (B w).ut (t,z) = ∑ a : Fin 3, ∑ b : Fin 3,
          BufferedUnweightedGraphTransport.weight (θ i j) (ψ i) (ξ j) (F i j) a b c d z *
          (w (a,b)).ut (t,F i j z)) ∧
        (∀ w t z, z ∉ tsupport (ψ i) →
          (B w).u (t,z) = 0 ∧ (B w).ut (t,z) = 0 ∧
          (B w).du (t,z) = 0 ∧ (B w).ddu (t,z) = 0) ∧
        ∀ w t z, z ∈ coordSupport A i → ∀ᶠ y in nhds z,
          (B w).u (t,y) =
          (@ite ℝ ((chart A i).symm y ∈ (chart A j).source)
            (Classical.propDecidable _)
            (ξ j (change A i j y) * ∑ a : Fin 3, ∑ b : Fin 3,
              (fderiv ℝ (change A i j) y (EuclideanSpace.basisFun (Fin 3) ℝ c)) a *
              (fderiv ℝ (change A i j) y (EuclideanSpace.basisFun (Fin 3) ℝ d)) b *
              (w (a,b)).u (t,change A i j y)) 0) := by
  classical
  obtain ⟨g0⟩ := SmoothInitialMetricExistence.exists_initial_metric (M := M)
  obtain ⟨A, ψ, ξ, hbuffer, θ, F, hgate, hrest⟩ :=
    MetricAdaptedGlobalParametrix.exists_metric_adapted_global_parametrix g0 α hα hα1
  refine ⟨g0, A, ψ, ξ, θ, F, ?_, ?_, ?_⟩
  · intro i
    refine ⟨(hbuffer i).1, (hbuffer i).2.2.1,
      (hbuffer i).2.2.2.2.1, (hbuffer i).2.2.2.2.2.2.2.2.1, ?_⟩
    constructor
    · intro z hz
      have hψ : ψ i z = 1 := Filter.EventuallyEq.eq_of_nhds ((hbuffer i).2.2.1 z hz)
      have hzψ : z ∈ tsupport (ψ i) := subset_tsupport _ (by simp [Function.mem_support,hψ])
      exact (hbuffer i).2.2.2.2.2.2.2.1 z hzψ
    · intro z hz
      exact DeTurckPrincipalIdentity.chartMetric_isInvertible_of_cutoff g0
        (A.cover.anchor i) z ((hbuffer i).2.2.2.2.2.2.2.2.2 z hz)
  · intro i j
    exact ⟨(hgate i j).1, (hgate i j).2.1, (hgate i j).2.2.2.2.2.1,
      (hgate i j).2.2.2.2.2.2.1, (hgate i j).2.2.2.1,
      (hgate i j).2.2.2.2.2.2.2.1,
      (hgate i j).2.2.2.2.1⟩
  · have hrow (i j : Fin A.cover.chartCount) (c d : Fin 3) :=
      BufferedUnweightedGraphTransport.exists_entry_transport
        (θ i j) (ψ i) (ξ j) (F i j) c d
        (hgate i j).1 (hgate i j).2.1 (hbuffer i).1
        (hbuffer j).2.2.2.2.1 (hgate i j).2.2.2.2.2.1
        (hgate i j).2.2.2.2.2.2.1 α hα hα1
    choose C hC hfamily using hrow
    refine ⟨C,hC,?_⟩
    intro T hT i j c d
    obtain ⟨B,hB,hraw,hsupport⟩ := hfamily i j c d T hT
    refine ⟨B,hB,hraw,?_,?_,?_⟩
    · intro w t ht z
      have htime := ParabolicGraphTimeJets.finite_time_transfer
        (ClosedSmoothModel 3) (Fin 3 × Fin 3) α T (B w) w
        (fun ab => BufferedUnweightedGraphTransport.weight
          (θ i j) (ψ i) (ξ j) (F i j) ab.1 ab.2 c d z)
        z (fun _ => F i j z) hT.1
        (fun s _ => by simpa only [Fintype.sum_prod_type] using hraw w (s,z)) t ht
      simpa only [Fintype.sum_prod_type] using htime
    · intro w t z hz
      have hder := ParabolicGraphSupport.derivatives_zero_off_closed
        (ClosedSmoothModel 3) α T (B w) (tsupport (ψ i))
        (isClosed_tsupport (ψ i)) hT.1
        (fun s _ y hy => hsupport w s y hy) t z hz
      exact ⟨hsupport w t z hz,hder⟩
    · intro w t z hz
      have hg := BufferedUnweightedGraphTransport.weighted_source_germ M A i j
        (θ i j) (ψ i) (ξ j) (F i j) c d
        (hbuffer j).2.2.2.2.2.1 (hbuffer j).2.2.2.2.2.2.2.2.1
        (hgate i j).2.2.2.1 (hgate i j).2.2.2.2.2.2.2.1
        (hgate i j).2.2.2.2.1 (fun ab y => (w ab).u (t,y)) z hz
        ((hbuffer i).2.2.1 z hz)
      filter_upwards [hg] with y hy
      rw [hraw w (t,y)]
      exact hy
end Poincare.ActualUnweightedTransportApplication
