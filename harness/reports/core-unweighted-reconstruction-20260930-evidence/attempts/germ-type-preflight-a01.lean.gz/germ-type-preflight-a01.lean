import Poincare.Global.BufferedUnweightedGraphTransportDefinitions

noncomputable section
set_option autoImplicit false
open Set Filter
open scoped Manifold ContDiff Topology
universe u

def Poincare.UnweightedGermTypePreflight : Prop :=
∀ (M : Type u) [TopologicalSpace M] [T2Space M]
[ChartedSpace (Poincare.ClosedSmoothModel 3) M]
[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]
(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M)
(i j : Fin A.cover.chartCount) (θ ψ ξ : Poincare.ClosedSmoothModel 3 → ℝ)
(F : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3)
(c d : Fin 3),
HasCompactSupport ξ →
tsupport ξ ⊆ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).target →
tsupport θ ⊆ ((Poincare.FiniteAtlasParabolicTensorSpace.chart A i).symm.trans
 (Poincare.FiniteAtlasParabolicTensorSpace.chart A j)).source →
(∀ v ∈ tsupport θ, ∀ᶠ y in nhds v,
 F y = Poincare.FiniteAtlasParabolicTensorSpace.change A i j y) →
(∀ v ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i) ''
 (tsupport (A.partition i) ∩
  (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).symm '' tsupport ξ),
 ∀ᶠ y in nhds v, θ y = 1) →
∀ (f : (Fin 3 × Fin 3) → Poincare.ClosedSmoothModel 3 → ℝ)
 (z : Poincare.ClosedSmoothModel 3),
z ∈ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A i →
(∀ᶠ y in nhds z, ψ y = 1) →
∀ᶠ y in nhds z,
 (∑ a : Fin 3, ∑ b : Fin 3,
  Poincare.BufferedUnweightedGraphTransport.weight θ ψ ξ F a b c d y *
   f (a,b) (F y)) =
 (@ite ℝ
  ((Poincare.FiniteAtlasParabolicTensorSpace.chart A i).symm y ∈
   (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).source)
  (Classical.propDecidable _)
  (ξ (Poincare.FiniteAtlasParabolicTensorSpace.change A i j y) *
   ∑ a : Fin 3, ∑ b : Fin 3,
    (fderiv ℝ (Poincare.FiniteAtlasParabolicTensorSpace.change A i j) y
      ((EuclideanSpace.basisFun (Fin 3) ℝ) c)) a *
    (fderiv ℝ (Poincare.FiniteAtlasParabolicTensorSpace.change A i j) y
      ((EuclideanSpace.basisFun (Fin 3) ℝ) d)) b *
    f (a,b) (Poincare.FiniteAtlasParabolicTensorSpace.change A i j y)) 0)
