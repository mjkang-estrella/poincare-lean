from pathlib import Path
import json,gzip,hashlib,datetime
root=Path('.');state=root/'harness/v2/state/core-unweighted-reconstruction-20260930';receipt=json.loads((root/'harness/v2/state/verification/latest.json').read_text());checkpoint=root/receipt['evidence_directory']
assert receipt['identity']['head']=='d7fa0fa86cd8fc094d0fddf25269d183e26d42df'
assert receipt['identity']['clean']
assert all(v['exit_code']==(1 if k=='completion' else 0) for k,v in receipt['phases'].items())
fails=[x for x in (checkpoint/'completion.out').read_text().splitlines() if x.startswith('FAIL:')]
assert len(fails)==2 and all('poincare_conjecture' in x for x in fails),fails
archive=root/'harness/reports/core-unweighted-reconstruction-20260930-evidence';archive.mkdir(exist_ok=False);entries=[]
def save(src,dest):
 data=src.read_bytes();packed=gzip.compress(data,mtime=0);out=archive/dest;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(packed)
 entries.append({'source':str(src),'archive':str(dest),'source_sha256':hashlib.sha256(data).hexdigest(),'archive_sha256':hashlib.sha256(packed).hexdigest(),'source_bytes':len(data)})
for path in sorted(state.rglob('*')):
 if path.is_file() and '__pycache__' not in path.parts:save(path,Path('attempts')/path.relative_to(state).with_suffix(path.suffix+'.gz'))
for path in sorted(checkpoint.rglob('*')):
 if path.is_file():save(path,Path('checkpoint')/path.relative_to(checkpoint).with_suffix(path.suffix+'.gz'))
save(root/'harness/v2/state/verification/latest.json',Path('checkpoint/receipt.json.gz'))
save(root/'harness/v2/state/external-proof-review-20260930/source-review.json',Path('external-review/source-review.json.gz'))
manifest={'schema_version':1,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_checkpoint':receipt['identity']['head'],'source_sha256':receipt['identity']['source_sha256'],'backend':'local Codex helpers; not registered Pi/Leanstral Jobs','completion_certified':False,'phase_exit_codes':{k:v['exit_code'] for k,v in receipt['phases'].items()},'completion_failures':fails,'entries':entries}
(archive/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for e in entries:
 packed=(archive/e['archive']).read_bytes();data=gzip.decompress(packed)
 assert hashlib.sha256(packed).hexdigest()==e['archive_sha256']
 assert hashlib.sha256(data).hexdigest()==e['source_sha256']
 assert data==Path(e['source']).read_bytes()
p=root/'harness/reports/core-unweighted-reconstruction-20260930.md'
with p.open('a') as f:
 f.write('\n## Sealed integration checkpoint\n\nClean checked source: `'+receipt['identity']['head']+'`.\n\nSource SHA256: `'+receipt['identity']['source_sha256']+'`.\n\n')
 f.write('Full build and every integration audit passed. Completion exited 1 only\nfor the absent reserved theorem and the failed exact final-declaration probe.\nPoincare.poincare_conjecture : Poincare.PoincareConjectureStatement remains\nabsent. Both universal cores remain open.\n\n')
 f.write('All compiler attempts and checkpoint artifacts are sealed in the adjacent\nevidence archive. Original/gzip hashes were independently checked against\nretained originals. Final evidence/status changes preserve the checked source.\n')
print('Original and compressed evidence hashes verified')
print('Completion failures:',fails)
