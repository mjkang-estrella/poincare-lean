#!/usr/bin/env python3
import datetime, hashlib, json, os, pathlib, subprocess, sys, time
root = pathlib.Path("/Users/mjkang/.codex/worktrees/core-graph-time-jets/poincare")
artifacts = pathlib.Path(__file__).parent
label, *argv = sys.argv[1:]
run = artifacts / label
run.mkdir(exist_ok=False)
source = root / "Poincare/Global/ParabolicGraphTimeJets.lean"
blob = source.read_bytes()
(run / source.name).write_bytes(blob)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
with (run / "compiler.log").open("wb") as output:
    result = subprocess.run(argv, cwd=root, stdout=output, stderr=subprocess.STDOUT)
metadata = {"argv": argv, "cwd": str(root), "started_utc": started,
    "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "wall_seconds": time.monotonic() - start, "exit_code": result.returncode,
    "source_sha256": hashlib.sha256(blob).hexdigest(),
    "base_commit": "a069fcc55c818e2e227f123c3b98cebe263dc38a"}
(run / "result.json").write_text(json.dumps(metadata, indent=2) + "\n")
print(json.dumps(metadata))
print((run / "compiler.log").read_text())
sys.exit(result.returncode)
