# Graph time-jet worker result

Local Codex helper, not a registered Pi/Leanstral Job. Root independently decides acceptance and merge.

Base: a069fcc55c818e2e227f123c3b98cebe263dc38a
Branch: codex/core-graph-time-jets-a01
Commit: 870a6d5489834890df6b9714590aa55d7ef7755d
Owned source: Poincare/Global/ParabolicGraphTimeJets.lean
Source SHA256: 43ffec79a69f5783244c6a510af7f9e2c6c662e407c3dd56a97166b79520756f

The exact finite_time_transfer target is proved for independent E/iota universes and arbitrary finite index type from Graph.hasDeriv_time, static finite-sum derivatives, and congr_of_mem. Positive Icc uniqueness covers endpoints.

The exact tensor_time_covariance target is proved with its literal inline TT and all nine ordered entries. Extensionality in both bilinear slots reduces covariance to scalar finite-sum derivatives. The within-time eventual value equality transports the second certificate through congr_of_eventuallyEq_of_mem. phi(z) and J remain fixed in time; no ordinary derivatives, joint C3, spatial regularity, derivative package, norm or topology change is introduced.

All four acceptance commands exited 0. compile-001 is the only source compiler attempt, 15.0309 seconds. frozen-001 took 12.3972 seconds and passed both declaration/type/universe and permitted-axiom checks. Its target-only build replayed dependency warnings and built the new leaf in 2.9 seconds. No full/root build was run by this helper.

No source changed outside the owned module. Copied Task/contract metadata remains untracked and unchanged. Failed proof evidence is absent because the first proof compiled successfully. Full source snapshots, argv, UTC times, exit codes, logs, and precommit/committed diffs are preserved under this directory. No acceptance, merge, main edit, service action, or deletion was performed.

Exact next action for root: independently rerun the frozen time-jets Task gate against commit 870a6d5489834890df6b9714590aa55d7ef7755d from the recorded base, inspect its single-file diff, then decide acceptance before integration.
