import Poincare.Global.ParabolicSolutionGraph
import Mathlib.Analysis.Calculus.Deriv.Add
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.Calculus.FDeriv.Const

noncomputable section
open Set Filter
open scoped Topology BigOperators
universe u v
namespace GraphTimeSupportProbe
open Poincare.ParabolicSolutionGraph

variable {E : Type u} [NormedAddCommGroup E] [NormedSpace ℝ E]
variable {ι : Type v} [Fintype ι] {α T : ℝ}

theorem finite_time_transfer (G : Graph (E := E) α T)
    (W : ι → Graph (E := E) α T) (a : ι → ℝ) (x : E) (xs : ι → E)
    (hT : 0 < T) (hvalue : ∀ s ∈ Icc 0 T,
      G.u (s,x) = ∑ i, a i * (W i).u (s,xs i))
    {t : ℝ} (ht : t ∈ Icc 0 T) :
    G.ut (t,x) = ∑ i, a i * (W i).ut (t,xs i) := by
  classical
  have hsum : HasDerivWithinAt (fun s : ℝ => ∑ i, a i * (W i).u (s,xs i))
      (∑ i, a i * (W i).ut (t,xs i)) (Icc 0 T) t :=
    HasDerivWithinAt.fun_sum (fun i _ => ((W i).hasDeriv_time t ht (xs i)).const_mul (a i))
  exact (uniqueDiffOn_Icc hT t ht).eq_deriv (Icc 0 T)
    (G.hasDeriv_time t ht x) (hsum.congr_of_mem hvalue ht)

theorem finite_time_transfer_germ (G : Graph (E := E) α T)
    (W : ι → Graph (E := E) α T) (a : ι → ℝ) (x : E) (xs : ι → E)
    (hT : 0 < T) {t : ℝ} (ht : t ∈ Icc 0 T)
    (hvalue : (fun s : ℝ => G.u (s,x)) =ᶠ[𝓝[Icc 0 T] t]
      (fun s : ℝ => ∑ i, a i * (W i).u (s,xs i))) :
    G.ut (t,x) = ∑ i, a i * (W i).ut (t,xs i) := by
  classical
  have hsum : HasDerivWithinAt (fun s : ℝ => ∑ i, a i * (W i).u (s,xs i))
      (∑ i, a i * (W i).ut (t,xs i)) (Icc 0 T) t :=
    HasDerivWithinAt.fun_sum (fun i _ => ((W i).hasDeriv_time t ht (xs i)).const_mul (a i))
  exact (uniqueDiffOn_Icc hT t ht).eq_deriv (Icc 0 T)
    (G.hasDeriv_time t ht x) (hsum.congr_of_eventuallyEq_of_mem hvalue ht)

theorem closed_support_derivatives (G : Graph (E := E) α T)
    (K : Set E) (hK : IsClosed K) (hT : 0 < T)
    (hu : ∀ s ∈ Icc 0 T, ∀ y : E, y ∉ K → G.u (s,y) = 0)
    {t : ℝ} (ht : t ∈ Icc 0 T) {x : E} (hx : x ∉ K) :
    G.ut (t,x) = 0 ∧ G.du (t,x) = 0 ∧ G.ddu (t,x) = 0 := by
  have hdu (y : E) (hy : y ∉ K) : G.du (t,y) = 0 := by
    have hv : (fun z : E => G.u (t,z)) =ᶠ[𝓝 y] (fun _ => (0 : ℝ)) := by
      filter_upwards [hK.isOpen_compl.mem_nhds hy] with z hz
      exact hu t ht z hz
    exact (G.hasFDeriv t ht y).unique
      ((hasFDerivAt_const (0 : ℝ) y).congr_of_eventuallyEq hv)
  have hut : G.ut (t,x) = 0 := by
    exact (uniqueDiffOn_Icc hT t ht).eq_deriv (Icc 0 T)
      (G.hasDeriv_time t ht x)
      ((hasDerivWithinAt_const t (Icc 0 T) (0 : ℝ)).congr_of_mem
        (fun s hs => hu s hs x hx) ht)
  have hdv : (fun z : E => G.du (t,z)) =ᶠ[𝓝 x] (fun _ => (0 : E →L[ℝ] ℝ)) := by
    filter_upwards [hK.isOpen_compl.mem_nhds hx] with z hz
    exact hdu z hz
  exact ⟨hut, hdu x hx, (G.hasFDeriv_du t ht x).unique
    ((hasFDerivAt_const (0 : E →L[ℝ] ℝ) x).congr_of_eventuallyEq hdv)⟩


theorem closed_support_derivatives_all_time (G : Graph (E := E) α T)
    (K : Set E) (hK : IsClosed K) (hT : 0 < T)
    (hu : ∀ s : ℝ, ∀ y : E, y ∉ K → G.u (s,y) = 0)
    (t : ℝ) {x : E} (hx : x ∉ K) :
    G.ut (t,x) = 0 ∧ G.du (t,x) = 0 ∧ G.ddu (t,x) = 0 := by
  by_cases ht : t ∈ Icc 0 T
  · exact closed_support_derivatives G K hK hT (fun s _ y hy => hu s y hy) ht hx
  · have hp : (t,x) ∉ Poincare.ParabolicHolder.cylinder T := fun hp => ht hp.1
    exact ⟨Poincare.ParabolicHolder.zero_off G.ut hp,
      Poincare.ParabolicHolder.zero_off G.du hp,
      Poincare.ParabolicHolder.zero_off G.ddu hp⟩

end GraphTimeSupportProbe
