# Local Codex helper result

Exact frozen declaration `Poincare.BufferedUnweightedGraphTransport.weighted_source_germ` proved.

The proof uses the compact closed manifold carrier `(chart A j).symm '' tsupport ξ`. On the carrier, the coordinate-support witness enters the original gate set and supplies the theta-one germ, map and derivative agreement, psi-one germ and true source branch. Off the carrier, a complement neighborhood forces the true buffered branch to zero; nonzero theta supplies a genuine overlap and map agreement, forcing the extended branch to zero too. No regularity/support assumption on f or stronger gate was added.

Only `Poincare/Global/BufferedUnweightedGraphTransportGerm.lean` changed. Copied metadata remains unchanged and untracked.

Verification: compiler-002 exit 0; exact frozen-contract-001 exit 0, including narrow Lake target build, AXIOM_CONTRACT_OK and FROZEN_CONTRACT_OK; token-002 exit 0; exact-diff-check-003 and staged-diff-check-001 exit 0. compiler-001 preserves the failed elaboration attempt. Every compiler attempt includes source, diff, stdout, stderr, argv, start/end and exit.

Commit: a45ff461a1d20e644dfd9b9d5ab6084233c68c29

This is a local helper result for independent root review; no task was accepted, merged or marked complete. No root, frozen definition, contract, target, norm or service was changed.

First action for root: independently rerun the four frozen gates in this worktree from base a069fcc55c818e2e227f123c3b98cebe263dc38a and inspect this single-module diff.
