import Poincare.Global.DeTurckTensorGraphJet
import Poincare.Global.DeTurckChartIndependentPullback

noncomputable section
open Set Filter
open scoped Topology BigOperators
namespace GraphTensorTimeProbe
open Poincare Poincare.DeTurckPrincipalSecondJet Poincare.DeTurckCoupledForcing

local instance tensorTimeProbeBilinBoundedSMul : IsBoundedSMul ℝ Bilin :=
  .of_norm_smul_le (fun c A => ContinuousLinearMap.opNorm_smul_le c A)

variable {α T : ℝ}

def tensorTimeValue (W : Inputs α T) (p : ℝ × E) : Bilin :=
  ∑ a : Fin 3, ∑ b : Fin 3, (W (a,b)).ut p • DeTurckTensorBasis.tensor a b

theorem tensorTime_hasDerivWithinAt (W : Inputs α T) {t : ℝ}
    (ht : t ∈ Icc 0 T) (z : E) :
    HasDerivWithinAt (fun s : ℝ => tensorValue W (s,z))
      (tensorTimeValue W (t,z)) (Icc 0 T) t := by
  unfold tensorValue tensorTimeValue
  exact HasDerivWithinAt.fun_sum (fun a _ => HasDerivWithinAt.fun_sum (fun b _ =>
    ((W (a,b)).hasDeriv_time t ht z).smul_const (DeTurckTensorBasis.tensor a b)))

theorem tensorTime_pullback_covariance (U V : Inputs α T)
    (hT : 0 < T) (phi : E → E) (J : E →L[ℝ] E) (z : E)
    {t : ℝ} (ht : t ∈ Icc 0 T)
    (hvalue : (fun s : ℝ => tensorValue U (s,z)) =ᶠ[𝓝[Icc 0 T] t]
      (fun s : ℝ => pullbackBilinearForm (tensorValue V (s,phi z)) J)) :
    tensorTimeValue U (t,z) = pullbackBilinearForm (tensorTimeValue V (t,phi z)) J := by
  ext v w
  have hU : HasDerivWithinAt (fun s : ℝ => tensorValue U (s,z) v w)
      (tensorTimeValue U (t,z) v w) (Icc 0 T) t := by
    simpa only [tensorValue, tensorTimeValue, ContinuousLinearMap.sum_apply,
      ContinuousLinearMap.smul_apply, smul_eq_mul] using
      (HasDerivWithinAt.fun_sum (fun a (_ : a ∈ Finset.univ) =>
        HasDerivWithinAt.fun_sum (fun b (_ : b ∈ Finset.univ) =>
          ((U (a,b)).hasDeriv_time t ht z).mul_const (DeTurckTensorBasis.tensor a b v w))))
  have hV : HasDerivWithinAt (fun s : ℝ => tensorValue V (s,phi z) (J v) (J w))
      (tensorTimeValue V (t,phi z) (J v) (J w)) (Icc 0 T) t := by
    simpa only [tensorValue, tensorTimeValue, ContinuousLinearMap.sum_apply,
      ContinuousLinearMap.smul_apply, smul_eq_mul] using
      (HasDerivWithinAt.fun_sum (fun a (_ : a ∈ Finset.univ) =>
        HasDerivWithinAt.fun_sum (fun b (_ : b ∈ Finset.univ) =>
          ((V (a,b)).hasDeriv_time t ht (phi z)).mul_const
            (DeTurckTensorBasis.tensor a b (J v) (J w)))))
  have heq : (fun s : ℝ => tensorValue U (s,z) v w) =ᶠ[𝓝[Icc 0 T] t]
      (fun s : ℝ => tensorValue V (s,phi z) (J v) (J w)) := by
    filter_upwards [hvalue] with s hs
    exact congrArg (fun B : Bilin => B v w) hs
  exact (uniqueDiffOn_Icc hT t ht).eq_deriv (Icc 0 T) hU
    (hV.congr_of_eventuallyEq_of_mem heq ht)

end GraphTensorTimeProbe
