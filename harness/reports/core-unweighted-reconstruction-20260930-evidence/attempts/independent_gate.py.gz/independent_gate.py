import json,subprocess,sys,time,hashlib
from pathlib import Path
root=Path('/Users/mjkang/.codex/worktrees/incremental-verification/poincare')
slug=sys.argv[1];wt=Path(sys.argv[2]);d=root/f'harness/v2/state/core-unweighted-reconstruction-20260930/independent-{slug}-a01';d.mkdir(exist_ok=False)
t=json.loads((root/f'harness/v2/tasks/core-input-20260930-unweighted-{slug}.json').read_text());base=t['base_commit']
changed=subprocess.check_output(['git','diff','--name-only',base,'HEAD'],cwd=wt,text=True).splitlines()
assert changed==t['scope']['allowed_paths'],changed
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=wt,text=True).strip()
allowed_context=set(t['context']['files'])|{f'harness/v2/tasks/{t["id"]}.json',f'harness/v2/contracts/core-unweighted-reconstruction-20260930/{slug}.contract.json'}
for p in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=wt,text=True).splitlines():
 assert p in allowed_context,p
 assert (wt/p).read_bytes()==(root/p).read_bytes(),p
(d/'task.snapshot.json').write_text(json.dumps(t,indent=2)+'\n')
(d/'final.diff').write_bytes(subprocess.check_output(['git','diff',base,'HEAD'],cwd=wt))
for p in changed:(d/Path(p).name).write_bytes((wt/p).read_bytes())
result={'task':t['id'],'base_commit':base,'worker_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt,text=True).strip(),'changed_files':changed,'backend':'local Codex helper; not registered Pi/Leanstral Job','gates':[]}
for i,command in enumerate(t['acceptance']['commands']):
 now=time.time();run=subprocess.run(command,cwd=wt,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (d/f'{i}.log').write_bytes(run.stdout)
 entry={'command':command,'exit_code':run.returncode,'seconds':time.time()-now,'log_sha256':hashlib.sha256(run.stdout).hexdigest()}
 (d/f'{i}.json').write_text(json.dumps(entry,indent=2)+'\n');result['gates'].append(entry)
 (d/'review.json').write_text(json.dumps(result,indent=2)+'\n')
 print(slug,i,run.returncode,round(entry['seconds'],2),flush=True)
 if run.returncode:sys.exit(run.returncode)
print('INDEPENDENT_GATE_PASSED',slug,flush=True)
