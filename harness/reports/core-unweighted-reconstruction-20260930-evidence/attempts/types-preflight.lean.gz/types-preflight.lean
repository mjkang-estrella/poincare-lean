import Poincare.Global.BufferedUnweightedGraphTransportDefinitions
import Mathlib.Analysis.Calculus.Deriv.Add
import Mathlib.Analysis.Calculus.Deriv.Mul
open scoped ContDiff Topology BigOperators
universe u v
#check (
  ∀ (θ ψ ξ : Poincare.ClosedSmoothModel 3 → ℝ) (F : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3) (c d : Fin 3),
  ContDiff ℝ ((⊤ : ENat) : WithTop ENat) θ → HasCompactSupport θ →
  ContDiff ℝ ((⊤ : ENat) : WithTop ENat) ψ →
  ContDiff ℝ ((⊤ : ENat) : WithTop ENat) ξ →
  ContDiff ℝ ((⊤ : ENat) : WithTop ENat) F → HasCompactSupport F →
  ∀ α : ℝ, 0 < α → α < 1 →
  ∃ C : ℝ, 0 ≤ C ∧ ∀ T ∈ Set.Ioc (0 : ℝ) 1,
  ∃ B : ((Fin 3 × Fin 3) → (Poincare.ParabolicSolutionGraph.Graph (E := Poincare.ClosedSmoothModel 3) α T)) →L[ℝ] (Poincare.ParabolicSolutionGraph.Graph (E := Poincare.ClosedSmoothModel 3) α T),
  ‖B‖ ≤ C ∧
  (∀ w p, (B w).u p = ∑ a : Fin 3, ∑ b : Fin 3,
   Poincare.BufferedUnweightedGraphTransport.weight θ ψ ξ F a b c d p.2 *
   (w (a,b)).u (p.1,F p.2)) ∧
  ∀ w t z, z ∉ tsupport ψ → (B w).u (t,z) = 0
)
#check (
  ∀ (E : Type u) [NormedAddCommGroup E] [NormedSpace ℝ E]
  (α T : ℝ) (G : Poincare.ParabolicSolutionGraph.Graph (E := E) α T)
  (K : Set E), IsClosed K → 0 < T →
  (∀ s ∈ Set.Icc 0 T, ∀ y : E, y ∉ K → G.u (s,y) = 0) →
  ∀ (t : ℝ) (x : E), x ∉ K →
   G.ut (t,x) = 0 ∧ G.du (t,x) = 0 ∧ G.ddu (t,x) = 0
)
#check (
  ∀ (E : Type u) [NormedAddCommGroup E] [NormedSpace ℝ E]
  (ι : Type v) [Fintype ι] (α T : ℝ)
  (G : Poincare.ParabolicSolutionGraph.Graph (E := E) α T)
  (W : ι → Poincare.ParabolicSolutionGraph.Graph (E := E) α T)
  (a : ι → ℝ) (x : E) (xs : ι → E), 0 < T →
  (∀ s ∈ Set.Icc 0 T, G.u (s,x) = ∑ i, a i * (W i).u (s,xs i)) →
  ∀ t ∈ Set.Icc 0 T, G.ut (t,x) = ∑ i, a i * (W i).ut (t,xs i)
)
