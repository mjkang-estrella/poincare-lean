import Poincare.Global.BufferedTensorGraphTransportOperator
import Poincare.Global.DeTurckCoupledForcingDefinitions
import Poincare.Global.DeTurckChartIndependentPullback

noncomputable section
set_option autoImplicit false
open Set Filter
open scoped Manifold ContDiff Topology

namespace Poincare.UnweightedContractProbe
open FiniteAtlasParabolicTensorSpace
universe u

def unweightedWeight
    (θ ψ ξ : ClosedSmoothModel 3 → ℝ)
    (F : ClosedSmoothModel 3 → ClosedSmoothModel 3)
    (a b c d : Fin 3) (z : ClosedSmoothModel 3) : ℝ :=
  θ z * (ψ z * ξ (F z) *
    (fderiv ℝ F z (EuclideanSpace.basisFun (Fin 3) ℝ c)) a *
    (fderiv ℝ F z (EuclideanSpace.basisFun (Fin 3) ℝ d)) b)

def BoundObjective : Prop :=
  ∀ (θ ψ ξ : ClosedSmoothModel 3 → ℝ)
    (F : ClosedSmoothModel 3 → ClosedSmoothModel 3) (c d : Fin 3),
  ContDiff ℝ ∞ θ → HasCompactSupport θ →
  ContDiff ℝ ∞ ψ → ContDiff ℝ ∞ ξ →
  ContDiff ℝ ∞ F → HasCompactSupport F →
  ∀ α : ℝ, 0 < α → α < 1 →
  ∃ C : ℝ, 0 ≤ C ∧ ∀ T ∈ Ioc (0 : ℝ) 1,
  ∃ H : GlobalParametrixAssembly.SourceGraphs α T →L[ℝ] Jet α T,
    ‖H‖ ≤ C ∧
    ∀ w p, (H w).u p = ∑ a : Fin 3, ∑ b : Fin 3,
      unweightedWeight θ ψ ξ F a b c d p.2 * (w (a,b)).u (p.1, F p.2)

variable {M : Type u} [TopologicalSpace M]
  [ChartedSpace (ClosedSmoothModel 3) M]
  [IsManifold (closedSmoothModelWithCorners 3) ∞ M]

def sourceEntry {α T : ℝ} (A : AtlasData M)
    (i j : Fin A.cover.chartCount) (ξ : ClosedSmoothModel 3 → ℝ)
    (w : GlobalParametrixAssembly.SourceGraphs α T)
    (c d : Fin 3) (t : ℝ) (z : ClosedSmoothModel 3) : ℝ :=
  let x := (chart A i).symm z
  @ite ℝ (x ∈ (chart A j).source) (Classical.propDecidable _)
    (ξ (chart A j x) * ∑ a : Fin 3, ∑ b : Fin 3,
      jac A i j x a c * jac A i j x b d * (w (a,b)).u (t, chart A j x)) 0

def sourceTensor {α T : ℝ} (A : AtlasData M)
    (i j : Fin A.cover.chartCount) (ξ : ClosedSmoothModel 3 → ℝ)
    (w : GlobalParametrixAssembly.SourceGraphs α T)
    (t : ℝ) (z : ClosedSmoothModel 3) : Bilin :=
  let x := (chart A i).symm z
  @ite Bilin (x ∈ (chart A j).source) (Classical.propDecidable _)
    (ξ (chart A j x) • pullbackBilinearForm
      (DeTurckCoupledForcing.tensorValue w (t, chart A j x))
      (fderiv ℝ (change A i j) z)) 0

def GermObjective : Prop :=
  ∀ (M : Type u) [TopologicalSpace M] [T2Space M]
    [ChartedSpace (ClosedSmoothModel 3) M]
    [IsManifold (closedSmoothModelWithCorners 3) ∞ M]
    (A : AtlasData M) (i j : Fin A.cover.chartCount)
    (θ ψ ξ : ClosedSmoothModel 3 → ℝ)
    (F : ClosedSmoothModel 3 → ClosedSmoothModel 3),
  HasCompactSupport ξ → tsupport ξ ⊆ (chart A j).target →
  (∀ z ∈ coordSupport A i, ∀ᶠ y in nhds z, ψ y = 1) →
  tsupport θ ⊆ ((chart A i).symm.trans (chart A j)).source →
  (∀ z ∈ (chart A i) ''
    (tsupport (A.partition i) ∩ (chart A j).symm '' tsupport ξ),
    ∀ᶠ y in nhds z, θ y = 1) →
  (∀ z ∈ tsupport θ, ∀ᶠ y in nhds z, F y = change A i j y) →
  ∀ (α T : ℝ) (c d : Fin 3)
    (H : GlobalParametrixAssembly.SourceGraphs α T →L[ℝ] Jet α T),
  (∀ w p, (H w).u p = ∑ a : Fin 3, ∑ b : Fin 3,
    unweightedWeight θ ψ ξ F a b c d p.2 * (w (a,b)).u (p.1, F p.2)) →
  ∀ z ∈ coordSupport A i, ∀ᶠ y in nhds z, ∀ w t,
    (H w).u (t,y) = sourceEntry A i j ξ w c d t y

def TensorGermObjective : Prop :=
  ∀ (M : Type u) [TopologicalSpace M]
    [ChartedSpace (ClosedSmoothModel 3) M]
    [IsManifold (closedSmoothModelWithCorners 3) ∞ M]
    (A : AtlasData M) (i j : Fin A.cover.chartCount)
    (ξ : ClosedSmoothModel 3 → ℝ) (α T : ℝ)
    (H : Fin 3 → Fin 3 →
      GlobalParametrixAssembly.SourceGraphs α T →L[ℝ] Jet α T),
  (∀ c d z, z ∈ coordSupport A i → ∀ᶠ y in nhds z, ∀ w t,
    (H c d w).u (t,y) = sourceEntry A i j ξ w c d t y) →
  ∀ z ∈ coordSupport A i, ∀ᶠ y in nhds z, ∀ w t,
    DeTurckCoupledForcing.tensorValue (fun cd => H cd.1 cd.2 w) (t,y) =
      sourceTensor A i j ξ w t y

end Poincare.UnweightedContractProbe
