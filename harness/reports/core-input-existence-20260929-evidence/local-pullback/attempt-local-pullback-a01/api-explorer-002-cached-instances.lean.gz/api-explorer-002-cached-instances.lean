import Poincare.Global.SmoothInitialMetricDefinitions
open Bundle FiberBundle Set
open scoped Manifold ContDiff Topology
noncomputable section
set_option autoImplicit false
universe u
open Poincare Poincare.SmoothInitialMetricDefinitions
variable {M : Type u} [TopologicalSpace M]
  [ChartedSpace (ClosedSmoothModel 3) M]
  [IsManifold (closedSmoothModelWithCorners 3) ∞ M]
example (p : M) : True := by
  letI : NormedAddCommGroup (ClosedSmoothModel 3 →L[ℝ] ℝ) :=
    ContinuousLinearMap.toNormedAddCommGroup
  letI : NormedSpace ℝ (ClosedSmoothModel 3 →L[ℝ] ℝ) :=
    ContinuousLinearMap.toNormedSpace
  letI : NormedAddCommGroup (ClosedSmoothModel 3 →L[ℝ] ClosedSmoothModel 3 →L[ℝ] ℝ) :=
    ContinuousLinearMap.toNormedAddCommGroup
  letI : NormedSpace ℝ (ClosedSmoothModel 3 →L[ℝ] ClosedSmoothModel 3 →L[ℝ] ℝ) :=
    ContinuousLinearMap.toNormedSpace
  letI : ∀ x : M, TopologicalSpace (TangentSpace (closedSmoothModelWithCorners 3) x →L[ℝ] ℝ) :=
    fun x ↦ ContinuousLinearMap.topologicalSpace
  letI : ∀ x : M, IsTopologicalAddGroup (TangentSpace (closedSmoothModelWithCorners 3) x →L[ℝ] ℝ) :=
    fun x ↦ ContinuousLinearMap.topologicalAddGroup
  letI : ∀ x : M, ContinuousSMul ℝ (TangentSpace (closedSmoothModelWithCorners 3) x →L[ℝ] ℝ) :=
    fun x ↦ ContinuousLinearMap.continuousSMul
  let eBil := trivializationAt
    (ClosedSmoothModel 3 →L[ℝ] ClosedSmoothModel 3 →L[ℝ] ℝ)
    (fun x : M ↦ TangentSpace (closedSmoothModelWithCorners 3) x →L[ℝ]
      TangentSpace (closedSmoothModelWithCorners 3) x →L[ℝ] ℝ) p
  have hbase : eBil.baseSet = (trivializationAt (ClosedSmoothModel 3)
    (TangentSpace (closedSmoothModelWithCorners 3)) p).baseSet := by
    simp [eBil, hom_trivializationAt_baseSet]
  have h := eBil.contMDiffOn_section_baseSet_iff
    (IB := closedSmoothModelWithCorners 3) (n := ∞)
    (E := fun x : M ↦ TangentSpace (closedSmoothModelWithCorners 3) x →L[ℝ]
      TangentSpace (closedSmoothModelWithCorners 3) x →L[ℝ] ℝ)
    (s := localEuclideanInner p)
  exact True.intro
