import Poincare.Global.SmoothInitialMetricLocalPullback
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let some idx := env.getModuleIdx? `Poincare.Global.SmoothInitialMetricLocalPullback
    | throwError "module not found"
  let mut bad : Array String := #[]
  let mut count := 0
  for (n, _) in env.constants.map₁.toList do
    if env.getModuleIdxFor? n == some idx then
      let axs ← liftCoreM (collectAxioms n)
      count := count + 1
      for ax in axs do
        unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do
          bad := bad.push s!"{n}: {axs}"
  logInfo m!"ALL_EMITTED_AXIOMS count={count} bad={bad}"
  unless bad.isEmpty do throwError "unexpected axioms"
