# Local pullback helper result

Date: 2026-09-29. Task: core-input-20260929-local-pullback.
This is a local Codex helper attempt, not a registered Pi/Leanstral runtime Job.
The proof is ready for independent orchestrator review. No Task acceptance or merge was performed.

Base: `d1691e7037f70a153a4e7b5c3bb1e2d267efc6c6`. Branch: `codex/core-initial-metric-local-a01`.
Proof commit: `16e07d4c08bd00750dee8acca8a07ed4e61ea14a`.
Only `Poincare/Global/SmoothInitialMetricLocalPullback.lean` is committed, adding 92 lines.
Source SHA-256: `43d4c85596102b2e06e4688ddee19b1d5dd830aa4e5c83409cc5dad4158727bd`.
The untracked orchestrator-supplied Task file is preserved.

The three frozen deliverables are proved with their exact reviewed types:

- `Poincare.SmoothInitialMetricLocalPullback.localEuclideanInner_symm`
- `Poincare.SmoothInitialMetricLocalPullback.localEuclideanInner_pos`
- `Poincare.SmoothInitialMetricLocalPullback.localEuclideanInner_contMDiffOn`

The additional named lemma `localEuclideanInner_coordinates` proves that the actual bilinear section has constant Euclidean inner-product coordinates in the nested Hom trivialization on the tangent trivialization's base set. Symmetry uses real inner-product symmetry globally. Strict positivity uses the inverse chart map to exclude a zero coordinate image of a nonzero tangent vector. Bundle smoothness follows from the constant coordinate identity and `Trivialization.contMDiffOn_section_baseSet_iff`.

No global metric, curvature, sphere identification, or extra hypothesis is supplied. The shared definition and the frozen targets are unchanged. Local positivity and smoothness retain their base-set restrictions. These helpers supply local sections to the pending partition-of-unity initial metric construction; they do not prove Ricci-flow existence, convergence, universal Hamilton input existence, or the Poincare conjecture.

Verification passed:

- Fresh source elaboration with `LEAN_NUM_THREADS=1 lake env lean Poincare/Global/SmoothInitialMetricLocalPullback.lean`, recorded in `compile-007.log`.
- The Task's `frozen_contract_audit.py` gate, including the targeted module build and all three rigid frozen type and axiom contracts, recorded in `frozen-gate-001.log` and JSON.
- The internal-inclusive module-index scan recorded `ALL_EMITTED_AXIOMS count=5 bad=[]`. Every emitted declaration has an axiom set contained in `propext`, `Classical.choice`, and `Quot.sound`, allowing empty sets.
- Forbidden-token, base-relative scope, and `git diff --check` gates, recorded in `static-gates.json` and logs.

The module scopes its larger compiler search limits to the coordinate lemma and nested bundle smoothness theorem. The API explorer separately preserved a default-limit instance-cache proof probe as possible later optimization; it is not part of this diff.

All six failed source compiler checks and the corresponding source snapshots are preserved, together with the successful final check. Both read-only API probe sources, their exact combined compiler stdout/stderr, and metadata are preserved under `api-explorer-*`. The final source and base-relative patch are `final-source.lean` and `final.patch`. No root import, handoff, shared definition, contract, model service, runtime Job, or other worktree was modified.

First action for the coordinator: independently rerun `python3 scripts/frozen_contract_audit.py --manifest harness/v2/contracts/core-input-existence-20260929/local-pullback.contract.json` against this base-relative diff, then use the accepted helpers in `SmoothInitialMetricExistence.exists_initial_metric`.
