import Poincare.Global.SmoothInitialMetricPositiveCone
open Lean Elab Command in
run_cmd do
  let env := (← getEnv).setExporting false
  let some idx := env.getModuleIdx? `Poincare.Global.SmoothInitialMetricPositiveCone |
    throwError "module not found"
  let mut count := 0
  for (n, _) in env.constants.map₁.toList do
    if env.getModuleIdxFor? n == some idx then
      let axs ← liftCoreM (collectAxioms n)
      count := count + 1
      logInfo m!"MODULE_DECL {n} AXIOMS {axs}"
      for a in axs do
        unless a == ``propext || a == ``Classical.choice || a == ``Quot.sound do
          throwError "nonstandard dependency {a} in {n}"
  unless count > 0 do
    throwError "empty module scan"
  logInfo m!"MODULE_SCAN declarations={count} nonstandard=[]"
#print axioms Poincare.SmoothInitialMetricPositiveCone.convex_positiveSymmetricBilinearForms
#print axioms Poincare.SmoothInitialMetricPositiveCone.exists_pos_mul_norm_sq_le
#print axioms Poincare.SmoothInitialMetricPositiveCone.isVonNBounded_bilinear_unitBall
