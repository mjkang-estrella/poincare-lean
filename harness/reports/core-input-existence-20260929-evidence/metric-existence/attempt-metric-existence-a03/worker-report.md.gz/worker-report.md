# Worker result: actual smooth initial metric exists

Task `core-input-20260929-metric-existence`, revision 2. This is a local Codex helper result, not a registered Pi or Leanstral runtime Job. Worker verification passed; acceptance and integration belong to the coordinator.

Base commit: `acdd969f1ce554c0f750d08e5ba2c554838c40d2`.
Proof commit: `ed1244c5a7932fdb9660b02396241d41a0007b8f`.
Branch: `codex/core-initial-metric-existence-a03`.
Only committed source: `Poincare/Global/SmoothInitialMetricExistence.lean`, 85 new lines.

The exact frozen theorem `Poincare.SmoothInitialMetricExistence.exists_initial_metric` is proved. Every compact Hausdorff smooth three-manifold admits an actual `ClosedSmoothRiemannianMetric 3 M`, with no supplied metric, curvature, recognition, connectedness, orientability, nonempty-manifold, or second-countability assumption.

For each point, the proof uses its actual tangent trivialization's open base set as a neighborhood. The local section is exactly `localEuclideanInner p`. The verified local helper proves symmetry, strict positivity and smoothness there. The verified convex-cone helper lets Mathlib's `exists_contMDiffSection_forall_mem_convex_of_local` glue those sections through a smooth partition of unity. The resulting section fills `inner`, `symm`, `pos`, and `contMDiff`; the finite-dimensional positive-form boundedness helper fills `isVonNBounded`. All five fields contain genuine data or proofs. The explicit local dual-fiber topology resolves nested Hom-bundle inference at default heartbeats.

Verification passed:

- `env LEAN_NUM_THREADS=1 lake env lean Poincare/Global/SmoothInitialMetricExistence.lean`, exit 0, 4.786 seconds.
- The Task's forbidden-token scan, exit 0.
- `git diff --check`, exit 0, and both staged and unstaged whitespace checks after staging the new file.
- `python3 scripts/frozen_contract_audit.py --manifest harness/v2/contracts/core-input-existence-20260929/metric-existence.contract.json`, exit 0. The exact frozen type and allowed axiom contract passed; its scoped build passed at 2738 jobs.
- The independent emitted-module scan, including internal declarations, exit 0. All 20 declarations have exactly `[propext, Classical.choice, Quot.sound]`; nonstandard dependencies are empty.
- The base-to-proof committed path list contains exactly the one owned source file.

Actual complete gate outputs are `gate-001-command-01.log` through `gate-001-command-05.log`; commands and statuses are in `gate-results-001.json`. The complete new-file diff is `final-proof.diff`, the verified source is `verified-source.lean`, and `sealed-result.json` binds the source hash and proof commit.

Earlier draft and actual failed typeclass diagnostics remain in `../attempt-metric-existence-a01`. The coordinator preserved the setup-only a02 branch-switch failure. No proof verification ran during that setup failure. No unfinished proof, added premise, frozen-definition edit, root import, full build, service action, Task acceptance, or merge is part of this result. The Root-managed Taskfile remains modified and unstaged, as instructed.

This closes the actual initial-metric input. Generic short-time evolution and universal favorable-metric or positive-Einstein production remain separate substantive obligations.

First independent review action: compile the leaf freshly from the pinned dependency base, then rerun its exact frozen contract and inspect the source-only diff.
