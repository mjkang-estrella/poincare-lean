import Poincare.Global.SmoothInitialMetricExistence
import Lean
open Lean Elab Command in
run_cmd do
  let env := (← getEnv).setExporting false
  let some idx := env.getModuleIdx? `Poincare.Global.SmoothInitialMetricExistence |
    throwError "metric-existence module not found"
  let mut count := 0
  let mut bad : Array String := #[]
  for (name, _) in env.constants.map₁.toList do
    if env.getModuleIdxFor? name == some idx then
      let axs ← liftCoreM (collectAxioms name)
      count := count + 1
      logInfo m!"METRIC_EXISTENCE_AXIOMS {name}: {axs}"
      for ax in axs do
        unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
          bad := bad.push s!"{name} uses {ax}"
  logInfo m!"METRIC_EXISTENCE_SCAN declarations={count} nonstandard={bad}"
  unless bad.isEmpty do
    throwError "nonstandard emitted-module dependencies: {bad}"
#print axioms Poincare.SmoothInitialMetricExistence.exists_initial_metric
