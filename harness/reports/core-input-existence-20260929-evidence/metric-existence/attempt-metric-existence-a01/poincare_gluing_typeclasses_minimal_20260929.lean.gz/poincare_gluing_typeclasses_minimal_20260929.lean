import Poincare.Global.SmoothInitialMetricDefinitions
import Mathlib.Geometry.Manifold.PartitionOfUnity

noncomputable section
open Bundle Filter Set
open scoped Manifold ContDiff Topology
universe u
open Poincare
local notation "E3" => ClosedSmoothModel 3
local notation "I3" => closedSmoothModelWithCorners 3
local notation "BF" => E3 →L[ℝ] E3 →L[ℝ] ℝ
variable {M : Type u} [TopologicalSpace M] [ChartedSpace E3 M]
  [IsManifold I3 ∞ M] [T2Space M] [CompactSpace M]
local instance : ∀ x : M, TopologicalSpace (TangentSpace I3 x →L[ℝ] ℝ) :=
  fun _ => ContinuousLinearMap.topologicalSpace
local notation "V" => fun x : M => TangentSpace I3 x →L[ℝ] TangentSpace I3 x →L[ℝ] ℝ
#synth SigmaCompactSpace M
#synth TopologicalSpace (TotalSpace BF V)
#synth FiberBundle BF V
#synth VectorBundle ℝ BF V
#synth ContMDiffVectorBundle ∞ BF V I3
#check exists_contMDiffSection_forall_mem_convex_of_local
example (t : ∀ x : M, Set (V x))
    (ht : ∀ x, Convex ℝ (t x))
    (Hloc : ∀ p : M, ∃ U ∈ 𝓝 p, ∃ s : ∀ x : M, V x,
      ContMDiffOn I3 ((I3).prod 𝓘(ℝ, BF)) ∞
        (fun x => TotalSpace.mk' BF x (s x)) U ∧ ∀ x ∈ U, s x ∈ t x) :
    ∃ s : Cₛ^∞⟮I3; BF, V⟯, ∀ x, s x ∈ t x := by
  exact exists_contMDiffSection_forall_mem_convex_of_local
    (n := (⊤ : ℕ∞)) (F_fiber := BF) I3 V t ht Hloc
