from pathlib import Path
import sys, json, shutil, subprocess, os, time, datetime, hashlib
root=Path("/Users/mjkang/.codex/worktrees/core-actual-evolution-derivative/poincare")
evidence=Path(__file__).parent
label=sys.argv[1]
argv=sys.argv[2:]
a=evidence/label
a.mkdir(exist_ok=False)
source=root/"Poincare/Global/DeTurckActualEvolutionDerivative.lean"
if source.exists(): shutil.copyfile(source,a/"source.lean")
(a/"argv.json").write_text(json.dumps(argv,indent=2)+"\n")
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
t=time.monotonic()
with (a/"stdout.log").open("wb") as out, (a/"stderr.log").open("wb") as err:
 r=subprocess.run(argv,cwd=root,env=dict(os.environ,LEAN_NUM_THREADS="1"),stdout=out,stderr=err)
(a/"result.json").write_text(json.dumps({"argv":argv,"cwd":str(root),"start":start,"end":datetime.datetime.now(datetime.timezone.utc).isoformat(),"elapsed_seconds":time.monotonic()-t,"exit_code":r.returncode},indent=2)+"\n")
with (a/"diff.patch").open("wb") as f:
 if source.exists(): subprocess.run(["git","diff","--no-index","--","/dev/null",str(source)],cwd=root,stdout=f)
if source.exists():
 (a/"source.sha256").write_text(hashlib.sha256(source.read_bytes()).hexdigest()+"\n")
print(json.dumps({"label":label,"exit_code":r.returncode,"elapsed_seconds":time.monotonic()-t}))
print("\n".join((a/"stdout.log").read_text().splitlines()[-30:]))
print("\n".join((a/"stderr.log").read_text().splitlines()[-30:]))
sys.exit(r.returncode)
