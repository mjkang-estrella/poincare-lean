import sys, os, json, time, subprocess, hashlib
from pathlib import Path
base=Path(__file__).resolve().parent
wt=Path('/Users/mjkang/.codex/worktrees/core-pullback-twojet/poincare')
label=sys.argv[1]; argv=sys.argv[2:]
out=base/label
out.mkdir(exist_ok=False)
source=wt/'Poincare/Global/DeTurckPullbackTwoJet.lean'
if source.exists(): (out/'DeTurckPullbackTwoJet.lean').write_bytes(source.read_bytes())
started=time.time()
(out/'argv.json').write_text(json.dumps({'argv':argv,'cwd':str(wt),'started':started},indent=2))
env=dict(os.environ, LEAN_NUM_THREADS='1')
with (out/'stdout.log').open('wb') as stdout, (out/'stderr.log').open('wb') as stderr:
 proc=subprocess.run(argv,cwd=wt,env=env,stdout=stdout,stderr=stderr)
res={'argv':argv,'cwd':str(wt),'exit_code':proc.returncode,'started':started,'finished':time.time(),'seconds':time.time()-started}
(out/'result.json').write_text(json.dumps(res,indent=2))
print(json.dumps(res))
print((out/'stdout.log').read_text(errors='replace'))
print((out/'stderr.log').read_text(errors='replace'))
raise SystemExit(proc.returncode)
