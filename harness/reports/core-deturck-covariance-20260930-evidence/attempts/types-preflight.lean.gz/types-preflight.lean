import Poincare.Global.DeTurckChartIndependentPullback
import Mathlib.Analysis.Calculus.ContDiff.Operations
import Mathlib.Analysis.Calculus.Deriv.Prod
import Mathlib.Analysis.Calculus.Deriv.Mul
open scoped ContDiff Topology
universe u v
#check (∀ (E : Type u) (B : Type v) [NormedAddCommGroup E] [NormedSpace ℝ E]
[NormedAddCommGroup B] [NormedSpace ℝ B]
(V : Set E), IsOpen V → ∀ z : E, z ∈ V →
∀ ε : ℝ, 0 < ε → ∀ (G : ℝ → E → B) (G0 F : E → B),
ContDiffOn ℝ 2 G0 V → ContDiffOn ℝ 2 F V →
(∀ s : ℝ, |s| < ε → ∀ y ∈ V, G s y = G0 y + s • F y) →
HasDerivAt
 (fun s => ((G s z, fderiv ℝ (G s) z), fderiv ℝ (fderiv ℝ (G s)) z))
 ((F z, fderiv ℝ F z), fderiv ℝ (fderiv ℝ F) z) 0)
#check (∀ (E : Type u) [NormedAddCommGroup E] [NormedSpace ℝ E]
(h F : E → (E →L[ℝ] E →L[ℝ] ℝ)) (phi : E → E) (z : E),
ContDiffAt ℝ 2 h (phi z) → ContDiffAt ℝ 2 F (phi z) →
ContDiffAt ℝ 3 phi z →
h (phi z) = F (phi z) →
fderiv ℝ h (phi z) = fderiv ℝ F (phi z) →
fderiv ℝ (fderiv ℝ h) (phi z) = fderiv ℝ (fderiv ℝ F) (phi z) →
let T := fun (q : E → (E →L[ℝ] E →L[ℝ] ℝ)) (y : E) =>
 Poincare.pullbackBilinearForm (q (phi y)) (fderiv ℝ phi y)
T h z = T F z ∧ fderiv ℝ (T h) z = fderiv ℝ (T F) z ∧
 fderiv ℝ (fderiv ℝ (T h)) z = fderiv ℝ (fderiv ℝ (T F)) z)
