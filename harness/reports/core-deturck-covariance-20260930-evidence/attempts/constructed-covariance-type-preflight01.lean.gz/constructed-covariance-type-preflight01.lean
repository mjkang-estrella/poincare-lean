import Poincare.Global.DeTurckJetLinearizationDefinitions
import Poincare.Global.DeTurckMetricVariation
noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option synthInstance.maxHeartbeats 100000
set_option maxSynthPendingDepth 100
open scoped Manifold ContDiff BigOperators Topology
universe u
#check (
  letI : NormedAddCommGroup Poincare.DeTurckPrincipalSecondJet.Jet1 :=
        ContinuousLinearMap.toNormedAddCommGroup
          (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin)
          (σ₁₂ := RingHom.id ℝ);
      letI : NormedSpace ℝ Poincare.DeTurckPrincipalSecondJet.Jet1 :=
        ContinuousLinearMap.toNormedSpace
          (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin)
          (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);
      letI : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ);
      letI : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);
      letI : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ);
      letI : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);
      letI : NormedAddCommGroup Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedAddCommGroup
       (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ);
      letI : NormedSpace ℝ Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedSpace
       (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);
      letI : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.normedAddCommGroup;
      letI : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.normedSpace;
      letI : NormedAddCommGroup Poincare.DeTurckJetLinearization.Variables := Prod.normedAddCommGroup;
      letI : NormedSpace ℝ Poincare.DeTurckJetLinearization.Variables := Prod.normedSpace;
      letI : AddCommMonoid (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.instAddCommMonoid;
  ∀ (M : Type u) [TopologicalSpace M] [T2Space M]
  [ChartedSpace Poincare.DeTurckPrincipalSecondJet.E M]
  [IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]
  (g0 bg : Poincare.ClosedSmoothRiemannianMetric 3 M) (liftAnchor : M)
  (F : Poincare.DeTurckPrincipalSecondJet.E → Poincare.DeTurckPrincipalSecondJet.Bilin),
  ContDiff ℝ ((⊤ : ENat) : WithTop ENat) F → HasCompactSupport F →
  tsupport F ⊆ (extChartAt (Poincare.closedSmoothModelWithCorners 3) liftAnchor).target →
  (∀ z v w : Poincare.DeTurckPrincipalSecondJet.E, F z v w = F z w v) →
  let H := Poincare.DeTurckChartLift.chartLift liftAnchor F
  let DQ := fun (anchor : M) (y : Poincare.DeTurckPrincipalSecondJet.E) =>
   let G0 := _root_.CovariantDerivative.chartMetric
    (I := Poincare.closedSmoothModelWithCorners 3) g0.inner anchor
   let DG0 := fderiv ℝ G0
   let D2G0 := fderiv ℝ DG0
   let F_a := _root_.CovariantDerivative.chartMetric
    (I := Poincare.closedSmoothModelWithCorners 3) H anchor
   let DF_a := fderiv ℝ F_a
   let D2F_a := fderiv ℝ DF_a
   let B := Poincare.GeodesicTransport.chartChristoffelField bg anchor
   let DB := fderiv ℝ B
   Poincare.DeTurckJetLinearization.differential
    (B y) (DB y) (G0 y) (DG0 y) (D2G0 y)
    ((F_a y, DF_a y), D2F_a y)
  ∀ (anchor₁ anchor₂ : M) (z : Poincare.DeTurckPrincipalSecondJet.E),
  z ∈ (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor₁).target →
  (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor₁).symm z ∈
   (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor₂).source →
  Filter.Eventually
   (fun y => Poincare.GeodesicTransport.cutoff (n := 3) anchor₁ y = 1) (nhds z) →
  Filter.Eventually
   (fun y => Poincare.GeodesicTransport.cutoff (n := 3) anchor₂ y = 1)
   (nhds (Poincare.GeodesicTransport.chartTransition anchor₁ anchor₂ z)) →
  Poincare.pullbackBilinearForm
   (DQ anchor₂ (Poincare.GeodesicTransport.chartTransition anchor₁ anchor₂ z))
   (Poincare.GeodesicTransport.chartTransitionDeriv anchor₁ anchor₂ z) =
  DQ anchor₁ z
)
