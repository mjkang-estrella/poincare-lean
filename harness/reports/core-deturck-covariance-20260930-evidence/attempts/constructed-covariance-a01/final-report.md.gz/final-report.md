Candidate commit: `8220d71e95466b7e0505857ef7c21b292bf8dc4d`
Base: `3bd6504391f785d0efc7e627e747d6f84362eb38`
Only changed source: `Poincare/Global/DeTurckConstructedCovariance.lean` (172 lines added).

Exact theorem `Poincare.DeTurckConstructedCovariance.chartLift_differential_covariance` passes the frozen type and allowed foundational-axiom contract. It constructs actual H, smoothness and a genuine signed metric family; obtains the actual full evolution derivative in both charts; differentiates existing nonlinear covariance on both cutoff-one germs; and concludes equality of entire bilinear forms by two CLM extensionality steps. No family, affine, derivative or covariance certificate is added as a premise.

All four Task acceptance commands pass. Supplemental staged diff check passes. First missing-cache failure and scalar simplification failure are retained with exact source/argv/timing/exit/stdout/stderr. The permitted prerequisite build and frozen audit module build are scoped; no root/full build ran. Copied Task/contracts remain unchanged and untracked. No services, frozen definitions, root imports, or HANDOFF were changed.

Worker candidate only; no Task acceptance or merge performed. First orchestrator action: independently rerun the frozen Task gate at this candidate and inspect the diff against its recorded base.
