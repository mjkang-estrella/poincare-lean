import Mathlib.Analysis.Calculus.Deriv.Mul

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

example (f g : ℝ → E →L[ℝ] E →L[ℝ] ℝ)
    (a b : E →L[ℝ] E →L[ℝ] ℝ) (T : E → E) (v w : E)
    (h1 : HasDerivAt f a 0) (h2 : HasDerivAt g b 0)
    (heq : ∀ s, f s (T v) (T w) = g s v w) :
    a (T v) (T w) = b v w := by
  have h1v : HasDerivAt (fun s : ℝ => f s (T v)) (a (T v)) 0 := by
    simpa using HasDerivAt.clm_apply (𝕜 := ℝ) (F := E)
      (G := E →L[ℝ] ℝ) h1 (hasDerivAt_const (0 : ℝ) (T v))
  have h1vw : HasDerivAt (fun s : ℝ => f s (T v) (T w)) (a (T v) (T w)) 0 := by
    simpa using HasDerivAt.clm_apply (𝕜 := ℝ) (F := E)
      (G := ℝ) h1v (hasDerivAt_const (0 : ℝ) (T w))
  have h2v : HasDerivAt (fun s : ℝ => g s v) (b v) 0 := by
    simpa using HasDerivAt.clm_apply (𝕜 := ℝ) (F := E)
      (G := E →L[ℝ] ℝ) h2 (hasDerivAt_const (0 : ℝ) v)
  have h2vw : HasDerivAt (fun s : ℝ => g s v w) (b v w) 0 := by
    simpa using HasDerivAt.clm_apply (𝕜 := ℝ) (F := E)
      (G := ℝ) h2v (hasDerivAt_const (0 : ℝ) w)
  exact h1vw.unique (h2vw.congr_of_eventuallyEq (Filter.Eventually.of_forall heq))
