from pathlib import Path
import json,sys,subprocess,os,time,datetime,uuid,shutil
root=Path("/Users/mjkang/.codex/worktrees/core-constructed-covariance/poincare")
evidence=Path(__file__).parent
argv=json.loads(sys.argv[1])
run=evidence/(datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")+"-"+uuid.uuid4().hex[:8])
run.mkdir()
(run/"argv.json").write_text(json.dumps(argv,ensure_ascii=False,indent=2)+"\n")
source=root/"Poincare/Global/DeTurckConstructedCovariance.lean"
if source.exists(): shutil.copy2(source,run/"source.lean")
start=time.time()
with (run/"stdout.log").open("wb") as out,(run/"stderr.log").open("wb") as err:
 p=subprocess.run(argv,cwd=root,stdout=out,stderr=err)
meta={"argv":argv,"cwd":str(root),"started_unix":start,"elapsed_seconds":time.time()-start,"exit_code":p.returncode}
(run/"result.json").write_text(json.dumps(meta,indent=2)+"\n")
print(json.dumps({"evidence":str(run),**meta}))
print((run/"stdout.log").read_text())
print((run/"stderr.log").read_text())
sys.exit(p.returncode)
