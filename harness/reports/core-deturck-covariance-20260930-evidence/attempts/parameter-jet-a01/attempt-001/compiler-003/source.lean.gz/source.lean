import Lean
import Poincare.Global.DeTurckParameterJet
open Lean Elab Command Meta
set_option autoImplicit false
run_cmd do
  let name := "Poincare.DeTurckParameterJet.twoJet_hasDerivAt_of_affine_on_open".toName
  let _ ← getConstInfo name
  let environment := (← getEnv).setExporting false
  let mut pending : List Name := [name]
  let mut seen : NameSet := {}
  while !pending.isEmpty do
    let current := pending.head!
    pending := pending.tail!
    if !seen.contains current then
      seen := seen.insert current
      let some info := environment.find? current |
        throwError "missing dependency {current} in {name}"
      if info.isUnsafe || info.isPartial then
        throwError "unsafe or partial declaration {current} in {name}"
      pending := info.getUsedConstantsAsSet.toList ++ pending
      match info with
      | .recInfo value =>
        for rule in value.rules do
          pending := rule.rhs.getUsedConstants.toList ++ pending
      | .inductInfo value => pending := value.ctors ++ pending
      | _ => pure ()
  let allowed : List Name := ["propext".toName, "Classical.choice".toName, "Quot.sound".toName]
  let footprint ← collectAxioms name
  for dependency in footprint do
    unless allowed.contains dependency do
      throwError "forbidden axiom {dependency} in {name}"
  logInfo "AXIOM_CONTRACT_OK: Poincare.DeTurckParameterJet.twoJet_hasDerivAt_of_affine_on_open"
universe u v
run_cmd liftTermElabM do
  let info ← getConstInfo "Poincare.DeTurckParameterJet.twoJet_hasDerivAt_of_affine_on_open".toName
  let levels : List Level := [Level.param "u".toName, Level.param "v".toName]
  unless info.levelParams.length == levels.length do
    throwError "frozen universe arity mismatch for {info.name}"
  let parsedType ← match Parser.runParserCategory (← getEnv) `term "∀ (E : Type u) (B : Type v) [NormedAddCommGroup E] [NormedSpace ℝ E]\n[NormedAddCommGroup B] [NormedSpace ℝ B]\n(V : Set E), IsOpen V → ∀ z : E, z ∈ V →\n∀ ε : ℝ, 0 < ε → ∀ (G : ℝ → E → B) (G0 F : E → B),\nContDiffOn ℝ 2 G0 V → ContDiffOn ℝ 2 F V →\n(∀ s : ℝ, |s| < ε → ∀ y ∈ V, G s y = G0 y + s • F y) →\nHasDerivAt\n (fun s => ((G s z, fderiv ℝ (G s) z), fderiv ℝ (fderiv ℝ (G s)) z))\n ((F z, fderiv ℝ F z), fderiv ℝ (fderiv ℝ F) z) 0" with
    | .ok parsedType => pure parsedType
    | .error error => throwError error
  let expected ← Term.elabType parsedType
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then
    throwError "unresolved metavariables in frozen type for {info.name}"
  let actual := info.type.instantiateLevelParams info.levelParams levels
  unless ← isDefEq actual expected do
    throwError "frozen type mismatch for {info.name}: actual {actual}, expected {expected}"
  logInfo "FROZEN_CONTRACT_OK: Poincare.DeTurckParameterJet.twoJet_hasDerivAt_of_affine_on_open"
