import Poincare.Global.DeTurckConstructedCovariance
import Poincare.Global.SmoothInitialMetricExistence
noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
open Set Filter
open scoped Manifold ContDiff Topology
universe u
namespace Poincare.ConstructedCovarianceApplication
open DeTurckPrincipalSecondJet DeTurckJetLinearization DeTurckJetRealization
local instance metricApplicationBilinBoundedSMul : IsBoundedSMul ℝ Bilin :=
  .of_norm_smul_le (fun c A => ContinuousLinearMap.opNorm_smul_le c A)
local instance metricApplicationJet1Group : NormedAddCommGroup Jet1 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance metricApplicationJet1Space : NormedSpace ℝ Jet1 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance metricApplicationJet2Group : NormedAddCommGroup Jet2 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1) (σ₁₂ := RingHom.id ℝ)
local instance metricApplicationJet2Space : NormedSpace ℝ Jet2 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)


example :
letI : NormedAddCommGroup Poincare.DeTurckPrincipalSecondJet.Jet1 :=
      ContinuousLinearMap.toNormedAddCommGroup
        (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin)
        (σ₁₂ := RingHom.id ℝ);
    letI : NormedSpace ℝ Poincare.DeTurckPrincipalSecondJet.Jet1 :=
      ContinuousLinearMap.toNormedSpace
        (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin)
        (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);
    letI : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ);
    letI : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);
    letI : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ);
    letI : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E) := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := (Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);
    letI : NormedAddCommGroup Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedAddCommGroup
     (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ);
    letI : NormedSpace ℝ Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedSpace
     (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);
    letI : NormedAddCommGroup (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.normedAddCommGroup;
    letI : NormedSpace ℝ (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.normedSpace;
    letI : NormedAddCommGroup Poincare.DeTurckJetLinearization.Variables := Prod.normedAddCommGroup;
    letI : NormedSpace ℝ Poincare.DeTurckJetLinearization.Variables := Prod.normedSpace;
    letI : AddCommMonoid (Poincare.DeTurckPrincipalSecondJet.Bilin × Poincare.DeTurckPrincipalSecondJet.Jet1) := Prod.instAddCommMonoid;
 ∀ (M : Type u) [TopologicalSpace M] [T2Space M] [CompactSpace M]
[ChartedSpace E M] [IsManifold (closedSmoothModelWithCorners 3) ∞ M],
∃ g0 : ClosedSmoothRiemannianMetric 3 M,
∀ (anchor : M) (h : E → Bilin) (z : E),
z ∈ (extChartAt (closedSmoothModelWithCorners 3) anchor).target →
ContDiffAt ℝ (2 : WithTop ENat) h z →
(∀ᶠ y in nhds z, ∀ v w : E, h y v w = h y w v) →
∃ (F : E → Bilin), ContDiff ℝ ∞ F ∧ HasCompactSupport F ∧
tsupport F ⊆ (extChartAt (closedSmoothModelWithCorners 3) anchor).target ∧
(∀ y v w : E, F y v w = F y w v) ∧
F z = h z ∧ fderiv ℝ F z = fderiv ℝ h z ∧
fderiv ℝ (fderiv ℝ F) z = fderiv ℝ (fderiv ℝ h) z ∧
let H := Poincare.DeTurckChartLift.chartLift anchor F
let DQ := fun (anchor : M) (y : Poincare.DeTurckPrincipalSecondJet.E) =>
 let G0 := _root_.CovariantDerivative.chartMetric
  (I := Poincare.closedSmoothModelWithCorners 3) g0.inner anchor
 let DG0 := fderiv ℝ G0
 let D2G0 := fderiv ℝ DG0
 let F_a := _root_.CovariantDerivative.chartMetric
  (I := Poincare.closedSmoothModelWithCorners 3) H anchor
 let DF_a := fderiv ℝ F_a
 let D2F_a := fderiv ℝ DF_a
 let B := Poincare.GeodesicTransport.chartChristoffelField bg anchor
 let DB := fderiv ℝ B
 Poincare.DeTurckJetLinearization.differential
  (B y) (DB y) (G0 y) (DG0 y) (D2G0 y)
  ((F_a y, DF_a y), D2F_a y)
∀ (anchor₁ anchor₂ : M) (z : Poincare.DeTurckPrincipalSecondJet.E),
z ∈ (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor₁).target →
(extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor₁).symm z ∈
 (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor₂).source →
Filter.Eventually
 (fun y => Poincare.GeodesicTransport.cutoff (n := 3) anchor₁ y = 1) (nhds z) →
Filter.Eventually
 (fun y => Poincare.GeodesicTransport.cutoff (n := 3) anchor₂ y = 1)
 (nhds (Poincare.GeodesicTransport.chartTransition anchor₁ anchor₂ z)) →
Poincare.pullbackBilinearForm
 (DQ anchor₂ (Poincare.GeodesicTransport.chartTransition anchor₁ anchor₂ z))
 (Poincare.GeodesicTransport.chartTransitionDeriv anchor₁ anchor₂ z) =
DQ anchor₁ z := by
  intro M _ _ _ _ _
  obtain ⟨g0⟩ := SmoothInitialMetricExistence.exists_initial_metric (M := M)
  refine ⟨g0, ?_⟩
  intro anchor h z hz hc hs
  obtain ⟨η, _hη, _hcη, _hηU, _hone, hF, hcF, hFU, hsym, hzero, hfirst, hsecond⟩ :=
    exists_compact_symmetric_realization h z
      (extChartAt (closedSmoothModelWithCorners 3) anchor).target
      (isOpen_extChartAt_target anchor) hz hc hs
  let F := realized η h z
  refine ⟨F, hF, hcF, hFU, hsym, hzero, hfirst, hsecond, ?_⟩
  exact DeTurckConstructedCovariance.chartLift_differential_covariance
    M g0 g0 anchor F hF hcF hFU hsym
end Poincare.ConstructedCovarianceApplication
