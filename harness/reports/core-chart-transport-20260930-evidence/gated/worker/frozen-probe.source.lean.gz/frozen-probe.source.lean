import Lean
import Poincare.Global.BufferedChartTransitionExtensions
open Lean Elab Command Meta
set_option autoImplicit false
run_cmd do
  let name := "Poincare.BufferedChartTransitionExtensions.exists_gated_chart_extensions".toName
  let _ ← getConstInfo name
  let environment := (← getEnv).setExporting false
  let mut pending : List Name := [name]
  let mut seen : NameSet := {}
  while !pending.isEmpty do
    let current := pending.head!
    pending := pending.tail!
    if !seen.contains current then
      seen := seen.insert current
      let some info := environment.find? current |
        throwError "missing dependency {current} in {name}"
      if info.isUnsafe || info.isPartial then
        throwError "unsafe or partial declaration {current} in {name}"
      pending := info.getUsedConstantsAsSet.toList ++ pending
      match info with
      | .recInfo value =>
        for rule in value.rules do
          pending := rule.rhs.getUsedConstants.toList ++ pending
      | .inductInfo value => pending := value.ctors ++ pending
      | _ => pure ()
  let allowed : List Name := ["propext".toName, "Classical.choice".toName, "Quot.sound".toName]
  let footprint ← collectAxioms name
  for dependency in footprint do
    unless allowed.contains dependency do
      throwError "forbidden axiom {dependency} in {name}"
  logInfo "AXIOM_CONTRACT_OK: Poincare.BufferedChartTransitionExtensions.exists_gated_chart_extensions"
universe u
run_cmd liftTermElabM do
  let info ← getConstInfo "Poincare.BufferedChartTransitionExtensions.exists_gated_chart_extensions".toName
  let levels : List Level := [Level.param "u".toName]
  unless info.levelParams.length == levels.length do
    throwError "frozen universe arity mismatch for {info.name}"
  let parsedType ← match Parser.runParserCategory (← getEnv) `term "∀ {M : Type u} [TopologicalSpace M] [T2Space M] [CompactSpace M] [ChartedSpace (Poincare.ClosedSmoothModel 3) M], ∀ [IsManifold (modelWithCornersSelf ℝ (Poincare.ClosedSmoothModel 3)) ((⊤ : ENat) : WithTop ENat) M], ∀ (A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M) (ξ : Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → ℝ),\n (∀ k, HasCompactSupport (ξ k)) →\n (∀ k, tsupport (ξ k) ⊆ (Poincare.FiniteAtlasParabolicTensorSpace.chart A k).target) →\n (∀ k, ∀ z ∈ tsupport (ξ k), Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor k) y = 1) (nhds z)) →\n (∀ k, ∀ z ∈ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A k, Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor k) y = 1) (nhds z)) → ∃ θ : Fin A.cover.chartCount → Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → ℝ,\n ∃ F : Fin A.cover.chartCount → Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → (Poincare.ClosedSmoothModel 3),\n ∀ i j, let K := (Poincare.FiniteAtlasParabolicTensorSpace.chart A i) '' (tsupport (A.partition i) ∩ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).symm '' tsupport (ξ j)); let O := ((Poincare.FiniteAtlasParabolicTensorSpace.chart A i).symm.trans (Poincare.FiniteAtlasParabolicTensorSpace.chart A j)).source ∩\n (fun z : (Poincare.ClosedSmoothModel 3) => Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor i) y = 1) (nhds z)) ∩\n (Poincare.FiniteAtlasParabolicTensorSpace.change A i j) ⁻¹' (fun z : (Poincare.ClosedSmoothModel 3) => Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor j) y = 1) (nhds z));\n   ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (θ i j) ∧ HasCompactSupport (θ i j) ∧\n   (∀ z, θ i j z ∈ Set.Icc 0 1) ∧ tsupport (θ i j) ⊆ O ∧\n   (∀ z ∈ K, Filter.Eventually (fun y ↦ θ i j y = 1) (nhds z)) ∧\n   ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (F i j) ∧ HasCompactSupport (F i j) ∧\n   (∀ z ∈ tsupport (θ i j), Filter.Eventually (fun y ↦ F i j y = Poincare.FiniteAtlasParabolicTensorSpace.change A i j y) (nhds z)) ∧\n   ∃ L : NNReal, LipschitzWith L (F i j)" with
    | .ok parsedType => pure parsedType
    | .error error => throwError error
  let expected ← Term.elabType parsedType
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then
    throwError "unresolved metavariables in frozen type for {info.name}"
  let actual := info.type.instantiateLevelParams info.levelParams levels
  unless ← isDefEq actual expected do
    throwError "frozen type mismatch for {info.name}: actual {actual}, expected {expected}"
  logInfo "FROZEN_CONTRACT_OK: Poincare.BufferedChartTransitionExtensions.exists_gated_chart_extensions"
