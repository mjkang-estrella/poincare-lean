import Poincare.Global.CompactBufferedChartOverlap
import Poincare.Global.SmoothCutoffVectorExtension
import Poincare.Global.BufferedFrozenParabolicSolver
noncomputable section
set_option autoImplicit false
open Set Filter
open scoped Manifold ContDiff Topology
universe u
namespace Poincare.BufferedChartTransitionExtensions
theorem exists_gated_chart_extensions :
∀ {M : Type u} [TopologicalSpace M] [T2Space M] [CompactSpace M] [ChartedSpace (Poincare.ClosedSmoothModel 3) M], ∀ [IsManifold (modelWithCornersSelf ℝ (Poincare.ClosedSmoothModel 3)) ((⊤ : ENat) : WithTop ENat) M], ∀ (A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M) (ξ : Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → ℝ),
 (∀ k, HasCompactSupport (ξ k)) →
 (∀ k, tsupport (ξ k) ⊆ (Poincare.FiniteAtlasParabolicTensorSpace.chart A k).target) →
 (∀ k, ∀ z ∈ tsupport (ξ k), Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor k) y = 1) (nhds z)) →
 (∀ k, ∀ z ∈ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A k, Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor k) y = 1) (nhds z)) → ∃ θ : Fin A.cover.chartCount → Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → ℝ,
 ∃ F : Fin A.cover.chartCount → Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → (Poincare.ClosedSmoothModel 3),
 ∀ i j, let K := (Poincare.FiniteAtlasParabolicTensorSpace.chart A i) '' (tsupport (A.partition i) ∩ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).symm '' tsupport (ξ j)); let O := ((Poincare.FiniteAtlasParabolicTensorSpace.chart A i).symm.trans (Poincare.FiniteAtlasParabolicTensorSpace.chart A j)).source ∩
 (fun z : (Poincare.ClosedSmoothModel 3) => Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor i) y = 1) (nhds z)) ∩
 (Poincare.FiniteAtlasParabolicTensorSpace.change A i j) ⁻¹' (fun z : (Poincare.ClosedSmoothModel 3) => Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor j) y = 1) (nhds z));
   ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (θ i j) ∧ HasCompactSupport (θ i j) ∧
   (∀ z, θ i j z ∈ Set.Icc 0 1) ∧ tsupport (θ i j) ⊆ O ∧
   (∀ z ∈ K, Filter.Eventually (fun y ↦ θ i j y = 1) (nhds z)) ∧
   ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (F i j) ∧ HasCompactSupport (F i j) ∧
   (∀ z ∈ tsupport (θ i j), Filter.Eventually (fun y ↦ F i j y = Poincare.FiniteAtlasParabolicTensorSpace.change A i j y) (nhds z)) ∧
   ∃ L : NNReal, LipschitzWith L (F i j) := by
  intro M _ _ _ _ _ A ξ hcξ htarget hξcut hcoordcut
  classical
  have hshape := CompactBufferedChartOverlap.isCompact_subset_good_overlap
    A ξ hcξ htarget hξcut hcoordcut
  have hsingle (i j : Fin A.cover.chartCount) :
∃ θ : Poincare.ClosedSmoothModel 3 → ℝ, ∃ F : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3, let K := (Poincare.FiniteAtlasParabolicTensorSpace.chart A i) '' (tsupport (A.partition i) ∩ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).symm '' tsupport (ξ j)); let O := ((Poincare.FiniteAtlasParabolicTensorSpace.chart A i).symm.trans (Poincare.FiniteAtlasParabolicTensorSpace.chart A j)).source ∩
 (fun z : (Poincare.ClosedSmoothModel 3) => Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor i) y = 1) (nhds z)) ∩
 (Poincare.FiniteAtlasParabolicTensorSpace.change A i j) ⁻¹' (fun z : (Poincare.ClosedSmoothModel 3) => Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor j) y = 1) (nhds z));
   ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (θ) ∧ HasCompactSupport (θ) ∧
   (∀ z, θ z ∈ Set.Icc 0 1) ∧ tsupport (θ) ⊆ O ∧
   (∀ z ∈ K, Filter.Eventually (fun y ↦ θ y = 1) (nhds z)) ∧
   ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (F) ∧ HasCompactSupport (F) ∧
   (∀ z ∈ tsupport (θ), Filter.Eventually (fun y ↦ F y = Poincare.FiniteAtlasParabolicTensorSpace.change A i j y) (nhds z)) ∧
   ∃ L : NNReal, LipschitzWith L (F) := by
    let K := (FiniteAtlasParabolicTensorSpace.chart A i) ''
      (tsupport (A.partition i) ∩
        (FiniteAtlasParabolicTensorSpace.chart A j).symm '' tsupport (ξ j))
    let O := ((FiniteAtlasParabolicTensorSpace.chart A i).symm.trans
      (FiniteAtlasParabolicTensorSpace.chart A j)).source ∩
      {z | ∀ᶠ y in nhds z, GeodesicTransport.cutoff (n := 3) (A.cover.anchor i) y = 1} ∩
      (FiniteAtlasParabolicTensorSpace.change A i j) ⁻¹'
      {z | ∀ᶠ y in nhds z, GeodesicTransport.cutoff (n := 3) (A.cover.anchor j) y = 1}
    obtain ⟨hK, hO, hKO⟩ := hshape i j
    obtain ⟨θ, hθ, hcθ, hθO, hθK, hθ01⟩ :=
      BufferedFrozenParabolicSolver.exists_buffered_cutoff hK hO hKO
    obtain ⟨η, hη, hcη, hηO, hηθ, _hη01⟩ :=
      BufferedFrozenParabolicSolver.exists_buffered_cutoff hcθ hO hθO
    have hchange : ContDiffOn ℝ ∞ (FiniteAtlasParabolicTensorSpace.change A i j)
        ((FiniteAtlasParabolicTensorSpace.chart A i).symm.trans
          (FiniteAtlasParabolicTensorSpace.chart A j)).source := by
      simpa only [FiniteAtlasParabolicTensorSpace.change,
        FiniteAtlasParabolicTensorSpace.chart, Function.comp_def] using
        (contDiffOn_ext_coord_change
          (I := closedSmoothModelWithCorners 3) (n := ∞)
          (A.cover.anchor j) (A.cover.anchor i))
    have hchangeO : ContDiffOn ℝ ∞ (FiniteAtlasParabolicTensorSpace.change A i j) O :=
      hchange.mono (fun z hz => hz.1.1)
    let F : ClosedSmoothModel 3 → ClosedSmoothModel 3 :=
      fun z => η z • FiniteAtlasParabolicTensorSpace.change A i j z
    obtain ⟨hF, hcF⟩ :=
      SmoothCutoffVectorExtension.contDiff_hasCompactSupport_cutoff_smul O hO
        (FiniteAtlasParabolicTensorSpace.change A i j) hchangeO η hη hcη hηO
    obtain ⟨L, hL⟩ := ContDiff.lipschitzWith_of_hasCompactSupport hcF hF (by simp)
    have hagree : ∀ z ∈ tsupport θ, ∀ᶠ y in nhds z,
        F y = FiniteAtlasParabolicTensorSpace.change A i j y := by
      intro z hz
      filter_upwards [hηθ z hz] with y hy
      simp only [F, hy, one_smul]
    exact ⟨θ, F, hθ, hcθ, hθ01, hθO, hθK, hF, hcF, hagree, L, hL⟩
  choose θ F hθ hcθ hθ01 hθO hθK hF hcF hagree L hL using hsingle
  exact ⟨θ, F, fun i j =>
    ⟨hθ i j, hcθ i j, hθ01 i j, hθO i j, hθK i j,
      hF i j, hcF i j, hagree i j, L i j, hL i j⟩⟩

end Poincare.BufferedChartTransitionExtensions
