from pathlib import Path
import datetime, json, os, shutil, subprocess, sys, time
root=Path(__file__).resolve().parents[5]
evidence=Path(__file__).resolve().parent
label=sys.argv[1]
command=sys.argv[2:]
index=len(list(evidence.glob("run-*.json")))+1
stem=f"run-{index:03d}-{label}"
source=root/"Poincare/Global/BufferedChartTransitionExtensions.lean"
if source.exists(): shutil.copyfile(source,evidence/(stem+".source.lean"))
start=time.monotonic()
result=subprocess.run(command,cwd=root,env=dict(os.environ,LEAN_NUM_THREADS="1"),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(evidence/(stem+".log")).write_text(result.stdout)
(evidence/(stem+".json")).write_text(json.dumps({"command":command,"cwd":str(root),"exit_code":result.returncode,"duration_seconds":time.monotonic()-start,"utc":datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+"\n")
print("\n".join(result.stdout.splitlines()[-24:]))
print(f"{stem}: exit_code={result.returncode}")
sys.exit(result.returncode)
