import Poincare.Global.MetricAdaptedLocalParametrix
open scoped ContDiff Topology
universe v
#check (∀ {V : Type v} [NormedAddCommGroup V] [NormedSpace ℝ V],
∀ (F : (Poincare.ClosedSmoothModel 3) → (Poincare.ClosedSmoothModel 3)), ContDiff ℝ ((⊤ : ENat) : WithTop ENat) F → HasCompactSupport F →
∀ (α : ℝ), 0 ≤ α → ∃ C : ℝ, 0 ≤ C ∧ ∀ T : ℝ,
∃ Q : (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T V) →L[ℝ] (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T V), ‖Q‖ ≤ C ∧ ∀ f p, Q f p = f (p.1, F p.2))
