# Smooth cutoff vector extension: verified worker result

Base: c1cdb3e721143bf8e021ec01b2af29409d312a5c.
Branch: codex/core-vector-extension-a01.
Owned source: Poincare/Global/SmoothCutoffVectorExtension.lean only.

Core assumption helped: UniversalHamiltonConvergenceStatement, through genuine
DeTurck/Ricci-flow input construction. Subsequent consumer:
BufferedChartTransitionExtensions.exists_gated_chart_extensions, with the true
chart transition as f and an actually constructed buffered cutoff as eta.
That actual gated-map construction feeds bounded destination-only Graph/tensor
transport and genuine global DeTurck L/P/R assembly.

Proved the exact frozen exported statement: if U is open, f is smooth on U,
and eta is globally smooth with compact support contained in U, then the
actual total map eta smul f is globally smooth and compactly supported. On U,
the smooth scalar action combines smoothness of eta and local smoothness of f.
Outside U, eta has a zero neighborhood germ, so the product has a smooth zero
germ regardless of f's values there. Compact support follows from the verified
HasCompactSupport.smul_right theorem. No new manifold, atlas, metric, curvature,
flow, endpoint, regularity-outside-U or ellipticity premise is introduced.

All four scoped Task gates passed. The first actual source compiler attempt
passed with no compiler messages. No full build was run; the frozen contract
audit performed its required targeted module build. The read-only import/API
probe and its raw output/exit receipt are preserved alongside the actual source
compile and gate evidence. The internal-inclusive emitted declaration scan is
recorded under emitted-axioms; its summary is authoritative.

This removes the compact vector-map extension obstacle. It does not prove
bounded tensor transport, global operator contraction, nonlinear inversion,
initial-time ordinary joint C3, general Ricci flow, continuation/surgery or
favorable metric/limit existence. Neither universal Hamilton existence nor
smoothability is discharged. Worker has not accepted or merged the Task;
independent orchestrator acceptance remains required.
