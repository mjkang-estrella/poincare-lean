import Poincare.Global.ClosedLaplacianStokesGlobalCoefficients
noncomputable section
open Set Filter
open scoped ContDiff Topology
#check @HasCompactSupport.smul_right
#check @ContDiffAt.smul
#check @ContDiffAt.congr_of_eventuallyEq
#check @notMem_tsupport_iff_eventuallyEq
example {U : Set (Poincare.ClosedSmoothModel 3)}
    {eta : Poincare.ClosedSmoothModel 3 → ℝ}
    {f : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3}
    (hU : IsOpen U) (heta : ContDiff ℝ ∞ eta) (hsupp : tsupport eta ⊆ U)
    (hf : ContDiffOn ℝ ∞ f U) : ContDiff ℝ ∞ (fun z ↦ eta z • f z) := by
  apply contDiff_iff_contDiffAt.mpr
  intro z
  by_cases hz : z ∈ U
  · exact heta.contDiffAt.smul ((hf z hz).contDiffAt (hU.mem_nhds hz))
  · have hzero := notMem_tsupport_iff_eventuallyEq.mp (fun h ↦ hz (hsupp h))
    apply (contDiffAt_const (c := (0 : Poincare.ClosedSmoothModel 3))).congr_of_eventuallyEq
    filter_upwards [hzero] with y hy
    simp only [hy, Pi.zero_apply, zero_smul]
example {eta : Poincare.ClosedSmoothModel 3 → ℝ}
    {f : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3}
    (hcompact : HasCompactSupport eta) :
    HasCompactSupport (fun z ↦ eta z • f z) := by
  exact hcompact.smul_right (f' := f)
