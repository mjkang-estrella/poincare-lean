import Poincare.Global.MetricAdaptedLocalParametrix
import Poincare.Global.BufferedChartTransitionExtensions
noncomputable section
open Set Filter
open scoped Manifold ContDiff Topology
universe u
namespace Poincare
example :
∀ {M : Type u} [TopologicalSpace M] [T2Space M] [CompactSpace M] [ChartedSpace (Poincare.ClosedSmoothModel 3) M], ∀ [IsManifold (modelWithCornersSelf ℝ (Poincare.ClosedSmoothModel 3)) ((⊤ : ENat) : WithTop ENat) M], ∀ (g0 : Poincare.ClosedSmoothRiemannianMetric 3 M) (α : ℝ), 0 < α → α < 1 → ∃ A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M, ∃ ξ : Fin A.cover.chartCount → Poincare.ClosedSmoothModel 3 → ℝ, ∃ θ : Fin A.cover.chartCount → Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → ℝ,
 ∃ F : Fin A.cover.chartCount → Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → (Poincare.ClosedSmoothModel 3),
 ∀ i j, let K := (Poincare.FiniteAtlasParabolicTensorSpace.chart A i) '' (tsupport (A.partition i) ∩ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).symm '' tsupport (ξ j)); let O := ((Poincare.FiniteAtlasParabolicTensorSpace.chart A i).symm.trans (Poincare.FiniteAtlasParabolicTensorSpace.chart A j)).source ∩
 (fun z : (Poincare.ClosedSmoothModel 3) => Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor i) y = 1) (nhds z)) ∩
 (Poincare.FiniteAtlasParabolicTensorSpace.change A i j) ⁻¹' (fun z : (Poincare.ClosedSmoothModel 3) => Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor j) y = 1) (nhds z));
   ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (θ i j) ∧ HasCompactSupport (θ i j) ∧
   (∀ z, θ i j z ∈ Set.Icc 0 1) ∧ tsupport (θ i j) ⊆ O ∧
   (∀ z ∈ K, Filter.Eventually (fun y ↦ θ i j y = 1) (nhds z)) ∧
   ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (F i j) ∧ HasCompactSupport (F i j) ∧
   (∀ z ∈ tsupport (θ i j), Filter.Eventually (fun y ↦ F i j y = Poincare.FiniteAtlasParabolicTensorSpace.change A i j y) (nhds z)) ∧
   ∃ L : NNReal, LipschitzWith L (F i j) := by
  intro M _ _ _ _ _ g0 α hα hα1
  obtain ⟨A, ψ, ξ, hbuffer, _hoperators⟩ :=
    MetricAdaptedLocalParametrix.exists_metric_adapted_local_parametrix g0 α hα hα1
  have hcξ (k : Fin A.cover.chartCount) : HasCompactSupport (ξ k) := by
    rcases hbuffer k with ⟨_, _, _, _, _, hc, _, _, _, _⟩
    exact hc
  have htξ (k : Fin A.cover.chartCount) :
      tsupport (ξ k) ⊆ (FiniteAtlasParabolicTensorSpace.chart A k).target := by
    rcases hbuffer k with ⟨_, _, _, _, _, _, _, _, ht, _⟩
    exact ht
  have hξcut (k : Fin A.cover.chartCount) :
      ∀ z ∈ tsupport (ξ k), ∀ᶠ y in nhds z,
        GeodesicTransport.cutoff (n := 3) (A.cover.anchor k) y = 1 := by
    rcases hbuffer k with ⟨_, _, _, _, _, _, _, _, _, hc⟩
    exact hc
  have hcoord (k : Fin A.cover.chartCount) :
      ∀ z ∈ FiniteAtlasParabolicTensorSpace.coordSupport A k, ∀ᶠ y in nhds z,
        GeodesicTransport.cutoff (n := 3) (A.cover.anchor k) y = 1 := by
    intro z hz
    rcases hbuffer k with ⟨_, _, hψone, _, _, _, _, hξψ, _, hcut⟩
    have hψz : ψ k z = 1 := Filter.EventuallyEq.eq_of_nhds (hψone z hz)
    have hzψ : z ∈ tsupport (ψ k) := subset_tsupport (ψ k) (by
      simp [Function.mem_support, hψz])
    have hξz : ξ k z = 1 := hξψ z hzψ
    have hzξ : z ∈ tsupport (ξ k) := subset_tsupport (ξ k) (by
      simp [Function.mem_support, hξz])
    exact hcut z hzξ
  obtain ⟨θ, F, hproperties⟩ :=
    BufferedChartTransitionExtensions.exists_gated_chart_extensions A ξ hcξ htξ hξcut hcoord
  exact ⟨A, ξ, θ, F, hproperties⟩

end Poincare
