import Poincare.Global.MetricAdaptedLocalParametrix
open scoped Manifold ContDiff Topology
universe u
#check (∀ {M : Type u} [TopologicalSpace M] [T2Space M] [CompactSpace M] [ChartedSpace (Poincare.ClosedSmoothModel 3) M], ∀ [IsManifold (modelWithCornersSelf ℝ (Poincare.ClosedSmoothModel 3)) ((⊤ : ENat) : WithTop ENat) M], ∀ (A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M) (ξ : Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → ℝ),
 (∀ k, HasCompactSupport (ξ k)) →
 (∀ k, tsupport (ξ k) ⊆ (Poincare.FiniteAtlasParabolicTensorSpace.chart A k).target) →
 (∀ k, ∀ z ∈ tsupport (ξ k), Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor k) y = 1) (nhds z)) →
 (∀ k, ∀ z ∈ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A k, Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor k) y = 1) (nhds z)) → ∀ i j, let K := (Poincare.FiniteAtlasParabolicTensorSpace.chart A i) '' (tsupport (A.partition i) ∩ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).symm '' tsupport (ξ j)); let O := ((Poincare.FiniteAtlasParabolicTensorSpace.chart A i).symm.trans (Poincare.FiniteAtlasParabolicTensorSpace.chart A j)).source ∩
 (fun z : (Poincare.ClosedSmoothModel 3) => Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor i) y = 1) (nhds z)) ∩
 (Poincare.FiniteAtlasParabolicTensorSpace.change A i j) ⁻¹' (fun z : (Poincare.ClosedSmoothModel 3) => Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor j) y = 1) (nhds z)); IsCompact K ∧ IsOpen O ∧ K ⊆ O)
#check (∀ (U : Set (Poincare.ClosedSmoothModel 3)), IsOpen U → ∀ (f : (Poincare.ClosedSmoothModel 3) → (Poincare.ClosedSmoothModel 3)), ContDiffOn ℝ ((⊤ : ENat) : WithTop ENat) f U →
 ∀ (η : (Poincare.ClosedSmoothModel 3) → ℝ), ContDiff ℝ ((⊤ : ENat) : WithTop ENat) η → HasCompactSupport η → tsupport η ⊆ U →
 ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (fun z ↦ η z • f z) ∧ HasCompactSupport (fun z ↦ η z • f z))
#check (∀ {M : Type u} [TopologicalSpace M] [T2Space M] [CompactSpace M] [ChartedSpace (Poincare.ClosedSmoothModel 3) M], ∀ [IsManifold (modelWithCornersSelf ℝ (Poincare.ClosedSmoothModel 3)) ((⊤ : ENat) : WithTop ENat) M], ∀ (A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M) (ξ : Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → ℝ),
 (∀ k, HasCompactSupport (ξ k)) →
 (∀ k, tsupport (ξ k) ⊆ (Poincare.FiniteAtlasParabolicTensorSpace.chart A k).target) →
 (∀ k, ∀ z ∈ tsupport (ξ k), Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor k) y = 1) (nhds z)) →
 (∀ k, ∀ z ∈ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A k, Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor k) y = 1) (nhds z)) → ∃ θ : Fin A.cover.chartCount → Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → ℝ,
 ∃ F : Fin A.cover.chartCount → Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → (Poincare.ClosedSmoothModel 3),
 ∀ i j, let K := (Poincare.FiniteAtlasParabolicTensorSpace.chart A i) '' (tsupport (A.partition i) ∩ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).symm '' tsupport (ξ j)); let O := ((Poincare.FiniteAtlasParabolicTensorSpace.chart A i).symm.trans (Poincare.FiniteAtlasParabolicTensorSpace.chart A j)).source ∩
 (fun z : (Poincare.ClosedSmoothModel 3) => Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor i) y = 1) (nhds z)) ∩
 (Poincare.FiniteAtlasParabolicTensorSpace.change A i j) ⁻¹' (fun z : (Poincare.ClosedSmoothModel 3) => Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor j) y = 1) (nhds z));
   ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (θ i j) ∧ HasCompactSupport (θ i j) ∧
   (∀ z, θ i j z ∈ Set.Icc 0 1) ∧ tsupport (θ i j) ⊆ O ∧
   (∀ z ∈ K, Filter.Eventually (fun y ↦ θ i j y = 1) (nhds z)) ∧
   ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (F i j) ∧ HasCompactSupport (F i j) ∧
   (∀ z ∈ tsupport (θ i j), Filter.Eventually (fun y ↦ F i j y = Poincare.FiniteAtlasParabolicTensorSpace.change A i j y) (nhds z)) ∧
   ∃ L : NNReal, LipschitzWith L (F i j))
