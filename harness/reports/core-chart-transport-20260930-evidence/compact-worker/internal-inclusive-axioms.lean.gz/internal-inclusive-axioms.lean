import Lean
import Poincare.Global.CompactBufferedChartOverlap

open Lean Elab Command

run_cmd do
  let env := (← getEnv).setExporting false
  setEnv env
  let targetModule := `Poincare.Global.CompactBufferedChartOverlap
  let mut names : Array Name := #[]
  for (name, _) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      if env.header.moduleNames[idx]! == targetModule then
        names := names.push name
  if names.isEmpty then
    throwError "No declarations found in target module"
  let permitted : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  for name in names.qsort (fun a b => a.toString < b.toString) do
    let footprint ← collectAxioms name
    for axiomName in footprint do
      unless permitted.contains axiomName do
        throwError "Forbidden axiom {axiomName} in {name}"
    logInfo m!"{name}: {footprint}"
  logInfo m!"INTERNAL_INCLUSIVE_AXIOM_SCAN_OK: {names.size} declarations"
