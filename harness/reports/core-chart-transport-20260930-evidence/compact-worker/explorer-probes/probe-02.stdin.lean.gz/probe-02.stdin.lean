import Poincare.Global.FiniteAtlasParabolicTensorSpace
open Set
open scoped Manifold ContDiff Topology
open Poincare Poincare.FiniteAtlasParabolicTensorSpace
universe u
variable {M : Type u} [TopologicalSpace M] [T2Space M] [CompactSpace M]
  [ChartedSpace (ClosedSmoothModel 3) M]
  [IsManifold (closedSmoothModelWithCorners 3) ∞ M]
  (A : AtlasData M)
#check IsClosed.isCompact
example (i j : Fin A.cover.chartCount) :
    IsOpen ((chart A i).symm.trans (chart A j)).source := by
  change IsOpen ((chart A i).target ∩ (chart A i).symm ⁻¹' (chart A j).source)
  exact (continuousOn_extChartAt_symm (A.cover.anchor i)).isOpen_inter_preimage
    (isOpen_extChartAt_target (A.cover.anchor i)) (isOpen_extChartAt_source (A.cover.anchor j))
example (i j : Fin A.cover.chartCount) :
    ContinuousOn (change A i j) ((chart A i).symm.trans (chart A j)).source := by
  simpa [chart, change, PartialEquiv.trans_source, PartialEquiv.symm_source]
    using (continuousOn_extChartAt (I := closedSmoothModelWithCorners 3) (A.cover.anchor j)).comp_inter
      (continuousOn_extChartAt_symm (I := closedSmoothModelWithCorners 3) (A.cover.anchor i))
example (ξ : Fin A.cover.chartCount → ClosedSmoothModel 3 → ℝ)
    (hξcompact : ∀ k, HasCompactSupport (ξ k))
    (hξtarget : ∀ k, tsupport (ξ k) ⊆ (chart A k).target)
    (i j : Fin A.cover.chartCount) :
    IsCompact ((chart A i) '' (tsupport (A.partition i) ∩ (chart A j).symm '' tsupport (ξ j))) := by
  have hj : IsCompact ((chart A j).symm '' tsupport (ξ j)) :=
    (hξcompact j).isCompact.image_of_continuousOn
      ((continuousOn_extChartAt_symm (A.cover.anchor j)).mono (hξtarget j))
  have hbase : IsCompact (tsupport (A.partition i) ∩ (chart A j).symm '' tsupport (ξ j)) :=
    hj.inter_left (isClosed_tsupport _)
  exact hbase.image_of_continuousOn
    ((continuousOn_extChartAt (A.cover.anchor i)).mono (inter_subset_left.trans (partition_support_source A i)))
