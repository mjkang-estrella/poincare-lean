import Poincare.Global.FiniteAtlasParabolicTensorSpace
open Set
open scoped Manifold ContDiff Topology
#check ContinuousOn.isOpen_inter_preimage
#check isOpen_setOf_eventually_nhds
#check IsCompact.image_of_continuousOn
#check HasCompactSupport.isCompact
#check isCompact_of_isClosed
#check PartialEquiv.mem_symm_trans_source
#check PartialEquiv.left_inv
#check PartialEquiv.right_inv
#check continuousOn_extChartAt
#check continuousOn_extChartAt_symm
#check isOpen_extChartAt_source
#check isOpen_extChartAt_target
#check ContinuousOn.comp
#check ContinuousOn.comp'
#check ContinuousOn.comp_inter
