import Poincare.Global.ParabolicHolderSpace
import Poincare.Global.RiemannianContext
import Mathlib.Analysis.Calculus.ContDiff.RCLike
noncomputable section
open scoped ContDiff NNReal
#check @ContDiff.lipschitzWith_of_hasCompactSupport
#check @LinearMap.mkContinuous
#check @LinearMap.mkContinuous_norm_le
#check @LinearMap.mkContinuous_norm_le'
#check @LinearMap.mkContinuous_apply
#check @Poincare.ParabolicHolder.ofFunction
#check @Poincare.ParabolicHolder.norm_le_of_bounds
#check @Poincare.ParabolicHolder.ext
example {F : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3}
    (hF : ContDiff ℝ ∞ F) (hc : HasCompactSupport F) :
    ∃ K : ℝ≥0, LipschitzWith K F :=
  ContDiff.lipschitzWith_of_hasCompactSupport hc hF (by simp)
example {V W : Type*} [NormedAddCommGroup V] [NormedSpace ℝ V]
    [NormedAddCommGroup W] [NormedSpace ℝ W]
    (L : V →ₗ[ℝ] W) (C : ℝ) (hC : 0 ≤ C)
    (hbound : ∀ x, ‖L x‖ ≤ C * ‖x‖) :
    ‖L.mkContinuous C hbound‖ ≤ C :=
  L.mkContinuous_norm_le hC hbound
