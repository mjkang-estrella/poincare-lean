# Actual nonlinear parabolic Holder pullback: verified worker result

Base: e821fb6920b5ebb48e36a84792926caf8be75acd.
Branch: codex/core-holder-pullback-a01.
Owned source: Poincare/Global/ParabolicSpatialHolderPullback.lean only.

Core assumption helped: UniversalHamiltonConvergenceStatement, through genuine
DeTurck/Ricci-flow input construction. Subsequent consumers are the actual
nonlinear derivative-compatible Graph pullback and bounded destination-only
tensor gluing into X_M, followed by genuine global DeTurck L/P/R assembly.
The accepted preceding gated constructor produces the actual compact smooth
map F, so the new final theorem constructs Q directly from that map.

Proved the exact frozen export exists_spatial_Y_pullback. It derives
L:NNReal and LipschitzWith L F from compact smoothness of F. Nonlinear spatial
substitution satisfies parabolicDist(t,Fx)(s,Fy) <= max(1,L) times the original
parabolic distance. For alpha>=0 this gives the Holder seminorm bound with
K=max(1,L^alpha). Time is unchanged, so membership in the time cylinder and
zero_off both transfer. The actual Y.ofFunction carrier is constructed with
these bounds, and the sum norm is <= K times the original norm. Its linear
map in f becomes Q_T through LinearMap.mkContinuous. C=K is chosen before
every real T and bounds the actual operator norm, with equality of Q_T f and
f(t,Fx) on the entire ambient product.

No CompleteSpace V premise, restriction alpha<1, positivity of T, supplied
operator/bound, extra source weight or spatial support claim for Q_T f was
added. Empty time cylinders are handled by the original carrier API. The
helper distance/carrier/norm declarations are the genuine construction used
by the final export and reusable for the subsequent Graph proof.

All four scoped Task gates passed. The first compiler source attempt failed
only on NNReal notation scope and an E named-argument/local-notation collision;
its exact source/output/exit is retained. The corrected second source attempt
and fresh scoped source gate passed with no compiler messages. Read-only API
probe failure and successful retry are preserved under import-api-probe. The
internal-inclusive emitted module scan and its permitted-axiom summary are
recorded under emitted-axioms. No full build was run; the frozen audit performs
its required targeted module build.

This discharges the actual Y spatial-pullback construction obstacle, not core
Hamilton existence. Still unproved are derivative-compatible nonlinear Graph
transport, Jacobian/partition weights and compatible global tensor assembly,
true signed L/P/R identity and contraction, nonlinear inversion, ordinary
joint C3 at zero, general Ricci flow and later continuation/surgery/favorable
metric limits. Smoothability remains separately open. Worker has not accepted
or merged the Task; independent orchestrator acceptance remains required.
