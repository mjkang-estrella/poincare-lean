import Poincare.Global.DeTurckConstructedCovariance
import Poincare.Global.DeTurckCoordinateJointRegularityOverlap

noncomputable section
open Filter Set
open scoped Manifold ContDiff Topology
namespace TransitionApiProbe
universe u
local notation "E" => Poincare.ClosedSmoothModel 3
local notation "I" => Poincare.closedSmoothModelWithCorners 3
variable {M : Type u} [TopologicalSpace M] [T2Space M]
  [ChartedSpace E M] [IsManifold I ∞ M]

theorem overlap_open (a b : M) :
    IsOpen ((extChartAt I a).symm ≫ extChartAt I b).source := by
  rw [isOpen_iff_mem_nhds]
  intro y hy
  have hy' : y ∈ (extChartAt I a).target ∧
      (extChartAt I a).symm y ∈ (extChartAt I b).source := by
    simpa only [PartialEquiv.trans_source, PartialEquiv.symm_source] using hy
  have htarget := (isOpen_extChartAt_target a).mem_nhds hy'.1
  have hpreimage := (continuousAt_extChartAt_symm'' hy'.1).preimage_mem_nhds
    ((isOpen_extChartAt_source b).mem_nhds hy'.2)
  simpa only [PartialEquiv.trans_source, PartialEquiv.symm_source] using
    inter_mem htarget hpreimage

theorem transition_three (a b : M) {z : E}
    (hz : z ∈ (extChartAt I a).target)
    (hy : (extChartAt I a).symm z ∈ (extChartAt I b).source) :
    ContDiffAt ℝ 3 (Poincare.GeodesicTransport.chartTransition a b) z := by
  apply Poincare.DeTurckCoordinateJointRegularityOverlap.chartTransition_contDiffAt_three_of_mem_source
  rw [PartialEquiv.trans_source, PartialEquiv.symm_source]
  exact ⟨hz, hy⟩

theorem overlap_eventually (a b : M) {z : E}
    (hz : z ∈ (extChartAt I a).target)
    (hy : (extChartAt I a).symm z ∈ (extChartAt I b).source) :
    ∀ᶠ y : E in nhds z, y ∈ (extChartAt I a).target ∧
      (extChartAt I a).symm y ∈ (extChartAt I b).source := by
  have hz' : z ∈ ((extChartAt I a).symm ≫ extChartAt I b).source := by
    rw [PartialEquiv.trans_source, PartialEquiv.symm_source]
    exact ⟨hz, hy⟩
  simpa only [PartialEquiv.trans_source, PartialEquiv.symm_source] using
    (overlap_open a b).mem_nhds hz'

theorem transition_three_direct (a b : M) {z : E}
    (hz : z ∈ (extChartAt I a).target)
    (hy : (extChartAt I a).symm z ∈ (extChartAt I b).source) :
    ContDiffAt ℝ 3 (Poincare.GeodesicTransport.chartTransition a b) z := by
  have hz' : z ∈ ((extChartAt I a).symm ≫ extChartAt I b).source := by
    rw [PartialEquiv.trans_source, PartialEquiv.symm_source]
    exact ⟨hz, hy⟩
  have h := contDiffWithinAt_ext_coord_change (I := I) (n := 3) b a hz'
  have hAt : ContDiffAt ℝ 3 ((extChartAt I b) ∘ (extChartAt I a).symm) z := by
    simpa [ModelWithCorners.range_eq_univ] using h
  simpa [Poincare.GeodesicTransport.chartTransition] using hAt

end TransitionApiProbe
