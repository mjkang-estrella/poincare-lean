from pathlib import Path
import subprocess,json,datetime,time,os,sys,hashlib
root=Path('/Users/mjkang/.codex/worktrees/core-c2-covariance/poincare')
evidence=Path('/Users/mjkang/.codex/worktrees/incremental-verification/poincare/harness/v2/state/core-deturck-c2-covariance-20260930/c2-covariance-a01')
name=sys.argv[1]
argv=sys.argv[2:]
out=evidence/name
out.mkdir(exist_ok=False)
source=root/'Poincare/Global/DeTurckC2Covariance.lean'
(out/'DeTurckC2Covariance.lean').write_bytes(source.read_bytes())
(out/'diff.patch').write_bytes(subprocess.check_output(['git','diff','--no-index','--','/dev/null',str(source)],cwd=root) if False else subprocess.run(['git','diff','--no-index','--','/dev/null',str(source)],cwd=root,capture_output=True).stdout)
started=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
(out/'argv.json').write_text(json.dumps({'argv':argv,'cwd':str(root),'started':started},indent=2)+'\n')
with (out/'stdout.log').open('wb') as stdout, (out/'stderr.log').open('wb') as stderr:
    r=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
result={'argv':argv,'exit':r.returncode,'seconds':time.monotonic()-t,'started':started,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
print((out/'stdout.log').read_text())
print((out/'stderr.log').read_text())
sys.exit(r.returncode)
