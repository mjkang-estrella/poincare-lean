# C2 covariance worker report

Date: 2026-09-30T15:41:58.897237+00:00
Backend: local Codex helper; not a registered Pi or Leanstral Job.
Task: core-input-20260930-c2-covariance revision 1
Base: 0f86dc9978ab147335c32a625b6ffe170510932a
Branch: codex/core-c2-covariance-a01
Commit: 11cdec73a929fc8a494b0c96174c16c4c140694c
Owned diff: Poincare/Global/DeTurckC2Covariance.lean only
Result: ready for independent orchestrator review; worker has not accepted or merged.

## Mathematical content

The exact frozen differential_covariance declaration is proved. The proof
constructs F = realized eta q (phi z) in the genuine chart2 target from q's
symmetric C2 germ. F has the exact value, D and D2 of q there. chartLift F is
recovered in chart2 by eventual equality on its open target before either
spatial derivative. The independently accepted overlap theorem supplies the
actual transition C3 and equality of the chart1 lift tuple with T F. The
pullback_twoJet_congr theorem transfers q/F matched two-jets through both
tensor slots to T q/T F. Those actual tuple equalities rewrite the complete
DeTurckJetLinearization.differential in constructed metric-variation covariance.
No new premise, norm, target interpretation or scalar reduction is added.

## Attempts and gates

The required prerequisite-only OverlapJets build passed. Three source compiler
attempts are preserved: compile-01 stopped on unconstrained model dimension in
the local transition binding; compile-02 stopped on a failed automatic order
simplification for reducing smooth F to C2; compile-03 passed with no diagnostics.
The repairs were only a type annotation and the explicit existing ENat order lemma.

The four exact Task gates passed: compile-03, gate-token, gate-diff, gate-contract.
The contract reports AXIOM_CONTRACT_OK and FROZEN_CONTRACT_OK. Additional staged
source whitespace validation passed (source-staged-whitespace). The exploratory
no-index whitespace invocation returned 1 with no output because the new file
itself differs from /dev/null; the staged check returned 0. Copied Task/context
and all frozen definition hashes still match the starting context manifest.

Every run directory retains source, diff, argv, stdout, stderr, exit and timing.
final.diff.patch is the actual base-to-commit diff. No full build, integration,
merge, service action, deletion or forbidden file edit occurred.
