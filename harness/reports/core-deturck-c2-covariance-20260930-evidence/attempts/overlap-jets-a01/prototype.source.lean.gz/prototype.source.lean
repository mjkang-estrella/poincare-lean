import Poincare.Global.DeTurckChartLiftCoordinates
import Poincare.Global.DeTurckChartIndependentPullback

noncomputable section
open Filter Set
open scoped Manifold ContDiff Topology
namespace TransitionApiProbe
universe u
local notation "E" => Poincare.ClosedSmoothModel 3
local notation "𝓙" => Poincare.closedSmoothModelWithCorners 3
variable {M : Type u} [TopologicalSpace M] [T2Space M]
  [ChartedSpace E M] [IsManifold 𝓙 ∞ M]

theorem overlap_open (a b : M) :
    IsOpen ((extChartAt 𝓙 a).symm ≫ extChartAt 𝓙 b).source := by
  rw [isOpen_iff_mem_nhds]
  intro y hy
  have hy' : y ∈ (extChartAt 𝓙 a).target ∧
      (extChartAt 𝓙 a).symm y ∈ (extChartAt 𝓙 b).source := by
    simpa only [PartialEquiv.trans_source, PartialEquiv.symm_source] using hy
  have htarget := (isOpen_extChartAt_target a).mem_nhds hy'.1
  have hpreimage := (continuousAt_extChartAt_symm'' hy'.1).preimage_mem_nhds
    ((isOpen_extChartAt_source b).mem_nhds hy'.2)
  simpa only [PartialEquiv.trans_source, PartialEquiv.symm_source] using
    inter_mem htarget hpreimage

theorem overlap_eventually (a b : M) {z : E}
    (hz : z ∈ (extChartAt 𝓙 a).target)
    (hy : (extChartAt 𝓙 a).symm z ∈ (extChartAt 𝓙 b).source) :
    ∀ᶠ y : E in nhds z, y ∈ (extChartAt 𝓙 a).target ∧
      (extChartAt 𝓙 a).symm y ∈ (extChartAt 𝓙 b).source := by
  have hz' : z ∈ ((extChartAt 𝓙 a).symm ≫ extChartAt 𝓙 b).source := by
    rw [PartialEquiv.trans_source, PartialEquiv.symm_source]
    exact ⟨hz, hy⟩
  simpa only [PartialEquiv.trans_source, PartialEquiv.symm_source] using
    (overlap_open a b).mem_nhds hz'

theorem transition_three_direct (a b : M) {z : E}
    (hz : z ∈ (extChartAt 𝓙 a).target)
    (hy : (extChartAt 𝓙 a).symm z ∈ (extChartAt 𝓙 b).source) :
    ContDiffAt ℝ 3 (Poincare.GeodesicTransport.chartTransition a b) z := by
  have hz' : z ∈ ((extChartAt 𝓙 a).symm ≫ extChartAt 𝓙 b).source := by
    rw [PartialEquiv.trans_source, PartialEquiv.symm_source]
    exact ⟨hz, hy⟩
  have h := contDiffWithinAt_ext_coord_change (I := 𝓙) (n := 3) b a hz'
  have hAt : ContDiffAt ℝ 3 ((extChartAt 𝓙 b) ∘ (extChartAt 𝓙 a).symm) z := by
    simpa [ModelWithCorners.range_eq_univ] using h
  simpa [Poincare.GeodesicTransport.chartTransition] using hAt


local notation "Bilin" => E →L[ℝ] E →L[ℝ] ℝ

theorem chartMetric_transport_eventually
    (H : ∀ x : M, TangentSpace 𝓙 x →L[ℝ] TangentSpace 𝓙 x →L[ℝ] ℝ)
    (a b : M) {z : E}
    (hz : z ∈ (extChartAt 𝓙 a).target)
    (hy : (extChartAt 𝓙 a).symm z ∈ (extChartAt 𝓙 b).source) :
    CovariantDerivative.chartMetric H a =ᶠ[nhds z]
      (fun y => Poincare.pullbackBilinearForm
        (CovariantDerivative.chartMetric H b (Poincare.GeodesicTransport.chartTransition a b y))
        (fderiv ℝ (Poincare.GeodesicTransport.chartTransition a b) y)) := by
  filter_upwards [overlap_eventually a b hz hy] with y hy'
  ext v w
  exact (Poincare.chartBilinearTensor_chartTransitionDeriv H a b hy'.1 hy'.2 v w).symm

theorem chartLift_transport_eventually
    (a b : M) (F : E → Bilin) {z : E}
    (hz : z ∈ (extChartAt 𝓙 a).target)
    (hy : (extChartAt 𝓙 a).symm z ∈ (extChartAt 𝓙 b).source) :
    CovariantDerivative.chartMetric (Poincare.DeTurckChartLift.chartLift b F) a =ᶠ[nhds z]
      (fun y => Poincare.pullbackBilinearForm
        (F (Poincare.GeodesicTransport.chartTransition a b y))
        (fderiv ℝ (Poincare.GeodesicTransport.chartTransition a b) y)) := by
  filter_upwards [overlap_eventually a b hz hy,
    chartMetric_transport_eventually (Poincare.DeTurckChartLift.chartLift b F) a b hz hy]
    with y hy' htransport
  rw [htransport]
  rw [Poincare.DeTurckChartLift.chartMetric_chartLift b F _]
  exact (extChartAt 𝓙 b).map_source hy'.2

theorem chartLift_transport_twoJet
    (a b : M) (F : E → Bilin) {z : E}
    (hz : z ∈ (extChartAt 𝓙 a).target)
    (hy : (extChartAt 𝓙 a).symm z ∈ (extChartAt 𝓙 b).source) :
    let FA := CovariantDerivative.chartMetric (Poincare.DeTurckChartLift.chartLift b F) a
    let TF := fun y => Poincare.pullbackBilinearForm
        (F (Poincare.GeodesicTransport.chartTransition a b y))
        (fderiv ℝ (Poincare.GeodesicTransport.chartTransition a b) y)
    FA z = TF z ∧ fderiv ℝ FA z = fderiv ℝ TF z ∧
      fderiv ℝ (fderiv ℝ FA) z = fderiv ℝ (fderiv ℝ TF) z := by
  dsimp only
  have heq := chartLift_transport_eventually a b F hz hy
  exact ⟨heq.eq_of_nhds, heq.fderiv_eq, heq.fderiv.fderiv_eq⟩

end TransitionApiProbe
