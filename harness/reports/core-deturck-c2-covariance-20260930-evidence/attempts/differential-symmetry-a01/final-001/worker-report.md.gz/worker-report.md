# Worker result for differential symmetry

Base: c3bed4788afb1c82db848590cb45ee148fd5884b
Commit: 38d377b27da688d2c64f9740e9e10058ed989800
Owned module: Poincare/Global/DeTurckDifferentialSymmetry.lean
Source SHA256: 0352ef9b6cdbda4a48217d6454c9527283ed95fdf4b012756c5cfd026b759517

Lean checks the exact frozen declaration
Poincare.DeTurckDifferentialSymmetry.differential_and_lower_symmetric.
Both full DQ output and combined zeroOrder(q)+firstOrder(Dq) are symmetric
in all tensor vectors, at actual initial/background metric jets.

The proof constructs compact smooth symmetric F with the germ's exact
value/D/D2, lifts it through the true chart, constructs a genuine metric
variation, and derives a common affine inner germ. Whole-target chart recovery
is used as a neighborhood identity before differentiating spatially twice.
Actual geometric evolution symmetry follows from canonical Ricci symmetry,
Lie derivative symmetry and chartMetric symmetry. Derivative uniqueness after
two fixed-vector evaluations gives full DQ symmetry. The accepted actual
coefficient decomposition and symmetric principal contraction give lower
symmetry without dropping inverse variation against D2g0.

Compiler attempt 001 failed only because the simp term principal was ambiguous
with Filter.principal. Its source and full output remain preserved.
Compiler attempt 002 passed, exit 0, and its bytes equal the committed module.
All four Task gates passed. Frozen gate reports AXIOM_CONTRACT_OK and
FROZEN_CONTRACT_OK. Gates and compiler source/argv/stdout/stderr/exit/timing
are preserved in sibling compile-* and gates-001 directories.

Only the owned module is committed. Copied Task/contract/readback metadata
remains untracked. No root, definition, service, merge, acceptance or deletion
change was made. No full root build was launched.

First root action: independently inspect this exact-base diff and rerun the
frozen Task gate before deciding acceptance or integration.
