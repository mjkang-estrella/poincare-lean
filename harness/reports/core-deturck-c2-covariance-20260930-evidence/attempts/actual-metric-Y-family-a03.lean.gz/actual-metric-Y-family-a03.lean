import Poincare.Global.BufferedTensorValueTransport
import Poincare.Global.MetricAdaptedGlobalParametrix
import Poincare.Global.SmoothInitialMetricExistence
noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 300000
open Set Filter
open scoped Manifold ContDiff Topology
universe u
namespace Poincare.ActualYTransportApplication
open FiniteAtlasParabolicTensorSpace
example (M : Type u) [TopologicalSpace M] [T2Space M] [CompactSpace M]
    [ChartedSpace (ClosedSmoothModel 3) M]
    [IsManifold (closedSmoothModelWithCorners 3) ∞ M]
    (α : ℝ) (hα : 0 < α) (hα1 : α < 1) :
    ∃ (g0 : ClosedSmoothRiemannianMetric 3 M) (A : AtlasData M)
      (ξ : Fin A.cover.chartCount → ClosedSmoothModel 3 → ℝ)
      (θ : Fin A.cover.chartCount → Fin A.cover.chartCount → ClosedSmoothModel 3 → ℝ)
      (F : Fin A.cover.chartCount → Fin A.cover.chartCount → ClosedSmoothModel 3 → ClosedSmoothModel 3),
    (∀ i, ContDiff ℝ ∞ (ξ i) ∧ tsupport (ξ i) ⊆ (chart A i).target ∧
      (∀ z ∈ coordSupport A i, ξ i z = 1) ∧
      ∀ z ∈ tsupport (ξ i),
        (CovariantDerivative.chartMetric (I := closedSmoothModelWithCorners 3)
          g0.inner (A.cover.anchor i) z).IsInvertible) ∧
    (∀ i j,
      ContDiff ℝ ∞ (θ i j) ∧ HasCompactSupport (θ i j) ∧
      ContDiff ℝ ∞ (F i j) ∧ HasCompactSupport (F i j) ∧
      tsupport (θ i j) ⊆ ((chart A i).symm.trans (chart A j)).source ∧
      (∀ z ∈ tsupport (θ i j), ∀ᶠ y in nhds z, F i j y = change A i j y) ∧
      ∀ z ∈ (chart A i) '' (tsupport (A.partition i) ∩ (chart A j).symm '' tsupport (ξ j)),
        θ i j z = 1) ∧
    ∃ C : Fin A.cover.chartCount → Fin A.cover.chartCount → Fin 3 → Fin 3 → ℝ,
      (∀ i j c d, 0 ≤ C i j c d) ∧ ∀ T : ℝ, ∀ i j c d,
      ∃ Q : ((Fin 3 × Fin 3) → Scalar α T) →L[ℝ] Scalar α T,
        ‖Q‖ ≤ C i j c d ∧
        (∀ w p, Q w p = ∑ a : Fin 3, ∑ b : Fin 3,
          BufferedTensorGraphTransport.weight A i (θ i j) (ξ j) (F i j) a b c d p.2 *
          w (a,b) (p.1,F i j p.2)) ∧
        ∀ w t z, z ∉ coordSupport A i → Q w (t,z) = 0 := by
  classical
  obtain ⟨g0⟩ := SmoothInitialMetricExistence.exists_initial_metric (M := M)
  obtain ⟨A, ψ, ξ, hbuffer, θ, F, hgate, hrest⟩ :=
    MetricAdaptedGlobalParametrix.exists_metric_adapted_global_parametrix g0 α hα hα1
  refine ⟨g0, A, ξ, θ, F, ?_, ?_, ?_⟩
  · intro i
    refine ⟨(hbuffer i).2.2.2.2.1, (hbuffer i).2.2.2.2.2.2.2.2.1, ?_⟩
    constructor
    · intro z hz
      have hψ : ψ i z = 1 := Filter.EventuallyEq.eq_of_nhds ((hbuffer i).2.2.1 z hz)
      have hzψ : z ∈ tsupport (ψ i) := subset_tsupport _ (by simp [Function.mem_support,hψ])
      exact (hbuffer i).2.2.2.2.2.2.2.1 z hzψ
    · intro z hz
      exact DeTurckPrincipalIdentity.chartMetric_isInvertible_of_cutoff g0
        (A.cover.anchor i) z ((hbuffer i).2.2.2.2.2.2.2.2.2 z hz)
  · intro i j
    exact ⟨(hgate i j).1, (hgate i j).2.1, (hgate i j).2.2.2.2.2.1,
      (hgate i j).2.2.2.2.2.2.1, (hgate i j).2.2.2.1,
      (hgate i j).2.2.2.2.2.2.2.1,
      fun z hz => Filter.EventuallyEq.eq_of_nhds ((hgate i j).2.2.2.2.1 z hz)⟩
  · have hrow (i j : Fin A.cover.chartCount) (c d : Fin 3) :=
      BufferedTensorGraphTransport.exists_destination_Y_entry_transport M A i j
        (θ i j) (ξ j) (F i j) c d (hgate i j).1 (hgate i j).2.1
        (hbuffer j).2.2.2.2.1 (hgate i j).2.2.2.2.2.1
        (hgate i j).2.2.2.2.2.2.1 (hgate i j).2.2.2.1
        (hgate i j).2.2.2.2.2.2.2.1
        (fun z hz => Filter.EventuallyEq.eq_of_nhds ((hgate i j).2.2.2.2.1 z hz))
        α hα hα1
    choose C hC hfamily using hrow
    refine ⟨C, hC, ?_⟩
    intro T i j c d
    obtain ⟨Q,hQ,hraw,hsupport,_⟩ := hfamily i j c d T
    exact ⟨Q,hQ,hraw,hsupport⟩
end Poincare.ActualYTransportApplication
