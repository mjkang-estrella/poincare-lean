import Poincare.Global.BufferedTensorGraphTransportWeights
import Poincare.Global.BufferedTensorGraphTransportValues
import Poincare.Global.ParabolicSpatialHolderPullback
import Poincare.Global.ParabolicCutoffCommutator

noncomputable section
set_option autoImplicit false
open Set
open Poincare FiniteAtlasParabolicTensorSpace

namespace RowApi
variable {α T : ℝ}

def multiplier (f : Scalar α T) : Scalar α T →L[ℝ] Scalar α T := by
  let m : Scalar α T →ₗ[ℝ] Scalar α T := {
    toFun := fun g => f * g
    map_add' := by
      intro g h
      apply ParabolicHolder.ext
      intro p hp
      change f p * (g p + h p) = f p * g p + f p * h p
      ring
    map_smul' := by
      intro c g
      apply ParabolicHolder.ext
      intro p hp
      change f p * (c • g p) = c • (f p * g p)
      ring }
  exact m.mkContinuous ‖f‖ (ParabolicHolder.norm_mul_le f)

example (f : Scalar α T) : ‖multiplier f‖ ≤ ‖f‖ := by
  exact ContinuousLinearMap.opNorm_le_bound _ (norm_nonneg f)
    (ParabolicHolder.norm_mul_le f)

example
    (K : Fin 3 → Fin 3 → ℝ) (hK : ∀ a b, 0 ≤ K a b)
    (f : Fin 3 → Fin 3 → Scalar α T) (hf : ∀ a b, ‖f a b‖ ≤ K a b)
    (CF : ℝ) (hCF : 0 ≤ CF) (P : Scalar α T →L[ℝ] Scalar α T)
    (hP : ‖P‖ ≤ CF)
    (F : ClosedSmoothModel 3 → ClosedSmoothModel 3)
    (hPvalue : ∀ g p, P g p = g (p.1,F p.2))
    (weight : Fin 3 → Fin 3 → ClosedSmoothModel 3 → ℝ)
    (hfvalue : ∀ a b p, p ∈ ParabolicHolder.cylinder T → f a b p = weight a b p.2) :
    ∃ B : ((Fin 3 × Fin 3) → Scalar α T) →L[ℝ] Scalar α T,
      ‖B‖ ≤ (∑ a : Fin 3, ∑ b : Fin 3, K a b) * CF ∧
      ∀ w p, B w p = ∑ a : Fin 3, ∑ b : Fin 3,
        weight a b p.2 * w (a,b) (p.1,F p.2) := by
  classical
  let bound : ℝ := (∑ a : Fin 3, ∑ b : Fin 3, K a b) * CF
  have hbound0 : 0 ≤ bound :=
    mul_nonneg (Finset.sum_nonneg fun a _ => Finset.sum_nonneg fun b _ => hK a b) hCF
  let B : ((Fin 3 × Fin 3) → Scalar α T) →L[ℝ] Scalar α T :=
    ∑ a : Fin 3, ∑ b : Fin 3,
      ((multiplier (f a b)).comp P).comp (ContinuousLinearMap.proj (a,b))
  have hBN : ‖B‖ ≤ bound := by
    apply ContinuousLinearMap.opNorm_le_bound B hbound0
    intro w
    have hpart (a b : Fin 3) : ‖f a b * P (w (a,b))‖ ≤ K a b * CF * ‖w‖ := by
      calc
        _ ≤ ‖f a b‖ * ‖P (w (a,b))‖ := ParabolicHolder.norm_mul_le _ _
        _ ≤ K a b * (CF * ‖w‖) := by
          apply mul_le_mul (hf a b)
            ((P.le_opNorm _).trans ((mul_le_mul_of_nonneg_right hP
              (norm_nonneg _)).trans (mul_le_mul_of_nonneg_left
                (norm_le_pi_norm w (a,b)) hCF)))
            (norm_nonneg _) (hK a b)
        _ = _ := by ring
    calc
      ‖B w‖ = ‖∑ a : Fin 3, ∑ b : Fin 3, f a b * P (w (a,b))‖ := by
        simp only [B, ContinuousLinearMap.sum_apply, ContinuousLinearMap.comp_apply,
          ContinuousLinearMap.proj_apply, multiplier, LinearMap.mkContinuous_apply,
          LinearMap.coe_mk, AddHom.coe_mk]
      _ ≤ ∑ a : Fin 3, ∑ b : Fin 3, ‖f a b * P (w (a,b))‖ :=
        (norm_sum_le _ _).trans (Finset.sum_le_sum fun a _ => norm_sum_le _ _)
      _ ≤ ∑ a : Fin 3, ∑ b : Fin 3, K a b * CF * ‖w‖ :=
        Finset.sum_le_sum fun a _ => Finset.sum_le_sum fun b _ => hpart a b
      _ = bound * ‖w‖ := by simp only [bound, Finset.sum_mul, mul_assoc]
  refine ⟨B, hBN, ?_⟩
  intro w p
  change evalY α T p (B w) = _
  simp only [B, ContinuousLinearMap.sum_apply, ContinuousLinearMap.comp_apply,
    ContinuousLinearMap.proj_apply, map_sum]
  apply Finset.sum_congr rfl
  intro a _
  apply Finset.sum_congr rfl
  intro b _
  change (f a b * P (w (a,b))) p = _
  rw [ParabolicHolder.mul_apply, hPvalue]
  by_cases hp : p ∈ ParabolicHolder.cylinder T
  · rw [hfvalue a b p hp]
  · have hpoff : (p.1,F p.2) ∉ ParabolicHolder.cylinder T :=
      fun h => hp ⟨h.1, mem_univ _⟩
    rw [ParabolicHolder.zero_off (w (a,b)) hpoff, mul_zero, mul_zero]

#check LinearMap.mkContinuous
#check LinearMap.mkContinuous_norm_le
#check norm_sum_le
#check norm_le_pi_norm
#check ContinuousLinearMap.sum_apply
#check ParabolicHolderMultiplier.sum_apply

end RowApi
