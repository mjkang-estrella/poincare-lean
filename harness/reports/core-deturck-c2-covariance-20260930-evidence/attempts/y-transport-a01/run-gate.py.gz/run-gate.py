from pathlib import Path
import json, subprocess, sys, time, datetime, shutil
root = Path(__file__).parent
w = Path('/Users/mjkang/.codex/worktrees/core-Y-tensor-transport/poincare')
label = sys.argv[1]
argv = json.loads(sys.argv[2])
e = root / label
e.mkdir(exist_ok=False)
source = w / 'Poincare/Global/BufferedTensorValueTransport.lean'
shutil.copy2(source, e / 'source.lean')
(e / 'argv.json').write_text(json.dumps(argv, indent=2)+'\n')
start = time.monotonic()
meta = {'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'cwd': str(w)}
with (e / 'stdout.log').open('wb') as out, (e / 'stderr.log').open('wb') as err:
    proc = subprocess.run(argv, cwd=w, stdout=out, stderr=err)
meta.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-start, exit_code=proc.returncode)
(e / 'result.json').write_text(json.dumps(meta, indent=2)+'\n')
print(json.dumps(meta))
print((e / 'stdout.log').read_text())
print((e / 'stderr.log').read_text())
sys.exit(proc.returncode)
