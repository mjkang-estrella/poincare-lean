import Poincare.Global.ParabolicSpatialHolderPullback
import Poincare.Global.ParabolicCutoffCommutator
open scoped ContDiff Topology
#check (∀ (F : (Poincare.ClosedSmoothModel 3) → (Poincare.ClosedSmoothModel 3)), ContDiff ℝ ((⊤ : ENat) : WithTop ENat) F →
∀ (α T : ℝ) (G : Poincare.ParabolicSolutionGraph.Graph (E := (Poincare.ClosedSmoothModel 3)) α T) (t : ℝ), t ∈ Set.Icc 0 T → ∀ x : (Poincare.ClosedSmoothModel 3),
HasFDerivAt (fun z ↦ (G.du (t, F z)).comp (fderiv ℝ F z))
 (((ContinuousLinearMap.compL ℝ (Poincare.ClosedSmoothModel 3) (Poincare.ClosedSmoothModel 3) ℝ).flip (fderiv ℝ F x)).comp ((G.ddu (t, F x)).comp (fderiv ℝ F x)) +
  ((ContinuousLinearMap.compL ℝ (Poincare.ClosedSmoothModel 3) (Poincare.ClosedSmoothModel 3) ℝ) (G.du (t, F x))).comp (fderiv ℝ (fderiv ℝ F) x)) x)
#check (∃ C : ℝ, 0 ≤ C ∧ ∀ (α T : ℝ) (dF : Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ((Poincare.ClosedSmoothModel 3) →L[ℝ] (Poincare.ClosedSmoothModel 3))),
∃ P : (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ((Poincare.ClosedSmoothModel 3) →L[ℝ] (Poincare.ClosedSmoothModel 3) →L[ℝ] ℝ)) →L[ℝ] (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ((Poincare.ClosedSmoothModel 3) →L[ℝ] (Poincare.ClosedSmoothModel 3) →L[ℝ] ℝ)), ‖P‖ ≤ C * ‖dF‖ ^ 2 ∧
∀ B p (v w : (Poincare.ClosedSmoothModel 3)), P B p v w = B p (dF p v) (dF p w))
#check (∀ (F : (Poincare.ClosedSmoothModel 3) → (Poincare.ClosedSmoothModel 3)), ContDiff ℝ ((⊤ : ENat) : WithTop ENat) F → HasCompactSupport F →
∀ (α : ℝ), 0 < α → α < 1 → ∃ C : ℝ, 0 ≤ C ∧ ∀ T ∈ Set.Ioc (0 : ℝ) 1,
∃ Q : (Poincare.ParabolicSolutionGraph.Graph (E := (Poincare.ClosedSmoothModel 3)) α T) →L[ℝ] (Poincare.ParabolicSolutionGraph.Graph (E := (Poincare.ClosedSmoothModel 3)) α T), ‖Q‖ ≤ C ∧ ∀ G p,
 (Q G).u p = G.u (p.1, F p.2) ∧
 (Q G).ut p = G.ut (p.1, F p.2) ∧
 (∀ v : (Poincare.ClosedSmoothModel 3), (Q G).du p v = G.du (p.1, F p.2) (fderiv ℝ F p.2 v)) ∧
 (∀ v w : (Poincare.ClosedSmoothModel 3), (Q G).ddu p v w =
   G.ddu (p.1, F p.2) (fderiv ℝ F p.2 v) (fderiv ℝ F p.2 w) +
   G.du (p.1, F p.2) (fderiv ℝ (fderiv ℝ F) p.2 v w)))
