# Actual Graph assembly recipe (unproved implementation notes)

Use actual existing Y pullback for values, covectors and Hessians, with
constants chosen before T. For F infinity/compact, DF and D2F are also smooth
compact by hF.fderiv_right/hcF.fderiv. Existing exists_cutoff_carrier produces
DF_T and DDF_T with common bounds K1,K2 and exact values on cylinder T.

Fix E=E3, Cov=E->L Real, End=E->L E, Hess=E->L Cov, DDF=E->L End.
The genuine bilinear cross map from Cov and DDF to Hess is
  (ContinuousLinearMap.compL Real E End Cov).comp
    (ContinuousLinearMap.compL Real E E Real).
Its evaluation is ell(DDF(v)(w)). This is an actual fixed CLM, not a supplied
bound assumption. Norms of compL give a fixed finite factor.

Use Hessian carrier operator H_T from the independently verified helper,
constructed with DF_T, and carrier pullbacks Qu/Qcov/Qhess. Define:
  u=Qu G.u; ut=Qu G.ut;
  du=bilinearY (compL Real E E Real) (Qcov G.du) DF_T;
  ddu=H_T(Qhess G.ddu)+bilinearY crossMap (Qcov G.du) DDF_T.
Zero trace follows from the actual Qu value identity and G.zero_trace.
The first derivative is G.hasFDeriv at F(x) composed with DF(x). The
second derivative uses ParabolicSpatialPullbackChainRule; its explicit CLM
sum matches ddu by ext v,w and compL application. Within-time derivative
is G.hasDeriv_time at F(x), with all-point Qu identity; no ordinary derivative
at time zero is inferred.

For every t in Icc0T, (t,z) lies in cylinder for every z, so DF_T and DDF_T
agree with actual derivatives throughout each spatial derivative proof.
For explicit jet identities at all p, split p in cylinder vs outside; outside
all Y fields vanish and spatial substitution preserves cylinder membership.

Use norm_bilinearY_le and the Hessian operator bound, actual Qu/Qcov/Qhess
opNorm bounds and K1,K2. A coarse common C is sufficient and must be chosen
before T. The unchanged Graph norm is the sum of its four carrier norms.
Build a linear map in G with Graph.ext_of_u for T>0 (only u needed to show
add/smul since all derivative certificates are present), then mkContinuous
from the genuine four-component norm estimate. Preserve all frozen explicit
u,ut,du,ddu evaluation identities.

No graph output spatial compact support is asserted; destination tensor
transport later multiplies actual gates/partition/outer buffer. No uniform
operator or derivative control is accepted as a new assumption.
