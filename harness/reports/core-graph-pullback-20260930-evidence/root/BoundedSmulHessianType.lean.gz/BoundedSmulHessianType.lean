import Poincare.Global.ParabolicSpatialHolderPullback
import Poincare.Global.ParabolicCutoffCommutator
#check (letI : IsBoundedSMul ℝ ((Poincare.ClosedSmoothModel 3) →L[ℝ] (Poincare.ClosedSmoothModel 3) →L[ℝ] ℝ) := .of_norm_smul_le (fun c A ↦ ContinuousLinearMap.opNorm_smul_le c A); ∃ C : ℝ, 0 ≤ C ∧ ∀ (α T : ℝ) (dF : Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ((Poincare.ClosedSmoothModel 3) →L[ℝ] (Poincare.ClosedSmoothModel 3))),
∃ P : (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ((Poincare.ClosedSmoothModel 3) →L[ℝ] (Poincare.ClosedSmoothModel 3) →L[ℝ] ℝ)) →L[ℝ] (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ((Poincare.ClosedSmoothModel 3) →L[ℝ] (Poincare.ClosedSmoothModel 3) →L[ℝ] ℝ)), ‖P‖ ≤ C * ‖dF‖ ^ 2 ∧
∀ B p (v w : (Poincare.ClosedSmoothModel 3)), P B p v w = B p (dF p v) (dF p w))
