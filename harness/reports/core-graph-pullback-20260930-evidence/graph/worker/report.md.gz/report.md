# Graph pullback worker result

Date: 2026-09-29 (local).
Task: core-input-20260930-graph-pullback, revision 1.
Authoritative task snapshot is preserved as task.json.
Base: 536cc4bb9aec4fce4eb85cfbe8cc70b00597d4cf.
Branch: codex/core-graph-pullback-a01.
Outcome: exact frozen target implemented; pending independent orchestrator review.

## Actual proof

The new single owned source file proves
Poincare.ParabolicSpatialGraphPullback.exists_spatial_Graph_pullback.
Its only inputs are the frozen compact smooth F and 0<alpha<1.
Actual compact derivative support/smoothness APIs produce DF and DDF carrier
norm bounds before T. The existing nonlinear Y pullback constructs u/ut and
pulls back covector/Hessian carriers. The landed Hessian operator substitutes
DF in both Hessian slots. A fixed bilinear composition map adds the genuine
covector-DDF term. The landed covector chain rule certifies the spatial
derivative of du. Spatial certificates, zero initial trace, and the original
within-Icc time certificate belong to the constructed Graph.

The norm estimate is the original sum of u, ut, du and ddu carrier norms.
Its constant is selected before every T in Ioc 0 1. Linearity follows from
Graph.ext_of_u using T>0, after all derivative certificates are constructed.
Every frozen u/ut/du/ddu identity holds on the entire ambient product,
including off-cylinder zero extension. No compact support for the output
Graph or ordinary ambient time derivative at zero is asserted.

## Verification

All four exact Task commands passed (gate-results.json, gate-01..04.log/exit).
The frozen audit built only its requested target module, then checked the
unapplied raw frozen type and permitted endpoint axioms. Source compilation
has no warnings. A staged whitespace check also passed.
The internal-inclusive module scan passed for 80 emitted declarations;
all footprints were subsets of propext, Classical.choice and Quot.sound.
Names and footprints are in axiom-scan-detail.log, with its Lean source
and exit/results preserved. It does not expand registry types or values.

## Attempt evidence

source-001..005.lean and lean-001..005.log/exit preserve each compiler attempt.
Early elaboration issues were local nested-CLM instance synthesis, parser
keys under E notation, NNReal scope and an extra solved goal. The final
assembly, explicit identities and norm bound all compile. Read-only explorer
API checks helped resolve the compact-derivative/carrier and cross-map API.
source-final.lean and final.diff preserve the exact completed source/diff.

No root/main edits, full builds, service changes, merges, pushes, acceptance
or task-state mutation were performed. All source changes are in the one
allowed new file. HANDOFF is intentionally not edited because the Task
forbids it; the orchestrator owns any handoff update.

The proof supplies the nonlinear Graph prerequisite toward actual global
Hamilton/Ricci-flow input construction. The universal Hamilton convergence
input and final Poincare theorem remain open. Destination tensor transport,
actual global signed DeTurck L/P/R, nonlinear inversion and physical flow
remain downstream work.

First independent action: review the one-file diff, rerun the exact frozen
Task gates at the recorded base, and scan the emitted declarations.

Local source commit: e7442fe8208b4e51d8fb606d298ff92fe8b34127 (one new owned source file).
Post-commit tracked status is clean.
