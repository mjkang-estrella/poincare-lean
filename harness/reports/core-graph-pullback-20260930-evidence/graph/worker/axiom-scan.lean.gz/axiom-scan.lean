import Lean
import Poincare.Global.ParabolicSpatialGraphPullback
open Lean Elab Command Meta
set_option autoImplicit false
run_cmd do
  let environment := (← getEnv).setExporting false
  setEnv environment
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  for (name, info) in environment.constants.toList do
    let some idx := environment.getModuleIdxFor? name | continue
    unless environment.header.moduleNames[idx]! == `Poincare.Global.ParabolicSpatialGraphPullback do
      continue
    if info.isUnsafe || info.isPartial then
      throwError "unsafe or partial declaration {name}"
    let footprint ← collectAxioms name
    for dependency in footprint do
      unless allowed.contains dependency do
        throwError "forbidden axiom {dependency} in {name}"
    count := count + 1
    logInfo "SCOPED_AXIOMS_OK: {name}: {footprint}"
  unless count > 0 do
    throwError "no module declarations scanned"
  logInfo "SCOPED_DECLARATIONS_SCANNED: {count}"
