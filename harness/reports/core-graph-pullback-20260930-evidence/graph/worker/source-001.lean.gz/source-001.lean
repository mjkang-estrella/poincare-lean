import Poincare.Global.ParabolicSpatialHolderPullback
import Poincare.Global.ParabolicSpatialPullbackChainRule
import Poincare.Global.ParabolicHessianCarrierPullback

/-!
# Nonlinear spatial pullback of genuine derivative graphs

The two chain-rule terms of the Hessian are assembled in the original
four-carrier norm. Time remains unchanged, including its within-interval
derivative certificate.
-/

noncomputable section
set_option autoImplicit false
set_option synthInstance.maxHeartbeats 200000
set_option maxHeartbeats 800000
set_option backward.isDefEq.respectTransparency false
open Set
open scoped ContDiff

namespace Poincare.ParabolicSpatialGraphPullback

open ParabolicHolder ParabolicSolutionGraph ParabolicCutoffCommutator
open ParabolicSpatialHolderPullback
local notation "E" => ClosedSmoothModel 3
local notation "End" => E →L[ℝ] E
local notation "Cov" => E →L[ℝ] ℝ
local notation "Hess" => E →L[ℝ] Cov
local notation "DDF" => E →L[ℝ] End

local instance covectorNormedGroup : NormedAddCommGroup Cov := inferInstance
local instance covectorNormedSpace : NormedSpace ℝ Cov := inferInstance
local instance hessianNormedGroup : NormedAddCommGroup Hess := inferInstance
local instance hessianNormedSpace : NormedSpace ℝ Hess :=
  { norm_smul_le := norm_real_smul_continuousLinearMap_two_le }

/-- Composition of a covector with the second derivative of the spatial map. -/
def secondDerivativeComposition : Cov →L[ℝ] DDF →L[ℝ] Hess :=
  (ContinuousLinearMap.compL ℝ E End Cov).comp
    (ContinuousLinearMap.compL ℝ E E ℝ)

variable {α T : ℝ}

/-- Assemble the actual pulled-back jets and their derivative certificates. -/
def graphOfCarriers
    (F : E → E) (hF : ContDiff ℝ ∞ F) (hα : 0 ≤ α)
    {L : ℝ≥0} (hL : LipschitzWith L F)
    (dF : Y («E» := E) α T End) (ddF : Y («E» := E) α T DDF)
    (hdF : ∀ p ∈ cylinder T, dF p = fderiv ℝ F p.2)
    (hddF : ∀ p ∈ cylinder T, ddF p = fderiv ℝ (fderiv ℝ F) p.2)
    (P : Y («E» := E) α T Hess →L[ℝ] Y («E» := E) α T Hess)
    (hP : ∀ B p (v w : E), P B p v w = B p (dF p v) (dF p w))
    (G : Graph (E := E) α T) : Graph (E := E) α T where
  u := pullback hα F hL G.u
  ut := pullback hα F hL G.ut
  du := bilinearY (ContinuousLinearMap.compL ℝ E E ℝ)
    (pullback hα F hL G.du) dF
  ddu := P (pullback hα F hL G.ddu) +
    bilinearY secondDerivativeComposition (pullback hα F hL G.du) ddF
  zero_trace := by
    intro x
    exact G.zero_trace (F x)
  hasFDeriv := by
    intro t ht x
    have hx : (t, x) ∈ cylinder T := ⟨ht, mem_univ x⟩
    convert (G.hasFDeriv t ht (F x)).comp x
      (hF.differentiable (by simp) x).hasFDerivAt using 1
    · rfl
    · simp only [bilinearY, ofFunction_apply, hdF (t, x) hx]
      rfl
  hasFDeriv_du := by
    intro t ht x
    have hmem (z : E) : (t, z) ∈ cylinder T := ⟨ht, mem_univ z⟩
    convert ParabolicSpatialPullbackChainRule.hasFDerivAt_graph_covector_pullback
      F hF α T G t ht x using 1
    · funext z
      simp only [bilinearY, ofFunction_apply, hdF (t, z) (hmem z)]
      rfl
    · ext v w
      simp only [add_apply, ContinuousLinearMap.add_apply, bilinearY, ofFunction_apply,
        hP, hdF (t, x) (hmem x), hddF (t, x) (hmem x)]
      rfl
  hasDeriv_time := by
    intro t ht x
    exact G.hasDeriv_time t ht (F x)

end Poincare.ParabolicSpatialGraphPullback
