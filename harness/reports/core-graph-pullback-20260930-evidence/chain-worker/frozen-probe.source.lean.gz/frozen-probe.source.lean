import Lean
import Poincare.Global.ParabolicSpatialPullbackChainRule
open Lean Elab Command Meta
set_option autoImplicit false
run_cmd do
  let name := "Poincare.ParabolicSpatialPullbackChainRule.hasFDerivAt_graph_covector_pullback".toName
  let _ ← getConstInfo name
  let environment := (← getEnv).setExporting false
  let mut pending : List Name := [name]
  let mut seen : NameSet := {}
  while !pending.isEmpty do
    let current := pending.head!
    pending := pending.tail!
    if !seen.contains current then
      seen := seen.insert current
      let some info := environment.find? current |
        throwError "missing dependency {current} in {name}"
      if info.isUnsafe || info.isPartial then
        throwError "unsafe or partial declaration {current} in {name}"
      pending := info.getUsedConstantsAsSet.toList ++ pending
      match info with
      | .recInfo value =>
        for rule in value.rules do
          pending := rule.rhs.getUsedConstants.toList ++ pending
      | .inductInfo value => pending := value.ctors ++ pending
      | _ => pure ()
  let allowed : List Name := ["propext".toName, "Classical.choice".toName, "Quot.sound".toName]
  let footprint ← collectAxioms name
  for dependency in footprint do
    unless allowed.contains dependency do
      throwError "forbidden axiom {dependency} in {name}"
  logInfo "AXIOM_CONTRACT_OK: Poincare.ParabolicSpatialPullbackChainRule.hasFDerivAt_graph_covector_pullback"
run_cmd liftTermElabM do
  let info ← getConstInfo "Poincare.ParabolicSpatialPullbackChainRule.hasFDerivAt_graph_covector_pullback".toName
  let levels : List Level := []
  unless info.levelParams.length == levels.length do
    throwError "frozen universe arity mismatch for {info.name}"
  let parsedType ← match Parser.runParserCategory (← getEnv) `term "∀ (F : (Poincare.ClosedSmoothModel 3) → (Poincare.ClosedSmoothModel 3)), ContDiff ℝ ((⊤ : ENat) : WithTop ENat) F →\n∀ (α T : ℝ) (G : Poincare.ParabolicSolutionGraph.Graph (E := (Poincare.ClosedSmoothModel 3)) α T) (t : ℝ), t ∈ Set.Icc 0 T → ∀ x : (Poincare.ClosedSmoothModel 3),\nHasFDerivAt (fun z ↦ (G.du (t, F z)).comp (fderiv ℝ F z))\n (((ContinuousLinearMap.compL ℝ (Poincare.ClosedSmoothModel 3) (Poincare.ClosedSmoothModel 3) ℝ).flip (fderiv ℝ F x)).comp ((G.ddu (t, F x)).comp (fderiv ℝ F x)) +\n  ((ContinuousLinearMap.compL ℝ (Poincare.ClosedSmoothModel 3) (Poincare.ClosedSmoothModel 3) ℝ) (G.du (t, F x))).comp (fderiv ℝ (fderiv ℝ F) x)) x" with
    | .ok parsedType => pure parsedType
    | .error error => throwError error
  let expected ← Term.elabType parsedType
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then
    throwError "unresolved metavariables in frozen type for {info.name}"
  let actual := info.type.instantiateLevelParams info.levelParams levels
  unless ← isDefEq actual expected do
    throwError "frozen type mismatch for {info.name}: actual {actual}, expected {expected}"
  logInfo "FROZEN_CONTRACT_OK: Poincare.ParabolicSpatialPullbackChainRule.hasFDerivAt_graph_covector_pullback"
