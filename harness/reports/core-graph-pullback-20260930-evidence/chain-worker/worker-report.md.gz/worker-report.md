# Actual graph covector chain rule worker report

Task: core-input-20260930-graph-chain-rule revision 1.
Authoritative Task was read from the absolute root integration path.
Base: b6798a4cbeec42132da1a4fff8ce83f167add31e.
Worktree: /Users/mjkang/.codex/worktrees/core-graph-chain-rule/poincare.
Branch: codex/core-graph-chain-rule-a01.
Owned source: Poincare/Global/ParabolicSpatialPullbackChainRule.lean only.

The exact frozen declaration `Poincare.ParabolicSpatialPullbackChainRule.hasFDerivAt_graph_covector_pullback` is proved. Worker result is ready for independent review. This report does not accept the Task.

The proof composes the genuine Graph.hasFDeriv_du certificate with the ordinary derivative of the actual smooth F. Smoothness supplies differentiability of DF. HasFDerivAt.clm_comp then differentiates the covector/Jacobian composition. Its two summands are reordered by add_comm, preserving all CLM compositions and slot order.

Applied first to direction v and then to covector argument w, the exact resulting derivative is:

```text
G.ddu(t,Fx)(DFx v)(DFx w) + G.du(t,Fx)(D2Fx v w)
```

The full D2F term is retained with a plus sign. The first argument of G.ddu and D2F is the derivative direction; no slot transpose, omitted term, or linearity assumption on F is used.

No alpha restriction, T positivity/bound, compact-support assumption, supplied Lipschitz bound, flow/operator existence, curvature, recognition or limit premise was added. The original admissible-time premise is t in Icc 0 T, including the T=0 case.

Verification:
- Fresh focused Lean, exact env LEAN_NUM_THREADS=1 command: exit 0, first implementation attempt, no new-source warning.
- Forbidden-token gate: exit 0.
- git diff --check: exit 0; staged actual source diff --check: exit 0.
- Frozen contract audit: exit 0. Exact no-universe type and permitted axiom closure passed. Only the named source module was built.
- Internal-inclusive scan of all emitted target-module declarations: exit 0. One declaration, with footprint exactly propext, Classical.choice, Quot.sound.

Every source/compiler log/exit, rendered frozen probe, context hashes, final.patch and result are preserved under this ignored attempt directory. The read-only API explorer ran no compiler probes and edited no files. There were no failed compiler attempts for this Job.

The consumer ParabolicSpatialGraphPullback.exists_spatial_Graph_pullback still needs actual bounded Graph CLMs with explicit u,ut,du,ddu evaluations, all derivative/zero-trace certificates, and one T-uniform full Graph norm bound. The existing nonlinear Y pullback transports the value/ut carriers. Constructed DF and D2F carriers plus this derivative theorem supply the spatial certificate needed by that consumer; this theorem does not itself build or norm-bound the Graph operator.

Later destination-only tensor transport still needs support, symmetry, genuine transition compatibility and derivative norm estimates. The actual global L/P/R maps must match the full DeTurck operator including lower terms and satisfy L.comp P = id - R with norm R < 1, accounting for the local id+R sign. Nonlinear inversion, matched initial jets, ordinary joint C3 at time zero, general Ricci flow, continuation/surgery and favorable metric/limit construction remain open. Smoothability remains separately open; this derivative identity does not discharge either universal core assumption.

No root/main or other source edit, full root build, service operation, merge, push, acceptance or final-conjecture claim was performed.

First orchestrator action: independently rerun this frozen Task gate from base b6798a4cbeec42132da1a4fff8ce83f167add31e, then consume the verified CLM formula in the actual bounded spatial Graph pullback constructor.
