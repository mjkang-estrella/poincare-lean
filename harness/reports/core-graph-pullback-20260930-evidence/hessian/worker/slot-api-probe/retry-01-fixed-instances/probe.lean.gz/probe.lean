import Poincare.Global.ParabolicCutoffCommutator
import Poincare.Global.RiemannianContext
noncomputable section
set_option synthInstance.maxHeartbeats 200000
set_option maxHeartbeats 800000
namespace SlotProbe
abbrev E := Poincare.ClosedSmoothModel 3
abbrev Cov := E →L[ℝ] ℝ
abbrev Hess := E →L[ℝ] Cov
abbrev End := E →L[ℝ] E

local instance instEndNormedGroup : NormedAddCommGroup End := inferInstance
local instance instEndNormedSpace : NormedSpace ℝ End := inferInstance
local instance instCovNormedGroup : NormedAddCommGroup Cov := inferInstance
local instance instCovNormedSpace : NormedSpace ℝ Cov := inferInstance
local instance instHessNormedGroup : NormedAddCommGroup Hess := inferInstance
local instance instHessNormedSpace : NormedSpace ℝ Hess := inferInstance
local instance instHessMapNormedGroup : NormedAddCommGroup (Hess →L[ℝ] Hess) := inferInstance
local instance instHessMapNormedSpace : NormedSpace ℝ (Hess →L[ℝ] Hess) := inferInstance
local instance instEndHessMapNormedGroup : NormedAddCommGroup (End →L[ℝ] Hess →L[ℝ] Hess) := inferInstance
local instance instEndHessMapNormedSpace : NormedSpace ℝ (End →L[ℝ] Hess →L[ℝ] Hess) := inferInstance
local instance instCovMapNormedGroup : NormedAddCommGroup (Cov →L[ℝ] Cov) := inferInstance
local instance instCovMapNormedSpace : NormedSpace ℝ (Cov →L[ℝ] Cov) := inferInstance
local instance instEndCovMapNormedGroup : NormedAddCommGroup (End →L[ℝ] Cov →L[ℝ] Cov) := inferInstance
local instance instEndCovMapNormedSpace : NormedSpace ℝ (End →L[ℝ] Cov →L[ℝ] Cov) := inferInstance
#synth NormedAddCommGroup Hess
#synth NormedSpace ℝ Hess
#check @ContinuousLinearMap.compL
#check @ContinuousLinearMap.compL_apply
#check @ContinuousLinearMap.flip_apply
#check @ContinuousLinearMap.comp_apply
#check @ContinuousLinearMap.opNorm_flip
#check @ContinuousLinearMap.norm_compL_le
#check @Poincare.ParabolicCutoffCommutator.bilinearY

def leftSlot : End →L[ℝ] Hess →L[ℝ] Hess :=
  (ContinuousLinearMap.compL ℝ E E Cov).flip

def covectorSlot : End →L[ℝ] Cov →L[ℝ] Cov :=
  (ContinuousLinearMap.compL ℝ E E ℝ).flip

def rightSlot : End →L[ℝ] Hess →L[ℝ] Hess :=
  (ContinuousLinearMap.compL ℝ E Cov Cov).comp covectorSlot

example (D : End) (B : Hess) (v w : E) : leftSlot D B v w = B (D v) w := rfl
example (D : End) (B : Hess) (v w : E) : rightSlot D B v w = B v (D w) := rfl
example : ‖leftSlot‖ ≤ 1 := by
  simpa only [leftSlot, ContinuousLinearMap.opNorm_flip] using
    ContinuousLinearMap.norm_compL_le ℝ E E Cov
example : ‖covectorSlot‖ ≤ 1 := by
  simpa only [covectorSlot, ContinuousLinearMap.opNorm_flip] using
    ContinuousLinearMap.norm_compL_le ℝ E E ℝ
example (α T : ℝ) : NormedSpace ℝ (Poincare.ParabolicHolder.Y (E := E) α T Hess) :=
  Submodule.normedSpace (Poincare.ParabolicHolder.holderSubmodule (E := E) (F := Hess) α T)
example (α T : ℝ) (dF : Poincare.ParabolicHolder.Y (E := E) α T End)
    (B : Poincare.ParabolicHolder.Y (E := E) α T Hess) (p : ℝ × E) (v w : E) :
    Poincare.ParabolicCutoffCommutator.bilinearY leftSlot dF B p v w = B p (dF p v) w := rfl
example (α T : ℝ) (dF : Poincare.ParabolicHolder.Y (E := E) α T End)
    (B : Poincare.ParabolicHolder.Y (E := E) α T Hess) (p : ℝ × E) (v w : E) :
    Poincare.ParabolicCutoffCommutator.bilinearY rightSlot dF B p v w = B p v (dF p w) := rfl
end SlotProbe
