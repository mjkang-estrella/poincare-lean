import Poincare.Global.ParabolicSpatialPullbackChainRule
import Poincare.Global.ParabolicHessianCarrierPullback
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for mod in #[`Poincare.Global.ParabolicSpatialPullbackChainRule, `Poincare.Global.ParabolicHessianCarrierPullback] do
    let some idx := env.getModuleIdx? mod | throwError "module missing: {mod}"
    let mut count := 0
    for (n, _) in env.constants.map₁.toList do
      if env.getModuleIdxFor? n == some idx then
        let axs ← liftCoreM (collectAxioms n)
        unless axs.all (fun a => a == ``propext || a == ``Classical.choice || a == ``Quot.sound) do
          throwError "Unexpected dependencies: {n}: {axs}"
        elabCommand (← `(command| #print axioms $(mkIdent n)))
        count := count + 1
    unless count > 0 do throwError "No module declarations found: {mod}"
    logInfo m!"MODULE_DEPENDENCIES_PASS module={mod} declarations={count}"
