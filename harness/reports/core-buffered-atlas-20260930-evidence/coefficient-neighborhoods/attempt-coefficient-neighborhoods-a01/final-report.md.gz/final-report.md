# Coefficient neighborhoods: verified local helper result

Date: 2026-09-30T02:12:15.587338+00:00
Base: `b95075ed949d5e5cd51ed66908bc942a94a4ae37`
Proof head: `85d08a9620e0b6b337dab2791c7e5ec59b1f732a`
Branch: `codex/core-coefficient-neighborhoods-a01`
Role: local Codex helper, not a registered Pi/Leanstral Job.

The exact frozen theorem `Poincare.MetricCoefficientNeighborhoods.exists_coefficient_neighborhoods` is proved. The only changed source is the new 114-line `Poincare/Global/MetricCoefficientNeighborhoods.lean`. The supplied untracked Task was not committed.

For each actual metric g0, anchor p, and positive pointwise tolerance epsilon(p), the construction chooses a common inverse-entry oscillation radius, then takes the intersection of the genuine chart target, the open set of points where the fixed-anchor cutoff has a germ equal to one, and the oscillation ball. Every function whose topological support lies in that intersection satisfies all nine bounds for the inverse of the whole Gram matrix. No continuity or global lower bound on epsilon, regularity of the supported function, supplied atlas, curvature, evolution, or operator witness is added.

The first compiler attempt exposed an unnecessary `ConnectedSpace M` premise on the existing `inverse_metric_oscillation_radius`. The leaf preserves the reviewed target by proving `gramField_det_ne_zero` from the actual metric matrix in the transported inverse-chart tangent basis, then proving `inverse_metric_entry_continuousAt` directly from local chart-metric pairing smoothness and `continuousAt_matrix_inv`. The already proved generic `exists_oscillation_radius` supplies the radius. The second source attempt failed only on the scalar-versus-function form of `Ring.inverse_eq_inv`; the third passes using `Ring.inverse_eq_inv'`. Both failed outputs and the assumption probe are retained.

Verification passed:

- Focused source elaboration, compiler attempt 03, exit 0.
- Forbidden-token Task gate, exit 0.
- Unstaged and staged whitespace checks, exit 0.
- Exact frozen type, rigid universe and allowed-axiom contract gate, exit 0. Its targeted Lake build completed 3413 jobs.
- Internal-inclusive module-index scan, exit 0. All three emitted declarations have exactly `propext`, `Classical.choice`, and `Quot.sound`; no other or partial axiom footprint occurs.

A nonfatal linter warning says the compactness instance is unused in `gramField_det_ne_zero`. The reviewed final theorem retains its original compactness assumption. No source definition, root import, task acceptance, merge, full build, or service was changed. This constructs a geometric input for `MetricAdaptedBufferedAtlas`; general Ricci-flow existence, universal Hamilton convergence, smoothability, and the final Poincare theorem remain open.

Exact first action for the orchestrator: independently rerun `python3 scripts/frozen_contract_audit.py --manifest harness/v2/contracts/core-buffered-atlas-20260930/coefficient-neighborhoods.contract.json` against this proof head and review the base-relative diff before acceptance.
