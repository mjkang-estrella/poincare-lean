import Poincare.Global.BufferedFrozenParabolicSolver

/-!
# Metric-selected coordinate neighborhoods

The actual inverse metric entries determine an oscillation ball at each
manifold anchor. Intersecting that ball with the genuine chart target and
the open neighborhood where the fixed anchor cutoff is locally one gives
coordinate neighborhoods suitable for a later buffered atlas construction.
-/

noncomputable section
set_option autoImplicit false
open Set Filter
open scoped Manifold ContDiff Topology

universe u

namespace Poincare.MetricCoefficientNeighborhoods

variable {M : Type u} [TopologicalSpace M] [T2Space M] [CompactSpace M]
  [ChartedSpace (ClosedSmoothModel 3) M]
  [IsManifold (closedSmoothModelWithCorners 3) ∞ M]

/-- Every positive pointwise tolerance selects a genuine coordinate neighborhood
on which the anchor cutoff is locally one and all actual inverse metric
entries satisfy the requested bound on any contained function support. -/
theorem exists_coefficient_neighborhoods
    (g0 : ClosedSmoothRiemannianMetric 3 M) (ε : M → ℝ)
    (hε : ∀ p, 0 < ε p) :
    ∃ V : M → Set (ClosedSmoothModel 3),
      (∀ p, IsOpen (V p) ∧
        extChartAt (closedSmoothModelWithCorners 3) p p ∈ V p ∧
        V p ⊆ (extChartAt (closedSmoothModelWithCorners 3) p).target ∧
        ∀ z ∈ V p, ∀ᶠ y in nhds z, GeodesicTransport.cutoff (n := 3) p y = 1) ∧
      ∀ p (ξ : ClosedSmoothModel 3 → ℝ), tsupport ξ ⊆ V p →
        ∀ z ∈ tsupport ξ, ∀ a b : Fin 3,
          |(inverseChartPullbackGramMatrixField g0 p z)⁻¹ a b -
            (inverseChartPullbackGramMatrixField g0 p
              (extChartAt (closedSmoothModelWithCorners 3) p p))⁻¹ a b| ≤ ε p := by
  classical
  have hradius (p : M) :=
    BufferedFrozenParabolicSolver.inverse_metric_oscillation_radius g0 p
      (extChartAt (closedSmoothModelWithCorners 3) p p)
      (mem_extChartAt_target p) (hε p)
  choose ρ hρpos hρbound using hradius
  let V (p : M) : Set (ClosedSmoothModel 3) :=
    (extChartAt (closedSmoothModelWithCorners 3) p).target ∩
      {z | ∀ᶠ y in nhds z, GeodesicTransport.cutoff (n := 3) p y = 1} ∩
      Metric.ball (extChartAt (closedSmoothModelWithCorners 3) p p) (ρ p)
  refine ⟨V, ?_, ?_⟩
  · intro p
    refine ⟨((isOpen_extChartAt_target p).inter
      isOpen_setOf_eventually_nhds).inter Metric.isOpen_ball, ?_, ?_, ?_⟩
    · exact ⟨⟨mem_extChartAt_target p,
        GeodesicTransport.cutoff_eventuallyEq_one (n := 3) p⟩,
        Metric.mem_ball_self (hρpos p)⟩
    · intro z hz
      exact hz.1.1
    · intro z hz
      exact hz.1.2
  · intro p ξ hξ z hz a b
    exact hρbound p ξ (fun z hz ↦ (hξ hz).2) z hz a b

end Poincare.MetricCoefficientNeighborhoods
