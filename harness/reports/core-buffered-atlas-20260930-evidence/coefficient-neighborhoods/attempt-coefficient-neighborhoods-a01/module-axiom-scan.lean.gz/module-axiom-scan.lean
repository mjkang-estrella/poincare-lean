import Poincare.Global.MetricCoefficientNeighborhoods
open Lean Elab Command in
run_cmd do
  let env := (← getEnv).setExporting false
  let some idx := env.getModuleIdx? `Poincare.Global.MetricCoefficientNeighborhoods
    | throwError "module missing"
  let mut count := 0
  let mut standard := 0
  let mut empty := 0
  for (n, _) in env.constants.map₁.toList do
    if env.getModuleIdxFor? n == some idx then
      let axs ← liftCoreM (collectAxioms n)
      unless axs.isEmpty || (axs.size == 3 && axs.contains ``propext &&
          axs.contains ``Classical.choice && axs.contains ``Quot.sound) do
        throwError "unexpected dependencies for {n}: {axs}"
      if axs.isEmpty then empty := empty + 1 else standard := standard + 1
      logInfo m!"MODULE_AXIOMS {n}: {axs}"
      count := count + 1
  unless count > 0 do throwError "empty module scan"
  logInfo m!"INTERNAL_INCLUSIVE_STD3_OR_EMPTY_PASS declarations={count} std3={standard} empty={empty}"
#print axioms Poincare.MetricCoefficientNeighborhoods.exists_coefficient_neighborhoods
