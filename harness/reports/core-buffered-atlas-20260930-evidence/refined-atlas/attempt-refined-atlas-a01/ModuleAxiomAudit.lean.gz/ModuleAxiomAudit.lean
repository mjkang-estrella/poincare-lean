import Poincare.Global.RefinedFiniteAtlasExistence
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let some idx := env.getModuleIdx? `Poincare.Global.RefinedFiniteAtlasExistence
    | throwError "module missing"
  let mut count := 0
  for (n, _) in env.constants.map₁.toList do
    if env.getModuleIdxFor? n == some idx then
      let axs ← liftCoreM (collectAxioms n)
      unless axs.isEmpty ||
          (axs.size == 3 && axs.contains ``propext &&
            axs.contains ``Classical.choice && axs.contains ``Quot.sound) do
        throwError "Unexpected dependencies: {n}: {axs}"
      elabCommand (← `(command| #print axioms $(mkIdent n)))
      count := count + 1
  unless count > 0 do
    throwError "No module declarations found"
  logInfo m!"MODULE_DEPENDENCIES_PASS declarations={count}"
