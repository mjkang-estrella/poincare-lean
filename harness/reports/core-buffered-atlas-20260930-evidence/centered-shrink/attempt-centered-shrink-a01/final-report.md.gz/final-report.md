# Centered chart shrinking helper proof

Task: `core-input-20260930-centered-shrink`. Local Codex helper; runtime_registered=false.
Base: `b95075ed949d5e5cd51ed66908bc942a94a4ae37`.
Proof commit: `5bb3b5a0c4a2a8f3da31eb9d9640546d2246345e`.
Owned source: `Poincare/Global/CenteredCoordinateNeighborhoodShrinking.lean`. Only that file is changed in the commit.

The exact frozen theorem `Poincare.CenteredCoordinateNeighborhoodShrinking.exists_centered_chart_shrinking` is proved. For any open coordinate neighborhood of the anchor, source intersection with its chart preimage is open and contains the anchor. Compact Hausdorff normality supplies an open U around the anchor with closure inside that intersection. The closure is compact in M; chart continuity restricted to the genuine source then proves compactness of its coordinate image. The intersection's preimage condition supplies containment in the prescribed V.

No smooth-manifold, metric, curvature, atlas, flow, or operator premise was added. This lemma is an input to RefinedFiniteAtlasExistence; it does not construct Ricci flow or close the universal Hamilton or Poincare target.

All scoped checks passed:
- Fresh source compile, first attempt: exit 0, silent.
- Required forbidden-token scan: exit 0, file returned because no forbidden token occurs.
- Git diff check: exit 0; also repeated against the staged source before commit.
- Frozen exact type and allowed-axiom contract: exit 0. Its targeted module build completed 2702 jobs.
- Internal-inclusive module-index axiom scan: exit 0, one emitted declaration with exactly propext, Classical.choice, Quot.sound.
- Frozen context hashes preserved; source snapshot equals committed source; base-to-head scope contains only the owned file.

No failed compiler attempt occurred. All source snapshots, compiler logs, gate outputs and exact final diff are preserved here. No acceptance, merge, root import, full build, service action or registered Pi/Leanstral Job was performed.

Next first action for the orchestrator: independently compile `Poincare/Global/CenteredCoordinateNeighborhoodShrinking.lean` and rerun its frozen contract gate from the recorded base before integration.

Final Git status:
```
## codex/core-centered-shrink-a01
?? harness/v2/tasks/core-input-20260930-centered-shrink.json
```
