import json,hashlib
from pathlib import Path
from harness.v2.runtime.validation import statement_contract_snapshot
r=Path.cwd();folder=r/'harness/v2/contracts/core-deturck-localization-20260930';folder.mkdir(exist_ok=True);d=r/'harness/v2/state/core-deturck-localization-20260930'
E='Poincare.DeTurckPrincipalSecondJet.E';G='Poincare.DeTurckPrincipalSecondJet.Bilin';J='Poincare.DeTurckPrincipalSecondJet.Jet1';H='Poincare.DeTurckJetLinearization.Jet2';V='Poincare.DeTurckJetLinearization.Variables';L='Poincare.DeTurckLocalization';Q='Poincare.DeTurckJetLinearization';F='Poincare.DeTurckCoupledForcing';S='Poincare.DeTurckTensorSecondJet';R='Poincare.DeTurckJetRealization';e='Poincare.DeTurckPrincipalSecondJet.basis3';A='Poincare.DeTurckPrincipalSecondJet.inverseEntries'
pre=''
for space,source,target in [(J,E,G),(H,E,J)]:
 pre+=f'''letI : NormedAddCommGroup {space} := ContinuousLinearMap.toNormedAddCommGroup
(𝕜 := ℝ) (𝕜₂ := ℝ) (E := {source}) (F := {target}) (σ₁₂ := RingHom.id ℝ);
letI : NormedSpace ℝ {space} := ContinuousLinearMap.toNormedSpace
(𝕜 := ℝ) (𝕜₂ := ℝ) (E := {source}) (F := {target}) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);
'''
local=pre+f'''∀ (B : {E} →L[ℝ] {E} →L[ℝ] {E})
(DB : {E} →L[ℝ] {E} →L[ℝ] {E} →L[ℝ] {E})
(G0 : {G}) (J0 : {J}) (H0 : {H})
(c : ℝ) (dc : {E} →L[ℝ] ℝ) (ddc : {G}) (p : {V}),
{Q}.differential B DB G0 J0 H0 ({L}.cutoffVariables c dc ddc p) =
c • {Q}.differential B DB G0 J0 H0 p +
(∑ i : Fin 3, ∑ j : Fin 3, {A} G0 i j •
 (dc ({e} i) • p.1.2 ({e} j) + dc ({e} j) • p.1.2 ({e} i) + ddc ({e} i) ({e} j) • p.1.1)) +
Poincare.DeTurckSpatialCoefficients.firstOrder B DB G0 J0 (dc.smulRight p.1.1)'''
product=pre+f'''∀ (χ : {E} → ℝ) (f : {E} → {G}) (J : {E} → {J})
(H : {H}) (z : {E}), ContDiff ℝ (2 : WithTop ENat) χ →
(∀ y : {E}, HasFDerivAt f (J y) y) → HasFDerivAt J H z →
HasFDerivAt (fun y => χ y • f y)
 ({L}.cutoffFirst (χ z) (fderiv ℝ χ z) (f z) (J z)) z ∧
HasFDerivAt (fun y => fderiv ℝ (fun x => χ x • f x) y)
 ({L}.cutoffSecond (χ z) (fderiv ℝ χ z) (fderiv ℝ (fderiv ℝ χ) z) (f z) (J z) H) z'''
hessian=pre+f'''∀ (α T : ℝ) (W : {F}.Inputs α T) (t : ℝ) (z : {E}), t ∈ Set.Icc 0 T →
HasFDerivAt (fun y => {F}.tensorJet W (t,y)) ({S}.tensorHessian W (t,z)) z'''
c2=pre+f'''∀ (α T : ℝ) (W : {F}.Inputs α T) (t : ℝ), 0 < α → t ∈ Set.Icc 0 T →
ContDiff ℝ (2 : WithTop ENat) (fun y : {E} => {F}.tensorValue W (t,y))'''
realization=pre+f'''∀ (h : {E} → {G}) (z : {E}) (U : Set {E}),
IsOpen U → z ∈ U → ContDiffAt ℝ (2 : WithTop ENat) h z →
(Filter.Eventually (fun y => ∀ v w : {E}, h y v w = h y w v) (nhds z)) →
∃ η : {E} → ℝ,
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) η ∧ HasCompactSupport η ∧ tsupport η ⊆ U ∧
(Filter.Eventually (fun y => η y = 1) (nhds z)) ∧
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) ({R}.realized η h z) ∧
HasCompactSupport ({R}.realized η h z) ∧ tsupport ({R}.realized η h z) ⊆ U ∧
(∀ y v w : {E}, {R}.realized η h z y v w = {R}.realized η h z y w v) ∧
{R}.realized η h z z = h z ∧
fderiv ℝ ({R}.realized η h z) z = fderiv ℝ h z ∧
fderiv ℝ (fderiv ℝ ({R}.realized η h z)) z = fderiv ℝ (fderiv ℝ h) z'''
mods={'localization':('DeTurckLocalization',[(L+'.differential_cutoff',local)]),'product':('DeTurckLocalizationProduct',[(L+'.cutoff_hasFDerivAt_two',product)]),'hessian':('DeTurckTensorSecondJet',[(S+'.tensorHessian_hasFDerivAt',hessian),(S+'.tensorValue_contDiff_two',c2)]),'realization':('DeTurckCompactJetRealization',[(R+'.exists_compact_symmetric_realization',realization)])}
pins=['Poincare/Global/RiemannianContext.lean','Poincare/Global/DeTurckPrincipalSecondJet.lean','Poincare/Global/DeTurckJetLinearizationDefinitions.lean','Poincare/Global/DeTurckSpatialCoefficientDefinitions.lean','Poincare/Global/DeTurckLocalizationDefinitions.lean','Poincare/Global/DeTurckTensorSecondJetDefinitions.lean','Poincare/Global/DeTurckJetRealizationDefinitions.lean','Poincare/Global/DeTurckCoupledForcingDefinitions.lean','Poincare/Global/ParabolicHolderSpace.lean','Poincare/Global/ParabolicSolutionGraph.lean']
for slug,(mod,targets) in mods.items():
 c={'imports':['Poincare.Global.'+mod],'declarations':[{'name':name,'lean_type':t,'universes':[]} for name,t in targets],'definition_files':[{'path':p,'sha256':hashlib.sha256((r/p).read_bytes()).hexdigest()} for p in pins],'author':'root-orchestrator'}
 c['review']={'reviewer':'deturck-localization-readback','method':'blind-readback','snapshot_sha256':statement_contract_snapshot(c),'verdict':'pending','report_path':str((folder/f'{slug}.readback.json').relative_to(r)),'report_sha256':'0'*64}
 (folder/f'{slug}.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
 s='import Poincare.Global.DeTurckJetRealizationDefinitions\nimport Poincare.Global.DeTurckTensorSecondJetDefinitions\nimport Lean\nset_option maxHeartbeats 2000000\nset_option synthInstance.maxHeartbeats 200000\nset_option maxSynthPendingDepth 100\nopen Lean Elab Command Term\n'
 for name,t in targets:
  s+=f'''run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(t,ensure_ascii=False)} with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: {name}"
'''
 (d/f'{slug}.preflight.lean').write_text(s)
(folder/'context.md').write_text('''# Full cutoff localization and actual C2 jet realization

All tasks help UniversalHamiltonConvergenceStatement by real physical flow input construction. Localization/product are consumed by the true global L=dt-DQ(g0) on stored chi_i*h_i, its correct signed residual and contraction. Hessian/C2 and compact symmetric realization are consumed by actual smooth metric variations and differentiated nonlinear covariance on symmetric C2 Graph germs. Both universal cores/final theorem remain open/unchanged; no flow/limit/curvature/coefficient package may replace construction.

Localization uses actual full differential, including Da(G0)[h]:H0 and lowerDifferential. The scalar cutoff product jets include BOTH ordered mixed terms, Hessian cutoff term, and firstOrder(dc.smulRight h); only zeroOrder cancels by true linearity. No symmetric principal assumption or offdiagonal convention. In L=dt-DQ the correction is negative. Algebra at arbitrary base jets is instantiated at actual metric jets on the invertibility zone supplied by the accepted actual coefficient producer. Product theorem must identify actual second fderiv using first-jet equality NEARBY, not at only one point. Stored source entries already include their partition; do not multiply source chi again.

Hessian uses genuine Graph.hasFDeriv_du and fixed smulRightL, finite sums; targetHasFD has no alpha restrictions. Global fixed-time C2 uses 0<alpha and spatial continuity of the same Y carriers; no ordinary joint/time C3 is inferred.

Realization constructs eta from singleton z in open U using actual buffered cutoff, then the explicit quadratic Taylor polynomial of the supplied C2 germ. Use direction-slot Hessian symmetry and covariant-slot symmetry differentiated from eventual tensor symmetry. Match value/D/D2 exactly; no smooth germ equality or full-Holder norm density is claimed. All original nested operator norms and all9 tensor slots remain. This supplies a real compact smooth coefficient field; subsequent global bundle lift and small positive actual metric family remain unproved producers.

Name EVERY local instance uniquely per module in shared namespaces. Prior anonymous compiler-generated helper collision and name-only repair are preserved. Canonical groups/spaces and IsBoundedSMul proved with opNorm_smul_le preserve existing norms/actions; no substitute normalization allowed.

Preserve every source/compiler failure and finaldiff append-only; LEAN_NUM_THREADS=1. Workers are not alone and own only task allowedfile; never revert others/edit main/root/defs/contracts/merge/selfaccept/fullbuild/manage services. Local Codex helper is not a registered Pi/Leanstral Job. Root independently reruns exact scoped gates/actual diff and integrates once per batch.
''')
