import Poincare.Global.DeTurckJetRealizationDefinitions
import Poincare.Global.DeTurckTensorSecondJetDefinitions
import Lean
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
open Lean Elab Command Term
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "letI : NormedAddCommGroup Poincare.DeTurckPrincipalSecondJet.Jet1 := ContinuousLinearMap.toNormedAddCommGroup\n  (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ);\nletI : NormedSpace ℝ Poincare.DeTurckPrincipalSecondJet.Jet1 := ContinuousLinearMap.toNormedSpace\n  (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);\nletI : NormedAddCommGroup Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedAddCommGroup\n  (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ);\nletI : NormedSpace ℝ Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedSpace\n  (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);\n∀ (χ : Poincare.DeTurckPrincipalSecondJet.E → ℝ) (f : Poincare.DeTurckPrincipalSecondJet.E → Poincare.DeTurckPrincipalSecondJet.Bilin) (J : Poincare.DeTurckPrincipalSecondJet.E → Poincare.DeTurckPrincipalSecondJet.Jet1)\n(H : Poincare.DeTurckJetLinearization.Jet2) (z : Poincare.DeTurckPrincipalSecondJet.E), ContDiff ℝ (2 : WithTop ENat) χ →\n(∀ y : Poincare.DeTurckPrincipalSecondJet.E, HasFDerivAt f (J y) y) → HasFDerivAt J H z →\nHasFDerivAt (fun y => χ y • f y)\n (Poincare.DeTurckLocalization.cutoffFirst (χ z) (fderiv ℝ χ z) (f z) (J z)) z ∧\nHasFDerivAt (fun y => fderiv ℝ (fun x => χ x • f x) y)\n (Poincare.DeTurckLocalization.cutoffSecond (χ z) (fderiv ℝ χ z) (fderiv ℝ (fderiv ℝ χ) z) (f z) (J z) H) z" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: Poincare.DeTurckLocalization.cutoff_hasFDerivAt_two"
