import Poincare.Global.DeTurckLocalization
import Poincare.Global.DeTurckLocalizationProduct
import Poincare.Global.DeTurckTensorSecondJet
import Poincare.Global.DeTurckCompactJetRealization
noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
open Set Filter
open scoped ContDiff Topology BigOperators
namespace Poincare.LocalizationApplication
open DeTurckPrincipalSecondJet DeTurckJetLinearization DeTurckLocalization
open DeTurckCoupledForcing DeTurckTensorSecondJet DeTurckJetRealization
local instance localizationApplicationBilinBoundedSMul : IsBoundedSMul ℝ Bilin :=
  .of_norm_smul_le (fun c A => ContinuousLinearMap.opNorm_smul_le c A)
local instance localizationApplicationJet1Group : NormedAddCommGroup Jet1 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance localizationApplicationJet1Space : NormedSpace ℝ Jet1 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance localizationApplicationJet2Group : NormedAddCommGroup Jet2 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1) (σ₁₂ := RingHom.id ℝ)
local instance localizationApplicationJet2Space : NormedSpace ℝ Jet2 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)


example (α T : ℝ) (W : Inputs α T) (t : ℝ) (ht : t ∈ Icc 0 T)
    (χ : E → ℝ) (hχ : ContDiff ℝ (2 : WithTop ENat) χ) (z : E)
    (B : E →L[ℝ] E →L[ℝ] E) (DB : E →L[ℝ] E →L[ℝ] E →L[ℝ] E)
    (G0 : Bilin) (J0 : Jet1) (H0 : Jet2) :
let f := fun y : E => tensorValue W (t,y)
let p : Variables := ((f z, tensorJet W (t,z)), tensorHessian W (t,z))
differential B DB G0 J0 H0
 ((χ z • f z, fderiv ℝ (fun y => χ y • f y) z),
   fderiv ℝ (fderiv ℝ (fun y => χ y • f y)) z) =
χ z • differential B DB G0 J0 H0 p +
(∑ i : Fin 3, ∑ j : Fin 3, inverseEntries G0 i j •
 (fderiv ℝ χ z (basis3 i) • tensorJet W (t,z) (basis3 j) +
  fderiv ℝ χ z (basis3 j) • tensorJet W (t,z) (basis3 i) +
  fderiv ℝ (fderiv ℝ χ) z (basis3 i) (basis3 j) • f z)) +
DeTurckSpatialCoefficients.firstOrder B DB G0 J0 ((fderiv ℝ χ z).smulRight (f z)) := by
  dsimp only
  obtain ⟨hfirst, hsecond⟩ := cutoff_hasFDerivAt_two χ
    (fun y => tensorValue W (t,y)) (fun y => tensorJet W (t,y))
    (tensorHessian W (t,z)) z hχ
    (fun y => tensorJet_hasFDerivAt α T W t y ht)
    (tensorHessian_hasFDerivAt α T W t z ht)
  rw [hfirst.fderiv, hsecond.fderiv]
  exact differential_cutoff B DB G0 J0 H0 (χ z) (fderiv ℝ χ z)
    (fderiv ℝ (fderiv ℝ χ) z)
    ((tensorValue W (t,z), tensorJet W (t,z)), tensorHessian W (t,z))

example (α T : ℝ) (W : Inputs α T) (t : ℝ) (ht : t ∈ Icc 0 T)
    (hα : 0 < α) (z : E) (U : Set E) (hU : IsOpen U) (hz : z ∈ U)
    (hs : ∀ᶠ y in nhds z, ∀ v w : E,
      tensorValue W (t,y) v w = tensorValue W (t,y) w v) :
∃ η : E → ℝ,
 ContDiff ℝ ∞ (realized η (fun y => tensorValue W (t,y)) z) ∧
 HasCompactSupport (realized η (fun y => tensorValue W (t,y)) z) ∧
 tsupport (realized η (fun y => tensorValue W (t,y)) z) ⊆ U ∧
 (∀ y v w, realized η (fun y => tensorValue W (t,y)) z y v w =
   realized η (fun y => tensorValue W (t,y)) z y w v) ∧
 realized η (fun y => tensorValue W (t,y)) z z = tensorValue W (t,z) ∧
 fderiv ℝ (realized η (fun y => tensorValue W (t,y)) z) z = tensorJet W (t,z) ∧
 fderiv ℝ (fderiv ℝ (realized η (fun y => tensorValue W (t,y)) z)) z = tensorHessian W (t,z) := by
  obtain ⟨η, _hη, _hcη, _hηU, _hone, hF, hcF, hFU, hsym, hzero, hone, htwo⟩ :=
    exists_compact_symmetric_realization (fun y => tensorValue W (t,y)) z U hU hz
      (tensorValue_contDiff_two α T W t hα ht).contDiffAt hs
  have hfirst : fderiv ℝ (fun y => tensorValue W (t,y)) =
      fun y => tensorJet W (t,y) := by
    funext y
    exact (tensorJet_hasFDerivAt α T W t y ht).fderiv
  refine ⟨η, hF, hcF, hFU, hsym, hzero, hone.trans ?_, htwo.trans ?_⟩
  · exact (tensorJet_hasFDerivAt α T W t z ht).fderiv
  · rw [hfirst]
    exact (tensorHessian_hasFDerivAt α T W t z ht).fderiv
end Poincare.LocalizationApplication
