import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();source=root/'harness/v2/state/core-deturck-localization-20260930';destination=root/'harness/reports/core-deturck-localization-20260930-evidence'
receipt=json.loads((root/'harness/v2/state/verification/latest.json').read_text())
assert receipt['identity']['head']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert all(v['exit_code']==(1 if k=='completion' else 0) for k,v in receipt['phases'].items())
assert 'Completion boundary status: reserved theorem absent only' in (root/'CURRENT_STATUS.md').read_text()
assert not destination.exists(),'append-only archive destination exists'
destination.mkdir();entries=[]
def save(path,relative):
 data=path.read_bytes();out=destination/(str(relative)+'.gz');out.parent.mkdir(parents=True,exist_ok=True);packed=gzip.compress(data,compresslevel=9,mtime=0);out.write_bytes(packed);entries.append({'source':str(path.relative_to(root)),'archive':str(out.relative_to(destination)),'sha256':hashlib.sha256(data).hexdigest(),'gzip_sha256':hashlib.sha256(packed).hexdigest(),'bytes':len(data)})
for path in sorted(source.rglob('*')):
 if path.is_file():save(path,Path('attempts')/path.relative_to(source))
save(root/'harness/v2/state/verification/latest.json',Path('checkpoint')/'latest.json')
save(root/'CURRENT_STATUS.md',Path('checkpoint')/'CURRENT_STATUS.md')
checkpoint=root/receipt['evidence_directory']
for path in sorted(checkpoint.rglob('*')):
 if path.is_file():save(path,Path('checkpoint')/path.relative_to(checkpoint))
(destination/'manifest.json').write_text(json.dumps({'schema_version':'1.0','source_commit':receipt['identity']['head'],'backend':'local Codex helpers; not registered Pi/Leanstral Jobs','entries':entries},indent=2)+'\n')
print('Evidence archived:',destination)

for entry in entries:
    packed=(destination/entry['archive']).read_bytes()
    assert hashlib.sha256(packed).hexdigest()==entry['gzip_sha256']
    assert hashlib.sha256(gzip.decompress(packed)).hexdigest()==entry['sha256']
print('Every compressed evidence hash verified')
