import Poincare.Global.DeTurckJetRealizationDefinitions
import Poincare.Global.DeTurckTensorSecondJetDefinitions
import Lean
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
open Lean Elab Command Term
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "letI : NormedAddCommGroup Poincare.DeTurckPrincipalSecondJet.Jet1 := ContinuousLinearMap.toNormedAddCommGroup\n(𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ);\nletI : NormedSpace ℝ Poincare.DeTurckPrincipalSecondJet.Jet1 := ContinuousLinearMap.toNormedSpace\n(𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);\nletI : NormedAddCommGroup Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedAddCommGroup\n(𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ);\nletI : NormedSpace ℝ Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedSpace\n(𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);\n∀ (B : Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)\n(DB : Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] Poincare.DeTurckPrincipalSecondJet.E)\n(G0 : Poincare.DeTurckPrincipalSecondJet.Bilin) (J0 : Poincare.DeTurckPrincipalSecondJet.Jet1) (H0 : Poincare.DeTurckJetLinearization.Jet2)\n(c : ℝ) (dc : Poincare.DeTurckPrincipalSecondJet.E →L[ℝ] ℝ) (ddc : Poincare.DeTurckPrincipalSecondJet.Bilin) (p : Poincare.DeTurckJetLinearization.Variables),\nPoincare.DeTurckJetLinearization.differential B DB G0 J0 H0 (Poincare.DeTurckLocalization.cutoffVariables c dc ddc p) =\nc • Poincare.DeTurckJetLinearization.differential B DB G0 J0 H0 p +\n(∑ i : Fin 3, ∑ j : Fin 3, Poincare.DeTurckPrincipalSecondJet.inverseEntries G0 i j •\n (dc (Poincare.DeTurckPrincipalSecondJet.basis3 i) • p.1.2 (Poincare.DeTurckPrincipalSecondJet.basis3 j) + dc (Poincare.DeTurckPrincipalSecondJet.basis3 j) • p.1.2 (Poincare.DeTurckPrincipalSecondJet.basis3 i) + ddc (Poincare.DeTurckPrincipalSecondJet.basis3 i) (Poincare.DeTurckPrincipalSecondJet.basis3 j) • p.1.1)) +\nPoincare.DeTurckSpatialCoefficients.firstOrder B DB G0 J0 (dc.smulRight p.1.1)" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: Poincare.DeTurckLocalization.differential_cutoff"
