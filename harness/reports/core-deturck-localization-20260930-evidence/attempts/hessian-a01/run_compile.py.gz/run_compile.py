from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
wd=Path('/Users/mjkang/.codex/worktrees/core-localization-hessian/poincare')
ev=Path(__file__).parent
src=wd/'Poincare/Global/DeTurckTensorSecondJet.lean'
label=sys.argv[1]
out=ev/label
out.mkdir()
(out/'source.lean').write_bytes(src.read_bytes())
cmd=['env','LEAN_NUM_THREADS=1','lake','env','lean','Poincare/Global/DeTurckTensorSecondJet.lean']
start=time.time()
with (out/'compiler.log').open('wb') as log:
 p=subprocess.run(cmd,cwd=wd,stdout=log,stderr=subprocess.STDOUT)
(out/'exit.json').write_text(json.dumps({'command':cmd,'exit_code':p.returncode,'seconds':time.time()-start,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest()},indent=2)+'\n')
print((out/'compiler.log').read_text())
print('EXIT',p.returncode,'EVIDENCE',out)
sys.exit(p.returncode)
