import Poincare.Global.DeTurckTensorSecondJetDefinitions

noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
open scoped BigOperators

namespace Poincare.DeTurckTensorSecondJet
open DeTurckPrincipalSecondJet DeTurckJetLinearization

local instance tensorSecondJetBilinBoundedSMul : IsBoundedSMul ℝ Bilin :=
  .of_norm_smul_le (fun c A => ContinuousLinearMap.opNorm_smul_le c A)
local instance tensorSecondJetJet1Group : NormedAddCommGroup Jet1 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance tensorSecondJetJet1Space : NormedSpace ℝ Jet1 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance tensorSecondJetJet2Group : NormedAddCommGroup Jet2 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1) (σ₁₂ := RingHom.id ℝ)
local instance tensorSecondJetJet2Space : NormedSpace ℝ Jet2 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

/-- The reconstructed second jet differentiates the same tensor first jet. -/
theorem tensorHessian_hasFDerivAt : ∀ (α T : ℝ)
    (W : DeTurckCoupledForcing.Inputs α T) (t : ℝ) (z : E),
    t ∈ Set.Icc 0 T →
    HasFDerivAt (fun y => DeTurckCoupledForcing.tensorJet W (t,y))
      (tensorHessian W (t,z)) z := by
  intro α T W t z ht
  unfold DeTurckCoupledForcing.tensorJet tensorHessian
  exact HasFDerivAt.fun_sum (fun a _ => HasFDerivAt.fun_sum (fun b _ =>
    (((ContinuousLinearMap.smulRightL ℝ E Bilin).flip
      (DeTurckTensorBasis.tensor a b)).hasFDerivAt.comp z
        ((W (a,b)).hasFDeriv_du t ht z))))

end Poincare.DeTurckTensorSecondJet
