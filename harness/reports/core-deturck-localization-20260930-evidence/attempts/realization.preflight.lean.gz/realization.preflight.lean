import Poincare.Global.DeTurckJetRealizationDefinitions
import Poincare.Global.DeTurckTensorSecondJetDefinitions
import Lean
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
open Lean Elab Command Term
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "letI : NormedAddCommGroup Poincare.DeTurckPrincipalSecondJet.Jet1 := ContinuousLinearMap.toNormedAddCommGroup\n  (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ);\nletI : NormedSpace ℝ Poincare.DeTurckPrincipalSecondJet.Jet1 := ContinuousLinearMap.toNormedSpace\n  (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Bilin) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);\nletI : NormedAddCommGroup Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedAddCommGroup\n  (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ);\nletI : NormedSpace ℝ Poincare.DeTurckJetLinearization.Jet2 := ContinuousLinearMap.toNormedSpace\n  (𝕜 := ℝ) (𝕜₂ := ℝ) (E := Poincare.DeTurckPrincipalSecondJet.E) (F := Poincare.DeTurckPrincipalSecondJet.Jet1) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ);\n∀ (h : Poincare.DeTurckPrincipalSecondJet.E → Poincare.DeTurckPrincipalSecondJet.Bilin) (z : Poincare.DeTurckPrincipalSecondJet.E) (U : Set Poincare.DeTurckPrincipalSecondJet.E),\nIsOpen U → z ∈ U → ContDiffAt ℝ (2 : WithTop ENat) h z →\n(Filter.Eventually (fun y => ∀ v w : Poincare.DeTurckPrincipalSecondJet.E, h y v w = h y w v) (nhds z)) →\n∃ η : Poincare.DeTurckPrincipalSecondJet.E → ℝ,\nContDiff ℝ ((⊤ : ENat) : WithTop ENat) η ∧ HasCompactSupport η ∧ tsupport η ⊆ U ∧\n(Filter.Eventually (fun y => η y = 1) (nhds z)) ∧\nContDiff ℝ ((⊤ : ENat) : WithTop ENat) (Poincare.DeTurckJetRealization.realized η h z) ∧\nHasCompactSupport (Poincare.DeTurckJetRealization.realized η h z) ∧ tsupport (Poincare.DeTurckJetRealization.realized η h z) ⊆ U ∧\n(∀ y v w : Poincare.DeTurckPrincipalSecondJet.E, Poincare.DeTurckJetRealization.realized η h z y v w = Poincare.DeTurckJetRealization.realized η h z y w v) ∧\nPoincare.DeTurckJetRealization.realized η h z z = h z ∧\nfderiv ℝ (Poincare.DeTurckJetRealization.realized η h z) z = fderiv ℝ h z ∧\nfderiv ℝ (fderiv ℝ (Poincare.DeTurckJetRealization.realized η h z)) z = fderiv ℝ (fderiv ℝ h) z" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: Poincare.DeTurckJetRealization.exists_compact_symmetric_realization"
