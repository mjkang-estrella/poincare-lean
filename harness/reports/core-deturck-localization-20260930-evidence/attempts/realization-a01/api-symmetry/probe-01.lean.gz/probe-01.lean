import Poincare.Global.DeTurckJetRealizationDefinitions
import Mathlib.Analysis.Calculus.FDeriv.Equiv

noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
open Filter Topology
namespace SymmetryAPI
open Poincare.DeTurckPrincipalSecondJet Poincare.DeTurckJetLinearization
local instance apiJet1Group : NormedAddCommGroup Jet1 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance apiJet1Space : NormedSpace ℝ Jet1 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance apiJet2Group : NormedAddCommGroup Jet2 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1) (σ₁₂ := RingHom.id ℝ)
local instance apiJet2Space : NormedSpace ℝ Jet2 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

abbrev tensorFlip : Bilin ≃L[ℝ] Bilin :=
  (ContinuousLinearMap.flipₗᵢ ℝ E E ℝ).toContinuousLinearEquiv
abbrev jetFlip : Jet1 ≃L[ℝ] Jet1 :=
  (ContinuousLinearEquiv.refl ℝ E).arrowCongr tensorFlip

theorem first_symmetry (h : E → Bilin) (z : E)
    (hs : ∀ᶠ y in 𝓝 z, ∀ v w : E, h y v w = h y w v) :
    ∀ p v w : E, fderiv ℝ h z p v w = fderiv ℝ h z p w v := by
  have heq : h =ᶠ[𝓝 z] (tensorFlip ∘ h) := by
    filter_upwards [hs] with y hy
    ext v w
    exact hy v w
  have hd : fderiv ℝ h z =
      (tensorFlip : Bilin →L[ℝ] Bilin).comp (fderiv ℝ h z) :=
    heq.fderiv_eq.trans tensorFlip.comp_fderiv
  intro p v w
  exact congrArg (fun J : Jet1 => J p v w) hd

theorem second_symmetry (h : E → Bilin) (z : E)
    (hs : ∀ᶠ y in 𝓝 z, ∀ v w : E, h y v w = h y w v) :
    ∀ p q v w : E, fderiv ℝ (fderiv ℝ h) z p q v w =
      fderiv ℝ (fderiv ℝ h) z p q w v := by
  have heq : h =ᶠ[𝓝 z] (tensorFlip ∘ h) := by
    filter_upwards [hs] with y hy
    ext v w
    exact hy v w
  have heq1 : fderiv ℝ h =ᶠ[𝓝 z] (jetFlip ∘ fderiv ℝ h) := by
    filter_upwards [heq.fderiv] with y hy
    exact hy.trans tensorFlip.comp_fderiv
  have hd : fderiv ℝ (fderiv ℝ h) z =
      (jetFlip : Jet1 →L[ℝ] Jet1).comp (fderiv ℝ (fderiv ℝ h) z) :=
    heq1.fderiv_eq.trans jetFlip.comp_fderiv
  intro p q v w
  exact congrArg (fun H : Jet2 => H p q v w) hd

end SymmetryAPI
