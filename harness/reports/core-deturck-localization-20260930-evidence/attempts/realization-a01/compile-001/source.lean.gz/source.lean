import Poincare.Global.DeTurckJetRealizationDefinitions
import Poincare.Global.BufferedFrozenParabolicSolver
import Mathlib.Analysis.Calculus.FDeriv.Symmetric

noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
open Set Filter
open scoped ContDiff Topology

namespace Poincare.DeTurckJetRealization
open DeTurckPrincipalSecondJet DeTurckJetLinearization

local instance compactJetRealizationBilinBoundedSMul : IsBoundedSMul ℝ Bilin :=
  .of_norm_smul_le (fun c A => ContinuousLinearMap.opNorm_smul_le c A)
local instance compactJetRealizationJet1Group : NormedAddCommGroup Jet1 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance compactJetRealizationJet1Space : NormedSpace ℝ Jet1 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance compactJetRealizationJet2Group : NormedAddCommGroup Jet2 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1) (σ₁₂ := RingHom.id ℝ)
local instance compactJetRealizationJet2Space : NormedSpace ℝ Jet2 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

/-- The full quadratic field is smooth in the original tensor operator norm. -/
theorem polynomial_contDiff (z : E) (h0 : Bilin) (J0 : Jet1) (H0 : Jet2) :
    ContDiff ℝ ∞ (polynomial z h0 J0 H0) := by
  have hd : ContDiff ℝ ∞ (fun y : E => y - z) := contDiff_id.sub contDiff_const
  exact (contDiff_const.add (J0.contDiff.comp hd)).add
    (((contDiff_const.clm_apply hd).clm_apply hd).const_smul (1 / 2 : ℝ))

/-- Multiplying the polynomial by a cutoff confines its whole tensor support. -/
theorem realized_tsupport_subset (η : E → ℝ) (h : E → Bilin) (z : E) :
    tsupport (realized η h z) ⊆ tsupport η :=
  tsupport_smul_subset_left η _

end Poincare.DeTurckJetRealization
