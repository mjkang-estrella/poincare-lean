import Poincare.Global.DeTurckJetRealizationDefinitions
noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
open scoped ContDiff
namespace PolynomialAPIProbe
open Poincare.DeTurckPrincipalSecondJet Poincare.DeTurckJetLinearization
open Poincare.DeTurckJetRealization
local instance probeBilinSMul : IsBoundedSMul ℝ Bilin :=
  .of_norm_smul_le (fun c A => ContinuousLinearMap.opNorm_smul_le c A)
local instance probeJet1Group : NormedAddCommGroup Jet1 :=
  ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance probeJet1Space : NormedSpace ℝ Jet1 :=
  ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance probeJet2Group : NormedAddCommGroup Jet2 :=
  ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1) (σ₁₂ := RingHom.id ℝ)
local instance probeJet2Space : NormedSpace ℝ Jet2 :=
  ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)

 theorem polynomial_smooth (z : E) (h0 : Bilin) (J0 : Jet1) (H0 : Jet2) :
    ContDiff ℝ ∞ (polynomial z h0 J0 H0) := by
  have hd : ContDiff ℝ ∞ (fun y : E => y - z) := contDiff_id.sub contDiff_const
  exact (contDiff_const.add (J0.contDiff.comp hd)).add
    (((H0.contDiff.comp hd).clm_apply hd).const_smul (1 / 2 : ℝ))

 theorem polynomial_value (z : E) (h0 : Bilin) (J0 : Jet1) (H0 : Jet2) :
    polynomial z h0 J0 H0 z = h0 := by
  simp [polynomial]

 theorem polynomial_hasFDeriv (z : E) (h0 : Bilin) (J0 : Jet1) (H0 : Jet2) (y : E) :
    HasFDerivAt (polynomial z h0 J0 H0)
      (J0 + (1 / 2 : ℝ) • (H0 (y-z) + H0.flip (y-z))) y := by
  have hd := (hasFDerivAt_id (𝕜 := ℝ) y).sub_const z
  have hJ := J0.hasFDerivAt.comp y hd
  have hH := (H0.hasFDerivAt.comp y hd).clm_apply hd
  simpa [polynomial] using (hJ.const_add h0).add (hH.const_smul (1 / 2 : ℝ))

 theorem polynomial_first (z : E) (h0 : Bilin) (J0 : Jet1) (H0 : Jet2) :
    fderiv ℝ (polynomial z h0 J0 H0) z = J0 := by
  simpa using (polynomial_hasFDeriv z h0 J0 H0 z).fderiv

 theorem polynomial_second (z : E) (h0 : Bilin) (J0 : Jet1) (H0 : Jet2)
    (hH : ∀ v w : E, H0 v w = H0 w v) :
    fderiv ℝ (fderiv ℝ (polynomial z h0 J0 H0)) z = H0 := by
  have hflip : H0.flip = H0 := by
    apply ContinuousLinearMap.ext
    intro v
    apply ContinuousLinearMap.ext
    intro w
    exact hH w v
  have hderiv : fderiv ℝ (polynomial z h0 J0 H0) = fun y => J0 + H0 (y-z) := by
    funext y
    rw [(polynomial_hasFDeriv z h0 J0 H0 y).fderiv, hflip]
    rw [← two_smul ℝ (H0 (y-z)), smul_smul]
    norm_num
  rw [hderiv]
  have hd := (hasFDerivAt_id (𝕜 := ℝ) z).sub_const z
  simpa using ((H0.hasFDerivAt.comp z hd).const_add J0).fderiv
end PolynomialAPIProbe
