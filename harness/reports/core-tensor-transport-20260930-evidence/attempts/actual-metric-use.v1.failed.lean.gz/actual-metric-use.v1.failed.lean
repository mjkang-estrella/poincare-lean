import Poincare.Global.MetricAdaptedLocalParametrix
import Poincare.Global.SmoothInitialMetricExistence
import Poincare.Global.BufferedChartTransitionExtensions
import Poincare.Global.BufferedTensorGraphTransportOperator

noncomputable section
set_option autoImplicit false
open Set Filter
open scoped Manifold ContDiff Topology
open Poincare Poincare.FiniteAtlasParabolicTensorSpace
universe u

example {M : Type u} [TopologicalSpace M] [T2Space M] [CompactSpace M]
    [ChartedSpace (ClosedSmoothModel 3) M]
    [IsManifold (closedSmoothModelWithCorners 3) ∞ M]
    (α : ℝ) (hα : 0 < α) (hα1 : α < 1) :
    ∃ A : AtlasData M,
    ∃ ξ : Fin A.cover.chartCount → ClosedSmoothModel 3 → ℝ,
    ∃ θ : Fin A.cover.chartCount → Fin A.cover.chartCount → ClosedSmoothModel 3 → ℝ,
    ∃ F : Fin A.cover.chartCount → Fin A.cover.chartCount → ClosedSmoothModel 3 → ClosedSmoothModel 3,
    ∀ i j (c d : Fin 3),
      ∃ C : ℝ, 0 ≤ C ∧ ∀ T ∈ Ioc (0 : ℝ) 1,
      ∃ B : ((Fin 3 × Fin 3) → ParabolicSolutionGraph.Graph (E := ClosedSmoothModel 3) α T) →L[ℝ]
        ParabolicSolutionGraph.Graph (E := ClosedSmoothModel 3) α T,
        ‖B‖ ≤ C ∧ ∀ w p, (B w).u p = ∑ a : Fin 3, ∑ b : Fin 3,
          BufferedTensorGraphTransport.weight A i (θ i j) (ξ j) (F i j) a b c d p.2 *
            (w (a,b)).u (p.1, F i j p.2) := by
  obtain ⟨g0⟩ := SmoothInitialMetricExistence.exists_initial_metric (M := M)
  obtain ⟨A, ψ, ξ, hb, _⟩ :=
    MetricAdaptedLocalParametrix.exists_metric_adapted_local_parametrix g0 α hα hα1
  have hcξ : ∀ k, HasCompactSupport (ξ k) := by
    intro k
    rcases hb k with ⟨_, _, _, _, _, h, _⟩
    exact h
  have htξ : ∀ k, tsupport (ξ k) ⊆ (chart A k).target := by
    intro k
    rcases hb k with ⟨_, _, _, _, _, _, _, _, h, _⟩
    exact h
  have hoξ : ∀ k, ∀ z ∈ tsupport (ξ k),
      ∀ᶠ y in 𝓝 z, GeodesicTransport.cutoff (n := 3) (A.cover.anchor k) y = 1 := by
    intro k
    rcases hb k with ⟨_, _, _, _, _, _, _, _, _, h⟩
    exact h
  have hp : ∀ k, ∀ z ∈ coordSupport A k,
      ∀ᶠ y in 𝓝 z, GeodesicTransport.cutoff (n := 3) (A.cover.anchor k) y = 1 := by
    intro k z hz
    rcases hb k with ⟨_, _, hψone, _, _, _, _, hξψ, _, hcut⟩
    have hψz : ψ k z = 1 := (hψone z hz).eq_of_nhds
    have hzψ : z ∈ tsupport (ψ k) := subset_tsupport (ψ k) (by simp [hψz])
    have hξz : ξ k z = 1 := hξψ z hzψ
    exact hcut z (subset_tsupport (ξ k) (by simp [hξz]))
  obtain ⟨θ, F, hg⟩ := BufferedChartTransitionExtensions.exists_gated_chart_extensions
    A ξ hcξ htξ hoξ hp
  refine ⟨A, ξ, θ, F, ?_⟩
  intro i j c d
  rcases hg i j with ⟨hθ, hcθ, _, hθO, hθK, hF, hcF, hagree, _⟩
  have hξ : ContDiff ℝ ∞ (ξ j) := by
    rcases hb j with ⟨_, _, _, _, h, _⟩
    exact h
  obtain ⟨C, hC, hB⟩ := BufferedTensorGraphTransport.exists_destination_entry_transport
    M A i j (θ i j) (ξ j) (F i j) c d hθ hcθ hξ hF hcF
    (fun _ hz => (hθO hz).1.1) hagree
    (fun z hz => (hθK z hz).eq_of_nhds) α hα hα1
  refine ⟨C, hC, ?_⟩
  intro T hT
  obtain ⟨B, hnorm, hraw, _⟩ := hB T hT
  exact ⟨B, hnorm, hraw⟩
