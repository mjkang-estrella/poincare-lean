import Poincare.Global.BufferedTensorGraphTransportDefinitions
import Lean
open Lean Elab Command Term
open scoped Manifold ContDiff Topology
universe u
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M]\n[ChartedSpace (Poincare.ClosedSmoothModel 3) M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M)\n(i : Fin A.cover.chartCount) (θ ξ : Poincare.ClosedSmoothModel 3 → ℝ)\n(F : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3)\n(a b c d : Fin 3),\ntsupport θ ⊆ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).target →\n∀ z : Poincare.ClosedSmoothModel 3,\nz ∉ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A i →\nPoincare.BufferedTensorGraphTransport.weight A i θ ξ F a b c d z = 0" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"
  logInfo "PREFLIGHT_OK: weight_zero_off_coordSupport"
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M]\n[ChartedSpace (Poincare.ClosedSmoothModel 3) M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M)\n(i : Fin A.cover.chartCount) (θ ξ : Poincare.ClosedSmoothModel 3 → ℝ)\n(F : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3)\n(a b c d : Fin 3),\n∀ j : Fin A.cover.chartCount,\ntsupport θ ⊆ ((Poincare.FiniteAtlasParabolicTensorSpace.chart A i).symm.trans (Poincare.FiniteAtlasParabolicTensorSpace.chart A j)).source →\n(∀ z ∈ tsupport θ, ∀ᶠ y in 𝓝 z, F y = Poincare.FiniteAtlasParabolicTensorSpace.change A i j y) →\n(∀ z ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i) ''\n  (tsupport (A.partition i) ∩ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).symm '' tsupport ξ), θ z = 1) →\n∀ (f : Poincare.ClosedSmoothModel 3 → ℝ) (x : M), x ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).source →\nPoincare.BufferedTensorGraphTransport.weight A i θ ξ F a b c d (Poincare.FiniteAtlasParabolicTensorSpace.chart A i x) * f (F (Poincare.FiniteAtlasParabolicTensorSpace.chart A i x)) =\nA.partition i x * (if x ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).source then\n  ξ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j x) * Poincare.FiniteAtlasParabolicTensorSpace.jac A i j x a c * Poincare.FiniteAtlasParabolicTensorSpace.jac A i j x b d * f (Poincare.FiniteAtlasParabolicTensorSpace.chart A j x)\n  else 0)" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"
  logInfo "PREFLIGHT_OK: weight_pullback_chart"
