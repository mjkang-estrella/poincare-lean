import json,hashlib,subprocess
from pathlib import Path
from harness.v2.runtime.validation import validate_task,validate_statement_contract,validate_statement_readback
root=Path.cwd(); folder=root/'harness/v2/contracts/core-tensor-transport-20260930'
for slug,mod in [('weights','BufferedTensorGraphTransportWeights'),('values','BufferedTensorGraphTransportValues'),('operator','BufferedTensorGraphTransportOperator')]:
 manifest=folder/f'{slug}.contract.json'; m=json.loads(manifest.read_text()); c=m['statement_contract']; report=root/c['review']['report_path']
 if not report.exists(): continue
 raw=report.read_bytes(); r=json.loads(raw)
 c['review'].update(verdict=r['verdict'],report_sha256=hashlib.sha256(raw).hexdigest())
 validate_statement_contract(c); validate_statement_readback(c,raw)
 manifest.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
 t=json.loads((root/'harness/v2/tasks/core-input-20260930-graph-pullback.json').read_text())
 t.pop('accepted_commit',None); t['id']='core-input-20260930-tensor-'+slug; t['status']='proposed'
 t['base_commit']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 t['objective']={'title':'Construct actual tensor '+slug+' toward universal Hamilton existence','statement':'Core assumption helped: UniversalHamiltonConvergenceStatement, through genuine general Ricci-flow inputs. Subsequent proof: actual bounded destination-entry Graph transport, then global tensor compatibility and genuine signed DeTurck L/P/R contraction. Construct coefficients/operators from actual atlas/gated chart maps; no supplied operator, flow, convergence or sphere-recognition package may replace construction.','deliverables':[d['name'] for d in c['declarations']]}
 t['scope']['allowed_paths']=['Poincare/Global/'+mod+'.lean']
 t['scope']['forbidden_paths']+=['Poincare/Global/BufferedTensorGraphTransportDefinitions.lean']
 t['context']['files']=['README.md','HANDOFF.md','docs/PROJECT_MAP.md','AGENTS.md',c['review']['report_path'],'harness/v2/contracts/core-tensor-transport-20260930/construction-context.md','Poincare/Global/BufferedTensorGraphTransportDefinitions.lean','Poincare/Global/FiniteAtlasParabolicTensorSpace.lean','Poincare/Global/BufferedChartTransitionExtensions.lean','Poincare/Global/ClosedLaplacianStokesGlobalCoefficients.lean']
 t['context']['depends_on']=[]
 if slug=='operator':
  t['context']['depends_on']=['core-input-20260930-tensor-weights','core-input-20260930-tensor-values']
  t['context']['files']+=['Poincare/Global/BufferedTensorGraphTransportWeights.lean','Poincare/Global/BufferedTensorGraphTransportValues.lean','Poincare/Global/ParabolicSpatialGraphPullback.lean','Poincare/Global/BufferedFrozenParabolicSolver.lean','Poincare/Global/ParabolicCutoffCommutator.lean','Poincare/Global/ParabolicSolutionGraph.lean','Poincare/Global/ParabolicHolderSpace.lean']
 t['context']['symbols']=[d['name'] for d in c['declarations']]
 t['acceptance']['required_declarations']=t['context']['symbols']
 t['acceptance']['commands'][0][-1]=t['scope']['allowed_paths'][0]
 t['acceptance']['commands'][1][-1]=t['scope']['allowed_paths'][0]
 t['acceptance']['commands'][3][-1]=str(manifest.relative_to(root))
 t['statement_contract']=c
 validate_task(t)
 (root/f"harness/v2/tasks/{t['id']}.json").write_text(json.dumps(t,ensure_ascii=False,indent=2)+'\n')
