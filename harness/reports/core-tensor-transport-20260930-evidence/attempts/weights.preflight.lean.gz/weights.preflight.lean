import Poincare.Global.BufferedTensorGraphTransportDefinitions
import Lean
open Lean Elab Command Term
open scoped Manifold ContDiff
universe u
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M]\n[ChartedSpace (Poincare.ClosedSmoothModel 3) M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M)\n(i : Fin A.cover.chartCount) (θ ξ : Poincare.ClosedSmoothModel 3 → ℝ)\n(F : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3)\n(a b c d : Fin 3),\nContDiff ℝ ((⊤ : ENat) : WithTop ENat) θ → HasCompactSupport θ →\ntsupport θ ⊆ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).target →\nContDiff ℝ ((⊤ : ENat) : WithTop ENat) ξ →\nContDiff ℝ ((⊤ : ENat) : WithTop ENat) F →\nContDiff ℝ ((⊤ : ENat) : WithTop ENat) (Poincare.BufferedTensorGraphTransport.weight A i θ ξ F a b c d) ∧\nHasCompactSupport (Poincare.BufferedTensorGraphTransport.weight A i θ ξ F a b c d)" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"
  logInfo "PREFLIGHT_OK: contDiff_hasCompactSupport_weight"
