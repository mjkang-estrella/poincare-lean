import json,hashlib
from pathlib import Path
from harness.v2.runtime.validation import statement_contract_snapshot
root=Path.cwd();folder=root/'harness/v2/contracts/core-tensor-transport-20260930'
E='Poincare.ClosedSmoothModel 3';C='Poincare.FiniteAtlasParabolicTensorSpace.chart';J='Poincare.FiniteAtlasParabolicTensorSpace.jac';V='Poincare.FiniteAtlasBufferedTensorValue.value'
prefix=f'''∀ (M : Type u) [TopologicalSpace M]
[ChartedSpace ({E}) M]
[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]
(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M)
(ξ : Fin A.cover.chartCount → {E} → ℝ)
(W : Fin A.cover.chartCount → Fin 3 → Fin 3 → {E} → ℝ),\n'''
types=[('weighted_transition',prefix+f'''∀ (i k : Fin A.cover.chartCount) (a b : Fin 3) (x : M),
x ∈ ({C} A i).source → x ∈ ({C} A k).source →
A.partition k x * {V} A ξ W i a b x =
A.partition i x * ∑ p : Fin 3, ∑ q : Fin 3,
 ({J} A i k x p a * {J} A i k x q b) * {V} A ξ W k p q x'''),('symmetric',prefix+f'''(∀ j a b z, W j a b z = W j b a z) →
∀ i a b x, {V} A ξ W i a b x = {V} A ξ W i b a x''')]
pins=['Poincare/Global/RiemannianContext.lean','Poincare/Global/FiniteAtlasParabolicTensorSpace.lean','Poincare/Global/FiniteAtlasBufferedTensorValueDefinitions.lean']
c={'imports':['Poincare.Global.FiniteAtlasBufferedTensorValueCompatibility'],'declarations':[{'name':'Poincare.FiniteAtlasBufferedTensorValue.'+n,'lean_type':t,'universes':['u']} for n,t in types],'definition_files':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in pins],'author':'root-orchestrator'}
c['review']={'reviewer':'tensor-transport-readback','method':'blind-readback','snapshot_sha256':statement_contract_snapshot(c),'verdict':'pending','report_path':'harness/v2/contracts/core-tensor-transport-20260930/compatibility.readback.json','report_sha256':'0'*64}
(folder/'compatibility.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
pre='''import Poincare.Global.FiniteAtlasBufferedTensorValueDefinitions
import Lean
open Lean Elab Command Term
universe u
'''
for n,t in types:
 pre+=f'run_cmd liftTermElabM do\n  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(t,ensure_ascii=False)} with\n    | .ok s => pure s\n    | .error e => throwError e\n  let expected ← Term.elabType stx\n  Term.synthesizeSyntheticMVarsNoPostponing\n  let expected ← instantiateMVars expected\n  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"\n  logInfo "PREFLIGHT_OK: {n}"\n'
(root/'harness/v2/state/local-core-tensor-transport-20260930/compatibility.preflight.lean').write_text(pre)
