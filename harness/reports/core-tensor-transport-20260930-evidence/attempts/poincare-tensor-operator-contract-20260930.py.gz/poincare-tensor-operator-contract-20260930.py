exec(open('/tmp/poincare-freeze-tensor-20260930.py').read().split('for slug,mod,decls')[0])
# This script only writes the dependent operator draft; existing helper snapshots are untouched.
E='Poincare.ClosedSmoothModel 3'; G=f'Poincare.ParabolicSolutionGraph.Graph (E := {E}) α T'
base=f'''∀ (M : Type u) [TopologicalSpace M]
[ChartedSpace ({E}) M]
[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]
(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M)
(i j : Fin A.cover.chartCount) (θ ξ : {E} → ℝ)
(F : {E} → {E}) (c d : Fin 3),
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) θ → HasCompactSupport θ →
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) ξ →
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) F → HasCompactSupport F →
tsupport θ ⊆ (({chart} A i).symm.trans ({chart} A j)).source →
(∀ z ∈ tsupport θ, ∀ᶠ y in nhds z, F y = {change} A i j y) →
(∀ z ∈ ({chart} A i) ''
 (tsupport (A.partition i) ∩ ({chart} A j).symm '' tsupport ξ), θ z = 1) →
∀ α : ℝ, 0 < α → α < 1 →
∃ C : ℝ, 0 ≤ C ∧ ∀ T ∈ Set.Ioc (0 : ℝ) 1,
∃ B : ((Fin 3 × Fin 3) → ({G})) →L[ℝ] ({G}), ‖B‖ ≤ C ∧
(∀ w p, (B w).u p = ∑ a : Fin 3, ∑ b : Fin 3,
 Poincare.BufferedTensorGraphTransport.weight A i θ ξ F a b c d p.2 *
 (w (a,b)).u (p.1, F p.2)) ∧
(∀ w t z, z ∉ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A i →
 (B w).u (t,z) = 0) ∧
(∀ w t (x : M), x ∈ ({chart} A i).source →
 (B w).u (t,{chart} A i x) =
 A.partition i x * (@ite ℝ (x ∈ ({chart} A j).source) (Classical.propDecidable _)
   (∑ a : Fin 3, ∑ b : Fin 3,
     ξ ({chart} A j x) * {jac} A i j x a c * {jac} A i j x b d *
     (w (a,b)).u (t,{chart} A j x)) 0))'''
pins+=['Poincare/Global/ParabolicSolutionGraph.lean','Poincare/Global/ParabolicHolderSpace.lean']
c={'imports':['Poincare.Global.BufferedTensorGraphTransportOperator'],'declarations':[{'name':'Poincare.BufferedTensorGraphTransport.exists_destination_entry_transport','lean_type':base,'universes':['u']}],'definition_files':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in pins],'author':'root-orchestrator'}
c['review']={'reviewer':'tensor-transport-readback','method':'blind-readback','snapshot_sha256':statement_contract_snapshot(c),'verdict':'pending','report_path':'harness/v2/contracts/core-tensor-transport-20260930/operator.readback.json','report_sha256':'0'*64}
(folder/'operator.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
pre='''import Poincare.Global.BufferedTensorGraphTransportDefinitions
import Lean
open Lean Elab Command Term
universe u
'''
pre+=f'run_cmd liftTermElabM do\n  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(base,ensure_ascii=False)} with\n    | .ok s => pure s\n    | .error e => throwError e\n  let expected ← Term.elabType stx\n  Term.synthesizeSyntheticMVarsNoPostponing\n  let expected ← instantiateMVars expected\n  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"\n  logInfo "PREFLIGHT_OK: exists_destination_entry_transport"\n'
(root/'harness/v2/state/local-core-tensor-transport-20260930/operator.preflight.lean').write_text(pre)
