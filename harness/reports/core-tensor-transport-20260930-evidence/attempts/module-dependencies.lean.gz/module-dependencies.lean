import Poincare.Global.BufferedTensorGraphTransportOperator
import Poincare.Global.FiniteAtlasBufferedTensorValueCompatibility
import Lean
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for mod in #[`Poincare.Global.BufferedTensorGraphTransportDefinitions,
    `Poincare.Global.BufferedTensorGraphTransportWeights,
    `Poincare.Global.BufferedTensorGraphTransportValues,
    `Poincare.Global.BufferedTensorGraphTransportOperator,
    `Poincare.Global.FiniteAtlasBufferedTensorValueDefinitions,
    `Poincare.Global.FiniteAtlasBufferedTensorValueCompatibility] do
    let some idx := env.getModuleIdx? mod | throwError "module missing: {mod}"
    let mut count := 0
    for (n, info) in env.constants.map₁.toList do
      if env.getModuleIdxFor? n == some idx then
        if info.isUnsafe || info.isPartial then throwError "unsafe or partial declaration: {n}"
        let axs ← liftCoreM (collectAxioms n)
        unless axs.all (fun a => a == ``propext || a == ``Classical.choice || a == ``Quot.sound) do
          throwError "unexpected dependencies: {n}: {axs}"
        count := count + 1
    unless count > 0 do throwError "no declarations found: {mod}"
    logInfo m!"MODULE_DEPENDENCIES_PASS: {mod}"
