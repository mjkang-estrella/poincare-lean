import Poincare.Global.FiniteAtlasBufferedTensorValueDefinitions
import Lean
open Lean Elab Command Term
universe u
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M]\n[ChartedSpace (Poincare.ClosedSmoothModel 3) M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M)\n(ξ : Fin A.cover.chartCount → Poincare.ClosedSmoothModel 3 → ℝ)\n(W : Fin A.cover.chartCount → Fin 3 → Fin 3 → Poincare.ClosedSmoothModel 3 → ℝ),\n∀ (i k : Fin A.cover.chartCount) (a b : Fin 3) (x : M),\nx ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).source → x ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A k).source →\nA.partition k x * Poincare.FiniteAtlasBufferedTensorValue.value A ξ W i a b x =\nA.partition i x * ∑ p : Fin 3, ∑ q : Fin 3,\n (Poincare.FiniteAtlasParabolicTensorSpace.jac A i k x p a * Poincare.FiniteAtlasParabolicTensorSpace.jac A i k x q b) * Poincare.FiniteAtlasBufferedTensorValue.value A ξ W k p q x" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"
  logInfo "PREFLIGHT_OK: weighted_transition"
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M]\n[ChartedSpace (Poincare.ClosedSmoothModel 3) M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M)\n(ξ : Fin A.cover.chartCount → Poincare.ClosedSmoothModel 3 → ℝ)\n(W : Fin A.cover.chartCount → Fin 3 → Fin 3 → Poincare.ClosedSmoothModel 3 → ℝ),\n(∀ j a b z, W j a b z = W j b a z) →\n∀ i a b x, Poincare.FiniteAtlasBufferedTensorValue.value A ξ W i a b x = Poincare.FiniteAtlasBufferedTensorValue.value A ξ W i b a x" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"
  logInfo "PREFLIGHT_OK: symmetric"
