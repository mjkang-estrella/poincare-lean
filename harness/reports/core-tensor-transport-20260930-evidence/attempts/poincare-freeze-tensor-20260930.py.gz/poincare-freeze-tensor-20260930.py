import hashlib,json
from pathlib import Path
from harness.v2.runtime.validation import statement_contract_snapshot
root=Path.cwd(); folder=root/'harness/v2/contracts/core-tensor-transport-20260930'
common='''∀ (M : Type u) [TopologicalSpace M]
[ChartedSpace (Poincare.ClosedSmoothModel 3) M]
[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]
(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M)
(i : Fin A.cover.chartCount) (θ ξ : Poincare.ClosedSmoothModel 3 → ℝ)
(F : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3)
(a b c d : Fin 3),\n'''
weight='Poincare.BufferedTensorGraphTransport.weight A i θ ξ F a b c d'
chart='Poincare.FiniteAtlasParabolicTensorSpace.chart'
change='Poincare.FiniteAtlasParabolicTensorSpace.change'
jac='Poincare.FiniteAtlasParabolicTensorSpace.jac'
compact=common+f'''ContDiff ℝ ((⊤ : ENat) : WithTop ENat) θ → HasCompactSupport θ →
tsupport θ ⊆ ({chart} A i).target →
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) ξ →
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) F →
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) ({weight}) ∧
HasCompactSupport ({weight})'''
support=common+f'''tsupport θ ⊆ ({chart} A i).target →
∀ z : Poincare.ClosedSmoothModel 3,
z ∉ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A i →
{weight} z = 0'''
agreement=common+f'''∀ j : Fin A.cover.chartCount,
tsupport θ ⊆ (({chart} A i).symm.trans ({chart} A j)).source →
(∀ z ∈ tsupport θ, ∀ᶠ y in nhds z, F y = {change} A i j y) →
(∀ z ∈ ({chart} A i) ''
  (tsupport (A.partition i) ∩ ({chart} A j).symm '' tsupport ξ), θ z = 1) →
∀ (f : Poincare.ClosedSmoothModel 3 → ℝ) (x : M), x ∈ ({chart} A i).source →
{weight} ({chart} A i x) * f (F ({chart} A i x)) =
A.partition i x * (@ite ℝ (x ∈ ({chart} A j).source) (Classical.propDecidable _)
  (ξ ({chart} A j x) * {jac} A i j x a c * {jac} A i j x b d * f ({chart} A j x)) 0)'''
pins=['Poincare/Global/RiemannianContext.lean','Poincare/Global/FiniteAtlasParabolicTensorSpace.lean','Poincare/Global/BufferedTensorGraphTransportDefinitions.lean']
for slug,mod,decls in [('weights','BufferedTensorGraphTransportWeights',[('contDiff_hasCompactSupport_weight',compact)]),('values','BufferedTensorGraphTransportValues',[('weight_zero_off_coordSupport',support),('weight_pullback_chart',agreement)])]:
 c={'imports':['Poincare.Global.'+mod], 'declarations':[{'name':'Poincare.BufferedTensorGraphTransport.'+n,'lean_type':t,'universes':['u']} for n,t in decls], 'definition_files':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in pins], 'author':'root-orchestrator'}
 snap=statement_contract_snapshot(c)
 c['review']={'reviewer':'tensor-transport-readback','method':'blind-readback','snapshot_sha256':snap,'verdict':'pending','report_path':f'harness/v2/contracts/core-tensor-transport-20260930/{slug}.readback.json','report_sha256':'0'*64}
 (folder/f'{slug}.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
 pre='''import Poincare.Global.BufferedTensorGraphTransportDefinitions
import Lean
open Lean Elab Command Term
open scoped Manifold ContDiff
universe u
'''
 for n,t in decls:
  pre+=f'run_cmd liftTermElabM do\n  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(t,ensure_ascii=False)} with\n    | .ok s => pure s\n    | .error e => throwError e\n  let expected ← Term.elabType stx\n  Term.synthesizeSyntheticMVarsNoPostponing\n  let expected ← instantiateMVars expected\n  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"\n  logInfo "PREFLIGHT_OK: {n}"\n'
 (root/f'harness/v2/state/local-core-tensor-transport-20260930/{slug}.preflight.lean').write_text(pre)
(folder/'construction-context.md').write_text('''# Actual tensor transport toward core Hamilton existence

Core assumption helped: UniversalHamiltonConvergenceStatement, through actual general Ricci-flow inputs. The immediate subsequent consumer is a T-uniform bounded destination-entry tensor Graph operator formed by finite sums of actual cutoff operators composed with constructed nonlinear Graph pullbacks. Then global support/symmetry/transition compatibility and genuine signed DeTurck L/P/R contraction must be proved. No global flow, Hamilton limit or smoothability is supplied here.

The weight is theta times destination partition in inverse destination coordinates, source outer buffer evaluated at F, and two DF factors. The source entries already carry their own partition, so no second source partition is permitted. F goes from destination i coordinates to source j coordinates. The compact smooth gate is essential because the total compact extension F may have spurious off-chart values.

Use existing scalar cutoff extension for smoothness of partition composed with inverse chart, whose smoothness is only on the genuine chart target. Existing exists_uniform_cutoff_bound and exists_cutoff_operator provide uniform Graph multiplication without a new bound hypothesis. Nonlinear Graph pullback is already proved, including D2F.

Relevant context: BufferedChartTransitionExtensions.lean constructs actual theta/F from g0-derived atlas/buffers; its theta=1 germ applies on K=chart_i image (tsupport partition_i intersect inverse chart_j image tsupport xi_j). Agreement F=change near ALL tsupport theta supplies derivative agreement. Value theorem must use an explicit source-chart indicator. The zero-support theorem handles arbitrary ambient z, including off the destination target.

Both core smoothability and universal Hamilton existence remain open. Do not replace these obligations with recognition or assumed tensor operators. All failed attempts and final diff must be preserved. Local Codex helpers are not registered Pi/Leanstral runtime Jobs.
''')
