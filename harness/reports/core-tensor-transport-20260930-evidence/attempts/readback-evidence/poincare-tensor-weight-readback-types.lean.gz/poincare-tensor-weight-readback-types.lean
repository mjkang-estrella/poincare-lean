import Poincare.Global.FiniteAtlasParabolicTensorSpace

noncomputable section
set_option autoImplicit false
open scoped Manifold ContDiff

namespace Poincare.BufferedTensorGraphTransport
open FiniteAtlasParabolicTensorSpace
universe u

variable {M : Type u} [TopologicalSpace M]
  [ChartedSpace (ClosedSmoothModel 3) M]
  [IsManifold (closedSmoothModelWithCorners 3) ∞ M]

/-- Destination-partition transport coefficient from source slot `(a,b)`
to destination slot `(c,d)`. The gate prevents off-chart extension values
from contributing. The source entries already carry their own partition. -/
def weight (A : AtlasData M) (i : Fin A.cover.chartCount)
    (θ ξ : ClosedSmoothModel 3 → ℝ) (F : ClosedSmoothModel 3 → ClosedSmoothModel 3)
    (a b c d : Fin 3) (z : ClosedSmoothModel 3) : ℝ :=
  θ z * ((A.partition i) ((chart A i).symm z) * ξ (F z) *
    (fderiv ℝ F z ((EuclideanSpace.basisFun (Fin 3) ℝ) c)) a *
    (fderiv ℝ F z ((EuclideanSpace.basisFun (Fin 3) ℝ) d)) b)

end Poincare.BufferedTensorGraphTransport

#check (∀ (M : Type u) [TopologicalSpace M]
[ChartedSpace (Poincare.ClosedSmoothModel 3) M]
[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]
(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M)
(i : Fin A.cover.chartCount) (θ ξ : Poincare.ClosedSmoothModel 3 → ℝ)
(F : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3)
(a b c d : Fin 3),
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) θ → HasCompactSupport θ →
tsupport θ ⊆ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).target →
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) ξ →
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) F →
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (Poincare.BufferedTensorGraphTransport.weight A i θ ξ F a b c d) ∧
HasCompactSupport (Poincare.BufferedTensorGraphTransport.weight A i θ ξ F a b c d))

#check (∀ (M : Type u) [TopologicalSpace M]
[ChartedSpace (Poincare.ClosedSmoothModel 3) M]
[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]
(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M)
(i : Fin A.cover.chartCount) (θ ξ : Poincare.ClosedSmoothModel 3 → ℝ)
(F : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3)
(a b c d : Fin 3),
tsupport θ ⊆ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).target →
∀ z : Poincare.ClosedSmoothModel 3,
z ∉ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A i →
Poincare.BufferedTensorGraphTransport.weight A i θ ξ F a b c d z = 0)

#check (∀ (M : Type u) [TopologicalSpace M]
[ChartedSpace (Poincare.ClosedSmoothModel 3) M]
[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]
(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M)
(i : Fin A.cover.chartCount) (θ ξ : Poincare.ClosedSmoothModel 3 → ℝ)
(F : Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3)
(a b c d : Fin 3),
∀ j : Fin A.cover.chartCount,
tsupport θ ⊆ ((Poincare.FiniteAtlasParabolicTensorSpace.chart A i).symm.trans (Poincare.FiniteAtlasParabolicTensorSpace.chart A j)).source →
(∀ z ∈ tsupport θ, ∀ᶠ y in 𝓝 z, F y = Poincare.FiniteAtlasParabolicTensorSpace.change A i j y) →
(∀ z ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i) ''
  (tsupport (A.partition i) ∩ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).symm '' tsupport ξ), θ z = 1) →
∀ (f : Poincare.ClosedSmoothModel 3 → ℝ) (x : M), x ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).source →
Poincare.BufferedTensorGraphTransport.weight A i θ ξ F a b c d (Poincare.FiniteAtlasParabolicTensorSpace.chart A i x) * f (F (Poincare.FiniteAtlasParabolicTensorSpace.chart A i x)) =
A.partition i x * (@ite ℝ (x ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).source) (Classical.propDecidable _)
  (ξ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j x) * Poincare.FiniteAtlasParabolicTensorSpace.jac A i j x a c * Poincare.FiniteAtlasParabolicTensorSpace.jac A i j x b d * f (Poincare.FiniteAtlasParabolicTensorSpace.chart A j x)) 0))
