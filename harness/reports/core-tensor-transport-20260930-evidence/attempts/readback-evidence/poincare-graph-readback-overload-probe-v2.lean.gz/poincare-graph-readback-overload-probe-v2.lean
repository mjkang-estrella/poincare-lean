import Poincare.Global.ParabolicSolutionGraph
import Poincare.Global.RiemannianContext
noncomputable section
abbrev E3 := Poincare.ClosedSmoothModel 3
example (A : E3 →L[ℝ] E3 →L[ℝ] ℝ) (b : E3 →L[ℝ] ℝ)
    (D : E3 →L[ℝ] E3) (D2 : E3 →L[ℝ] E3 →L[ℝ] E3) (v w : E3) :
    ((((ContinuousLinearMap.compL ℝ E3 E3 ℝ).flip D).comp (A.comp D) +
       ((ContinuousLinearMap.compL ℝ E3 E3 ℝ) b).comp D2) v) w =
      A (D v) (D w) + b (D2 v w) := by rfl
example (α T : ℝ)
    (dF : Poincare.ParabolicHolder.Y (E := E3) α T (E3 →L[ℝ] E3)) :
    (‖dF‖ ^ 2 : ℝ) = Pow.pow ‖dF‖ (2 : ℕ) := by rfl
