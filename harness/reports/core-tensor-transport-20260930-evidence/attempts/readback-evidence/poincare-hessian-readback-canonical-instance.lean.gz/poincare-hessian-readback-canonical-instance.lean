import Poincare.Global.ParabolicSolutionGraph
import Poincare.Global.RiemannianContext
set_option autoImplicit false
#check (∃ C : ℝ, 0 ≤ C ∧ ∀ (α T : ℝ) (dF : Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ((Poincare.ClosedSmoothModel 3) →L[ℝ] (Poincare.ClosedSmoothModel 3))),
letI : NormedSpace ℝ (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ((Poincare.ClosedSmoothModel 3) →L[ℝ] (Poincare.ClosedSmoothModel 3) →L[ℝ] ℝ)) := Submodule.normedSpace (Poincare.ParabolicHolder.holderSubmodule (E := (Poincare.ClosedSmoothModel 3)) (F := ((Poincare.ClosedSmoothModel 3) →L[ℝ] (Poincare.ClosedSmoothModel 3) →L[ℝ] ℝ)) α T); ∃ P : (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ((Poincare.ClosedSmoothModel 3) →L[ℝ] (Poincare.ClosedSmoothModel 3) →L[ℝ] ℝ)) →L[ℝ] (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ((Poincare.ClosedSmoothModel 3) →L[ℝ] (Poincare.ClosedSmoothModel 3) →L[ℝ] ℝ)), ‖P‖ ≤ C * ‖dF‖ ^ 2 ∧
∀ B p (v w : (Poincare.ClosedSmoothModel 3)), P B p v w = B p (dF p v) (dF p w))
noncomputable section
abbrev E3 := Poincare.ClosedSmoothModel 3
abbrev Hess := E3 →L[ℝ] E3 →L[ℝ] ℝ
abbrev HY (α T : ℝ) := Poincare.ParabolicHolder.Y (E := E3) α T Hess
example (α T : ℝ) (B : HY α T) :
    (letI : NormedSpace ℝ (HY α T) := Submodule.normedSpace
       (Poincare.ParabolicHolder.holderSubmodule (E := E3) (F := Hess) α T)
     ‖B‖) = ‖B‖ := by rfl
example (α T : ℝ) (B : HY α T) (r : ℝ) :
    (letI : NormedSpace ℝ (HY α T) := Submodule.normedSpace
       (Poincare.ParabolicHolder.holderSubmodule (E := E3) (F := Hess) α T)
     r • B) = r • B := by rfl
