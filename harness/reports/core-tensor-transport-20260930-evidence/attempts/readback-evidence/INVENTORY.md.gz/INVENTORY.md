# Readback probe inventory

The source files below were copied without modification from /tmp. No checks were rerun during this archival step. Existing reviewed reports, contracts, and Lean sources were not edited.

Compiler stdout and stderr were returned by the original execution tools in the chat transcript. This reviewer did not save those outputs as separate log files, so no standalone compiler logs are present in this archive. Outcomes below are recorded from those original tool results; they are not new verification results.

| Retained source | Original outcome | Standalone compiler output |
| --- | --- | --- |
| poincare-graph-readback-overload-probe.lean | Failed: the optional square probe used unknown identifier pow. The CLM slot-order example emitted no error. | Not recorded as a file |
| poincare-graph-readback-overload-probe-v2.lean | Passed: exact compL/flip pointwise slot order and natural-number square. | Not recorded as a file |
| poincare-hessian-readback-canonical-instance.lean | Failed optional HSMul diagnostic: the revised literal type and unchanged-norm example elaborated, then an unannotated scalar-action expression reached a typeclass timeout. | Not recorded as a file |
| poincare-hessian-readback-canonical-instance-v2.lean | Passed: revised literal Hessian type and unchanged Y norm under its explicit canonical NormedSpace instance. | Not recorded as a file |
| poincare-tensor-weight-readback-types.lean | Failed: temporary header omitted rigid universe u; the earlier values literal also used unresolved scoped notation for nhds. | Not recorded as a file |
| poincare-tensor-weight-readback-types-v2.lean | Passed: weights and both revised values literal types, with rigid universe u and explicit nhds. | Not recorded as a file |
| poincare-tensor-value-compatibility-readback-types.lean | Passed: both compatibility literal types from the exact value definition, with rigid universe u. | Not recorded as a file |

SHA-256 values and original source paths are stored in probe-inventory.json.
