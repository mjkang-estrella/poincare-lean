from pathlib import Path
import json, subprocess, shutil
p=Path('/private/tmp/audit-payload-wiring-evidence')
if not (p/'after-completion_audit.json').exists():
 shutil.copyfile(p/'original-CURRENT_STATUS.md',Path('/private/tmp/poincare-workers/audit-payload-wiring/CURRENT_STATUS.md'))
 subprocess.run(['python3',str(p/'run.py'),'after','completion_audit'],check=True)
results=[]
for name in ['axiom_audit','root_import_audit','semantic_surface_audit','completion_audit']:
 cmd=['diff','-u',str(p/f'before-{name}.results'),str(p/f'after-{name}.results')]
 r=subprocess.run(cmd,capture_output=True,text=True)
 (p/f'{name}.results.diff').write_text(r.stdout)
 old=json.loads((p/f'before-{name}.json').read_text())
 new=json.loads((p/f'after-{name}.json').read_text())
 result={'audit':name,'diff_command':' '.join(cmd),'diff_exit_code':r.returncode,
         'old_exit_code':old['exit_code'],'new_exit_code':new['exit_code'],
         'result_lines':len((p/f'after-{name}.results').read_text().splitlines())}
 results.append(result)
 print(json.dumps(result),flush=True)
 if r.returncode: print(r.stdout[:5000])
(p/'comparison.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['diff_exit_code']==0 and r['old_exit_code']==r['new_exit_code'] for r in results)
