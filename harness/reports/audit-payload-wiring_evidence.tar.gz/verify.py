from pathlib import Path
import json, os, subprocess, time
root=Path('/private/tmp/poincare-workers/audit-payload-wiring')
evidence=Path('/private/tmp/audit-payload-wiring-evidence')
commands=[
 ('payload-equivalence',['python3','scripts/audit_payload_equivalence.py','--check']),
 ('script-tests',['python3','-m','unittest','discover','-s','scripts/tests']),
 ('guard-lean',['env','LEAN_NUM_THREADS=1','lake','env','lean','audit/PoincareAudit/Guard.lean']),
 ('surface-lean',['env','LEAN_NUM_THREADS=1','lake','env','lean','audit/PoincareAudit/Semantic/Surface.lean']),
 ('payload-build',['lake','build','PoincareAudit']),
 ('payload-rebuild',['lake','build','PoincareAudit']),
 ('diff-check',['git','diff','--check']),
]
for key,cmd in commands:
 if (evidence/f'{key}.json').exists():
  assert json.loads((evidence/f'{key}.json').read_text())['exit_code']==0
  continue
 start=time.monotonic()
 with (evidence/f'{key}.stdout').open('w') as out, (evidence/f'{key}.stderr').open('w') as err:
  p=subprocess.run(cmd,cwd=root,stdout=out,stderr=err)
 result={'command':' '.join(cmd),'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3)}
 (evidence/f'{key}.json').write_text(json.dumps(result)+'\n')
 print(json.dumps(result),flush=True)
 if p.returncode:
  print((evidence/f'{key}.stdout').read_text()[-5000:])
  print((evidence/f'{key}.stderr').read_text()[-5000:])
  raise SystemExit(p.returncode)
