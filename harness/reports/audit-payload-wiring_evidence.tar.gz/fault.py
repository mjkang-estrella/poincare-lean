"""Rebuild the cached audit after renaming a checked leaf in an independent copy."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, time
root=Path('/private/tmp/poincare-workers/audit-payload-wiring')
evidence=Path('/private/tmp/audit-payload-wiring-evidence')
scratch=Path('/private/tmp/audit-payload-wiring-fault')
scratch.mkdir(exist_ok=False)
archive=evidence/'source.tar'
with archive.open('wb') as out:
 subprocess.run(['git','archive','HEAD'],cwd=root,stdout=out,check=True)
subprocess.run(['tar','-xf',str(archive),'-C',str(scratch)],check=True)
archive.unlink()
# Overlay the current implementation. Poincare source remains the archived base.
for name in ['axiom','root_import','semantic_surface','completion']:
 shutil.copy2(root/f'scripts/{name}_audit.sh',scratch/f'scripts/{name}_audit.sh')
for name in ['lakefile.lean','audit/PoincareAudit/Guard.lean','audit/PoincareAudit/Semantic/Surface.lean']:
 shutil.copy2(root/name,scratch/name)
start=time.monotonic()
subprocess.run(['cp','-cR',str(root/'.lake'),str(scratch/'.lake')],check=True)
print('Cloned cache in',round(time.monotonic()-start,3),'seconds',flush=True)
env=os.environ.copy()
if not shutil.which('rg'): env['PATH']=str(scratch/'scripts/bin')+':'+env['PATH']
path=scratch/'Poincare/CanonicalBridges.lean'
original=path.read_bytes()
name='canonical_statement_payload_iff_aggregate_canonical_statement_payload_eq'
needle=f'theorem {name} :'.encode()
assert original.count(needle)==1
changed=original.replace(needle,f'theorem {name}_audit_fault :'.encode(),1)
try:
 path.write_bytes(changed)
 cmd=['sh','scripts/root_import_audit.sh']
 start=time.monotonic()
 with (evidence/'fault-root_import_audit.stdout').open('w') as out, (evidence/'fault-root_import_audit.stderr').open('w') as err:
  p=subprocess.run(cmd,cwd=scratch,env=env,stdout=out,stderr=err)
 result={'command':' '.join(cmd),'cwd':str(scratch),'renamed':name,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3)}
 text=(evidence/'fault-root_import_audit.stdout').read_text()
 result['fail_lines']=[line for line in text.splitlines() if line.startswith('FAIL:')]
 result['missing_identifier_in_output']=name in text
 (evidence/'fault.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result),flush=True)
 assert p.returncode==1
 assert 'FAIL: Poincare root does not expose canonical target contracts, canonical assembly bridges, and projection assembly' in text
 assert name in text
finally:
 path.write_bytes(original)
 assert path.read_bytes()==original
 print('Restored scratch CanonicalBridges.lean sha256',hashlib.sha256(original).hexdigest(),flush=True)
# Rebuild after restoration proves cache recovery, without rerunning shell-only checks.
cmd=['lake','build','PoincareAudit.Root.Contracts']
start=time.monotonic()
with (evidence/'fault-restored-build.stdout').open('w') as out, (evidence/'fault-restored-build.stderr').open('w') as err:
 p=subprocess.run(cmd,cwd=scratch,env=env,stdout=out,stderr=err)
result={'command':' '.join(cmd),'cwd':str(scratch),'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3)}
(evidence/'fault-restored-build.json').write_text(json.dumps(result)+'\n')
print(json.dumps(result),flush=True)
assert p.returncode==0
