import os, pathlib, subprocess, time, json, re, sys
root=pathlib.Path('/private/tmp/poincare-workers/audit-payload-wiring')
evidence=pathlib.Path('/private/tmp/audit-payload-wiring-evidence')
phase=sys.argv[1]
names=['axiom_audit','root_import_audit','semantic_surface_audit','completion_audit','write_status_summary']
if len(sys.argv)>2: names=sys.argv[2:]
env=os.environ.copy()
import shutil
if not shutil.which('rg'): env['PATH']=str(root/'scripts/bin')+':'+env['PATH']
for name in names:
 cmd=['sh','scripts/'+('old_' if phase=='before' and name!='write_status_summary' else '')+name+'.sh']
 start=time.monotonic()
 with (evidence/f'{phase}-{name}.stdout').open('w') as out, (evidence/f'{phase}-{name}.stderr').open('w') as err:
  p=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=err)
 result={'command':' '.join(cmd),'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3)}
 (evidence/f'{phase}-{name}.json').write_text(json.dumps(result)+'\n')
 lines=(evidence/f'{phase}-{name}.stdout').read_text().splitlines()
 selected=sorted(l for l in lines if re.match(r'^(?:PASS|FAIL|MISSING|STALE|INFO|[A-Z][A-Z _/-]*):|^==',l))
 (evidence/f'{phase}-{name}.results').write_text('\n'.join(selected)+'\n')
 if name=='write_status_summary': shutil.copy2(root/'CURRENT_STATUS.md', evidence/f'{phase}-CURRENT_STATUS.md')
 print(json.dumps(result),flush=True)
