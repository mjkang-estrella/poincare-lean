from pathlib import Path
import re
root=Path('/private/tmp/poincare-workers/audit-payload-wiring')
stage=Path('/private/tmp/audit-payload-wiring-evidence/staged')
stage.mkdir(exist_ok=True)
for name in ['axiom','root_import','semantic_surface','completion']:
 p=root/f'scripts/{name}_audit.sh'
 s=p.read_text()
 # Remove payloads, retaining the expected-to-fail reserved endpoint as a printf probe.
 def strip(m):
  if 'Poincare.poincare_conjecture : Poincare.PoincareConjectureStatement' in m[0] and len(m[0])<400:
   return "printf '%s\\n' 'import Poincare' '' \\\n  '#check (Poincare.poincare_conjecture : Poincare.PoincareConjectureStatement)' > \"$completion_check\"\n"
  return ''
 s=re.sub(r'^\s*cat (?:>|>>) [^\n]*<<\'EOF\'\n.*?^EOF\n',strip,s,flags=re.M|re.S)
 s=re.sub(r'^append_certificate_route_projection_(?:axiom|contract)_checks\(\) \{\n\}\n', '',s,flags=re.M)
 s=re.sub(r'^\s*append_certificate_route_projection_(?:axiom|contract)_checks "[^"\n]+"\n','\n',s,flags=re.M)
 if name=='axiom':
  a=s.index('if ! lake env lean "$check_file"')
  b=s.index('echo "AXIOMS:',a)
  s=s[:a]+'''if ! lake build PoincareAudit.Axiom.Footprint > "$output_file" 2>&1; then
  if rg -q "sorryAx|_sorry|proof_wanted|Poincare\\\\.poincare_conjecture([^A-Za-z0-9_]|$)" "$output_file"; then
    echo "FAIL: proof-placeholder or final-theorem dependency found in axiom footprint"
  else
    echo "FAIL: nonstandard axiom footprint detected"
  fi
  cat "$output_file"
  exit 1
fi

sh scripts/mathlib_proof_wanted_dependency_guard.sh

'''+s[b:]
  s=s.replace('normalized_file="$check_dir/normalized.txt"\n','')
 if name=='root_import':
  s=s.replace('if lake env lean "$root_check" >/dev/null 2>&1; then','if lake build PoincareAudit.Root.Contracts > "$root_check" 2>&1; then')
  s=s.replace('  lake env lean "$root_check" || true','  cat "$root_check"')
 if name=='semantic_surface':
  s=s.replace('if ! lake env lean "$check_file" >/dev/null 2>&1; then\n  lake env lean "$check_file" || true', 'if ! lake build PoincareAudit.Semantic.Surface PoincareAudit.Semantic.CertificateRoutes > "$check_file" 2>&1; then\n  cat "$check_file"')
  s=s.replace('"$0" |', 'audit/PoincareAudit/Semantic/*.lean |')
 if name=='completion':
  # Each legacy completion probe also included CertificateRoutes. Keep that dependency
  # at all three decision points, including the generated parser-visible file.
  s=s.replace('  if lake env lean "$explicit_check_file" >/dev/null 2>&1; then', '''  if lake build PoincareAudit.Completion.CertificateRoutes > "$audit_surface_dir/routes.log" 2>&1 &&
      lake env lean "$explicit_check_file" > "$audit_surface_dir/explicit.log" 2>&1; then''')
  s=s.replace('    lake env lean "$explicit_check_file" || true', '''    cat "$audit_surface_dir/routes.log"
    if [ -f "$audit_surface_dir/explicit.log" ]; then
      cat "$audit_surface_dir/explicit.log"
    fi''')
  # Include the cached route checks in the old explicit-token union.
  s=s.replace("  rg -P --no-filename -o '^[[:space:]]*#check (?:Poincare\\.)?[A-Za-z0-9_]+' \"$explicit_check_file\" |", "  rg -P --no-filename -o '#check (?:Poincare\\.)?[A-Za-z0-9_]+' \\\n    \"$explicit_check_file\" audit/PoincareAudit/Completion/CertificateRoutes.lean |")
  for var,mod in [('root_contract_check','RootContract'),('dependency_contract_check','DependencyContract')]:
   s=s.replace(f'if lake env lean "${var}" >/dev/null 2>&1; then',f'if lake build PoincareAudit.Completion.{mod} PoincareAudit.Completion.CertificateRoutes > "${var}" 2>&1; then')
   s=s.replace(f'  lake env lean "${var}" || true', f'  cat "${var}"')
  s=s.replace('    source_file=$1\n    output_file=$2', '    output_file=$1\n    shift')
  s=s.replace(' "$source_file" |', ' "$@" |')
  for old,group in [('semantic_surface','Semantic'),('completion','Completion'),('root_import','Root'),('axiom','Axiom')]:
   var={'semantic_surface':'semantic','root_import':'root'}.get(old,old)
   s=s.replace(f'collect_canonical_completion_certificate_routes scripts/{old}_audit.sh "$canonical_{var}_routes"',f'collect_canonical_completion_certificate_routes "$canonical_{var}_routes" audit/PoincareAudit/{group}/*.lean')
 (stage/p.name).write_text(s)
 print(p.name,len(p.read_text().splitlines()),'->',len(s.splitlines()))
