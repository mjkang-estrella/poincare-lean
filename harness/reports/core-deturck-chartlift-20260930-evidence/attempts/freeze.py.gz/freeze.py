import json,hashlib
from pathlib import Path
from harness.v2.runtime.validation import statement_contract_snapshot
r=Path.cwd();folder=r/'harness/v2/contracts/core-deturck-chartlift-20260930';folder.mkdir(exist_ok=True);d=r/'harness/v2/state/core-deturck-chartlift-20260930'
E='Poincare.DeTurckChartLift.E';G='Poincare.DeTurckChartLift.Bilin';I='Poincare.closedSmoothModelWithCorners 3';C='Poincare.DeTurckChartLift';chart=f'extChartAt ({I}) anchor';base=f'''∀ (M : Type u) [TopologicalSpace M] [ChartedSpace {E} M]
[IsManifold ({I}) ((⊤ : ENat) : WithTop ENat) M]''';t2=base.replace('[ChartedSpace','[T2Space M] [ChartedSpace')
support=t2+f'''
(anchor : M) (F : {E} → {G}), HasCompactSupport F → tsupport F ⊆ ({chart}).target →
IsCompact ({C}.sourceSupport anchor F) ∧ {C}.sourceSupport anchor F ⊆ ({chart}).source ∧
(∀ x : M, x ∉ {C}.sourceSupport anchor F → {C}.chartLift anchor F x = 0) ∧
HasCompactSupport ({C}.chartLift anchor F) ∧ tsupport ({C}.chartLift anchor F) ⊆ {C}.sourceSupport anchor F ∧
∀ x : M, x ∉ {C}.sourceSupport anchor F → Filter.Eventually (fun y => {C}.chartLift anchor F y = 0) (nhds x)'''
recovery=base+f'''
(anchor : M) (F : {E} → {G}) (z : {E}), z ∈ ({chart}).target →
_root_.CovariantDerivative.chartMetric (I := {I}) ({C}.chartLift anchor F) anchor z = F z'''
sym=base+f'''
(anchor : M) (F : {E} → {G}), (∀ z v w : {E}, F z v w = F z w v) →
∀ (x : M) (v w : TangentSpace ({I}) x), {C}.chartLift anchor F x v w = {C}.chartLift anchor F x w v'''
coords=base+f'''
(anchor : M) (F : {E} → {G}) (x : M), x ∈ ({chart}).source →
let e := trivializationAt {E} (TangentSpace ({I})) anchor
let eR := trivializationAt ℝ (fun _ : M => ℝ) anchor
((e.continuousLinearMap (RingHom.id ℝ) (e.continuousLinearMap (RingHom.id ℝ) eR))
 ⟨x, {C}.chartLift anchor F x⟩).2 = F (({chart}) x)'''
positivity=t2+f'''
(g0 : Poincare.ClosedSmoothRiemannianMetric 3 M) (anchor : M) (F : {E} → {G}),
ContDiff ℝ ((⊤ : ENat) : WithTop ENat) F → HasCompactSupport F → tsupport F ⊆ ({chart}).target →
∃ ε : ℝ, 0 < ε ∧ ∀ s : ℝ, |s| < ε → ∀ z ∈ ({chart}).target,
∀ v : {E}, v ≠ 0 → 0 < (_root_.CovariantDerivative.chartMetric (I := {I}) g0.inner anchor z + s • F z) v v'''
mods={'support':('DeTurckChartLiftSupport',[(C+'.compact_source_support',support)]),'coordinates':('DeTurckChartLiftCoordinates',[(C+'.chartMetric_chartLift',recovery),(C+'.chartLift_symmetric',sym),(C+'.chartLift_coordinates',coords)]),'positivity':('DeTurckCompactCoordinateVariation',[(C+'.exists_coordinate_variation_radius',positivity)])}
pins=['Poincare/Global/RiemannianContext.lean','Poincare/ChartTransport.lean','Poincare/Global/DeTurckChartLiftDefinitions.lean','Poincare/Global/SmoothInitialMetricDefinitions.lean','Poincare/Global/SmoothInitialMetricLocalPullback.lean','Poincare/Global/CompactCoefficientEllipticity.lean']
for slug,(mod,targets) in mods.items():
 c={'imports':['Poincare.Global.'+mod],'declarations':[{'name':name,'lean_type':t,'universes':['u']} for name,t in targets],'definition_files':[{'path':p,'sha256':hashlib.sha256((r/p).read_bytes()).hexdigest()} for p in pins],'author':'root-orchestrator'};c['review']={'reviewer':'deturck-chartlift-readback','method':'blind-readback','snapshot_sha256':statement_contract_snapshot(c),'verdict':'pending','report_path':str((folder/f'{slug}.readback.json').relative_to(r)),'report_sha256':'0'*64};(folder/f'{slug}.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
 s='import Poincare.Global.DeTurckChartLiftDefinitions\nimport Lean\nset_option maxHeartbeats 2000000\nset_option synthInstance.maxHeartbeats 200000\nset_option maxSynthPendingDepth 100\nuniverse u\nopen Lean Elab Command Term\n'
 for name,t in targets:
  s+=f'''run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(t,ensure_ascii=False)} with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: {name}"
'''
 (d/f'{slug}.preflight.lean').write_text(s)
(folder/'context.md').write_text('''# Actual chart tensor lift and positive coordinate variation

Every task helps UniversalHamiltonConvergenceStatement via actual metric variations and full linearized covariance, then true global L/R and physical Ricci-flow input production. Universal cores/final endpoint remain open. No supplied coordinate identity, positivity margin, metric/bound/flow/limit package may bypass the constructor.

The frozen data are actual localPullback(F(c x),mfderiv c x) in both tangent slots, chartLift zero off true c.source, and sourceSupport=c.symm''tsupportF. chartMetric has NO cutoff; blendedChartMetric separately does. Preserve topological tangent CLM composition: precomp + comp works without inventing tangent seminorms; bilinearComp would demand such a norm.

Coordinates: mfderiv_extChartAt_comp_mfderivWithin_extChartAt_symm gives forward-after-inverse id on true target. chartMetric_apply, branch source and right_inv yield whole target equality for arbitrary F. For nested Hom coordinates, TangentBundle.continuousLinearMapAt_trivializationAt (source converted with extChartAt_source) matches forward chart derivative, then continuousLinearMapAt_symmL cancels both slots. Prove this bridge, never use it as final input. Fiber symmetry follows F symmetry through actual pullback.

Support: actual compact K=c.symm''tsupportF via image_of_continuousOn and continuousOn_extChartAt_symm restricted to support. K subset source. OffK split source branch, c.left_inv shows F(c x)=0; rewrite image_eq_zero_of_notMem_tsupport BEFORE simp/precomp. This derives actual tsupport/chartLift compactness and neighborhood zero through closed K under T2. No bump/germ shortcut.

Positivity: derive actual g0 chart positivity and continuity on compact coefficient support, then uniform coercivity from CompactCoefficientEllipticity and F norm bound from compactness. Choose epsilon>0 BEFORE all real s and retain both signs |s|<epsilon. Off support F=0; use actual g0 positivity throughout true target. No symmetry premise needed for quadratic positivity alone; actual Riemannian metric constructor will additionally use symmetry and smooth global lift. Preserve original model Euclidean/operator norms; no tangent norm replacement.

After support/coordinates are accepted, global smoothness uses local Hom coordinates and hF.contMDiff composition with chart, then glues source with K-complement via actual zero section. Subsequent actual metric family remains unconstructed until smoothness/positivity/symmetry are combined. Neither field positivity nor lift recovery alone is a complete metric or covariance proof.

Name local instances uniquely per module. Preserve every failed source/log and finaldiff append-only, LEAN_NUM_THREADS=1. Workers not alone, own only allowedfile, never revert others/main/root/defs/contracts/merge/selfaccept/fullbuild/services. Local Codex helper is not registered Pi/Leanstral Job. Root independently reruns exact gates and reviews actual diff.
''')
