import Poincare.Global.DeTurckChartLiftDefinitions
import Lean
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
universe u
open Lean Elab Command Term
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M] [T2Space M] [ChartedSpace Poincare.DeTurckChartLift.E M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(anchor : M) (F : Poincare.DeTurckChartLift.E → Poincare.DeTurckChartLift.Bilin), HasCompactSupport F → tsupport F ⊆ (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor).target →\nIsCompact (Poincare.DeTurckChartLift.sourceSupport anchor F) ∧ Poincare.DeTurckChartLift.sourceSupport anchor F ⊆ (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor).source ∧\n(∀ x : M, x ∉ Poincare.DeTurckChartLift.sourceSupport anchor F → Poincare.DeTurckChartLift.chartLift anchor F x = 0) ∧\nHasCompactSupport (Poincare.DeTurckChartLift.chartLift anchor F) ∧ tsupport (Poincare.DeTurckChartLift.chartLift anchor F) ⊆ Poincare.DeTurckChartLift.sourceSupport anchor F ∧\n∀ x : M, x ∉ Poincare.DeTurckChartLift.sourceSupport anchor F → Filter.Eventually (fun y => Poincare.DeTurckChartLift.chartLift anchor F y = 0) (nhds x)" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: Poincare.DeTurckChartLift.compact_source_support"
