import Poincare.Global.DeTurckChartLiftDefinitions
noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
open Bundle FiberBundle Set
open scoped Manifold ContDiff Topology
universe u
namespace Poincare.DeTurckChartLift
variable {M : Type u} [TopologicalSpace M] [ChartedSpace E M] [IsManifold I ∞ M]
example (anchor : M) (F : E → Bilin) (x : M)
    (hx : x ∈ (extChartAt I anchor).source) :
    let e := trivializationAt E (TangentSpace I) anchor
    let eR := trivializationAt ℝ (fun _ : M => ℝ) anchor
    ((e.continuousLinearMap (RingHom.id ℝ)
      (e.continuousLinearMap (RingHom.id ℝ) eR))
      ⟨x, chartLift anchor F x⟩).2 = F (extChartAt I anchor x) := by
  dsimp only
  let e := trivializationAt E (TangentSpace I) anchor
  let eR := trivializationAt ℝ (fun _ : M => ℝ) anchor
  let eHom := e.continuousLinearMap (RingHom.id ℝ) eR
  have hx_chart : x ∈ (chartAt E anchor).source := by
    simpa only [extChartAt_source] using hx
  have hxBase : x ∈ e.baseSet := by
    simpa only [e, TangentBundle.trivializationAt_baseSet] using hx_chart
  have hxHom : x ∈ eHom.baseSet := by simpa [eHom, eR] using hxBase
  have hcancel (v : E) :
      (mfderiv I 𝓘(ℝ, E) (extChartAt I anchor) x) (e.symmL ℝ x v) = v := by
    rw [← TangentBundle.continuousLinearMapAt_trivializationAt hx_chart]
    exact e.continuousLinearMapAt_symmL hxBase v
  ext a b
  simp only [Trivialization.continuousLinearMap_apply, ContinuousLinearMap.comp_apply]
  rw [Trivialization.continuousLinearMapAt_apply_of_mem ℝ eHom hxHom]
  simp only [eHom, Trivialization.continuousLinearMap_apply, ContinuousLinearMap.comp_apply]
  change (Bundle.Trivial.trivialization M ℝ).continuousLinearMapAt ℝ x
    (chartLift anchor F x (e.symmL ℝ x a) (e.symmL ℝ x b)) =
      F (extChartAt I anchor x) a b
  rw [Bundle.Trivial.continuousLinearMapAt_trivialization]
  simp only [ContinuousLinearMap.id_apply, chartLift, if_pos hx, localPullback,
    ContinuousLinearMap.comp_apply, ContinuousLinearMap.precomp_apply]
  rw [hcancel a, hcancel b]
end Poincare.DeTurckChartLift
