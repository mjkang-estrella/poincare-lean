import Poincare.Global.DeTurckMetricVariation
import Poincare.Global.SmoothInitialMetricExistence
noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
open Set Filter
open scoped Manifold ContDiff Topology
universe u
namespace Poincare.ChartLiftApplication
open DeTurckPrincipalSecondJet DeTurckJetLinearization DeTurckJetRealization
local instance metricApplicationBilinBoundedSMul : IsBoundedSMul ℝ Bilin :=
  .of_norm_smul_le (fun c A => ContinuousLinearMap.opNorm_smul_le c A)
local instance metricApplicationJet1Group : NormedAddCommGroup Jet1 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance metricApplicationJet1Space : NormedSpace ℝ Jet1 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
local instance metricApplicationJet2Group : NormedAddCommGroup Jet2 :=
  ContinuousLinearMap.toNormedAddCommGroup
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1) (σ₁₂ := RingHom.id ℝ)
local instance metricApplicationJet2Space : NormedSpace ℝ Jet2 :=
  ContinuousLinearMap.toNormedSpace
    (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Jet1)
    (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)


example : ∀ (M : Type u) [TopologicalSpace M] [T2Space M] [CompactSpace M]
[ChartedSpace E M] [IsManifold (closedSmoothModelWithCorners 3) ∞ M],
∃ g0 : ClosedSmoothRiemannianMetric 3 M,
∀ (anchor : M) (h : E → Bilin) (z : E),
z ∈ (extChartAt (closedSmoothModelWithCorners 3) anchor).target →
ContDiffAt ℝ (2 : WithTop ENat) h z →
(∀ᶠ y in nhds z, ∀ v w : E, h y v w = h y w v) →
∃ (F : E → Bilin), ContDiff ℝ ∞ F ∧ HasCompactSupport F ∧
tsupport F ⊆ (extChartAt (closedSmoothModelWithCorners 3) anchor).target ∧
(∀ y v w : E, F y v w = F y w v) ∧
F z = h z ∧ fderiv ℝ F z = fderiv ℝ h z ∧
fderiv ℝ (fderiv ℝ F) z = fderiv ℝ (fderiv ℝ h) z ∧
∃ ε : ℝ, 0 < ε ∧ ∃ gt : ℝ → ClosedSmoothRiemannianMetric 3 M,
gt 0 = g0 ∧
(∀ s : ℝ, |s| < ε → ∀ x : M,
 (gt s).inner x = g0.inner x + s • DeTurckChartLift.chartLift anchor F x) ∧
∀ s : ℝ, |s| < ε → ∀ y ∈ (extChartAt (closedSmoothModelWithCorners 3) anchor).target,
_root_.CovariantDerivative.chartMetric (I := closedSmoothModelWithCorners 3) (gt s).inner anchor y =
_root_.CovariantDerivative.chartMetric (I := closedSmoothModelWithCorners 3) g0.inner anchor y + s • F y := by
  intro M _ _ _ _ _
  obtain ⟨g0⟩ := SmoothInitialMetricExistence.exists_initial_metric (M := M)
  refine ⟨g0, ?_⟩
  intro anchor h z hz hc hs
  obtain ⟨η, _hη, _hcη, _hηU, _hone, hF, hcF, hFU, hsym, hzero, hfirst, hsecond⟩ :=
    exists_compact_symmetric_realization h z
      (extChartAt (closedSmoothModelWithCorners 3) anchor).target
      (isOpen_extChartAt_target anchor) hz hc hs
  let F := realized η h z
  refine ⟨F, hF, hcF, hFU, hsym, hzero, hfirst, hsecond, ?_⟩
  exact DeTurckChartLift.exists_actual_metric_variation M g0 anchor F hF hcF hFU hsym
end Poincare.ChartLiftApplication
