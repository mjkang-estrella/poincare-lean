import Poincare.Global.DeTurckChartLiftDefinitions
import Lean
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
universe u
open Lean Elab Command Term
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M] [T2Space M]\n[ChartedSpace Poincare.DeTurckChartLift.E M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(g0 : Poincare.ClosedSmoothRiemannianMetric 3 M) (anchor : M)\n(F : Poincare.DeTurckChartLift.E → Poincare.DeTurckChartLift.Bilin),\nContDiff ℝ ((⊤ : ENat) : WithTop ENat) F → HasCompactSupport F →\ntsupport F ⊆ (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor).target →\n(∀ z v w : Poincare.DeTurckChartLift.E, F z v w = F z w v) →\n∃ ε : ℝ, 0 < ε ∧ ∃ gt : ℝ → Poincare.ClosedSmoothRiemannianMetric 3 M,\ngt 0 = g0 ∧\n(∀ s : ℝ, |s| < ε → ∀ x : M,\n (gt s).inner x = g0.inner x + s • Poincare.DeTurckChartLift.chartLift anchor F x) ∧\n∀ s : ℝ, |s| < ε → ∀ z ∈ (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor).target,\n_root_.CovariantDerivative.chartMetric (I := Poincare.closedSmoothModelWithCorners 3) (gt s).inner anchor z =\n_root_.CovariantDerivative.chartMetric (I := Poincare.closedSmoothModelWithCorners 3) g0.inner anchor z + s • F z" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: exists_actual_metric_variation"
