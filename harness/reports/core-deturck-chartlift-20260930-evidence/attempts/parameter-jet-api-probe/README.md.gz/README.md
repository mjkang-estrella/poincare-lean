# Verified parameter two-jet API prototype

This directory preserves the exact generic Lean source passed through standard input on 2026-09-30. It is a verified standalone prototype, not an accepted repository theorem or proof of metric-family existence.

The original invocation was `LEAN_NUM_THREADS=1 lake env lean --stdin`, with the complete input in `source.lean` and the original shell command in `command.txt`. It returned exit code 0 with empty captured combined output. The tool supplied combined output rather than separate stream captures. `stdout.log` and `stderr.log` preserve the empty observed result; `verification.json` records this stream limitation explicitly.

The original tool-call timestamps were 2026-09-30T13:12:04.390Z to 2026-09-30T13:12:08.631Z. The command reported 4.068467333 seconds. The verification HEAD was `40e60c86ccf417c5645c5d6dc1f5d7ae5aaf4e1d`, corroborated by the initial checkout observation and retained worktree HEAD reflog: the following HEAD update occurred at 2026-09-30T13:12:35Z, after the passed invocation.

`verification-tool-events.json` preserves the successful call and returned output from the original session. No compiler rerun was performed to save these artifacts. The intended next proof step is to specialize this generic theorem to the constructed actual Riemannian metric family and genuine open chart target, then consume the existing nonlinear jet evolution derivative.
