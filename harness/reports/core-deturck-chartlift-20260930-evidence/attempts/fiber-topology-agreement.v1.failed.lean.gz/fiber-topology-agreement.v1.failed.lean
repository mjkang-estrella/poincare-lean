import Poincare.Global.DeTurckMetricVariation
open scoped Manifold ContDiff
universe u
namespace Poincare.FiberTopologyAgreement
variable {M : Type u} [TopologicalSpace M]
 [ChartedSpace (ClosedSmoothModel 3) M]
 [IsManifold (closedSmoothModelWithCorners 3) ∞ M]
example (x : M) :
 (inferInstanceAs (NormedAddCommGroup (ClosedSmoothModel 3))).toTopologicalSpace =
 (inferInstanceAs (TopologicalSpace (TangentSpace (closedSmoothModelWithCorners 3) x))) := rfl
example (x : M) :
 (inferInstanceAs (NormedSpace ℝ (ClosedSmoothModel 3))).toModule =
 (inferInstanceAs (Module ℝ (TangentSpace (closedSmoothModelWithCorners 3) x))) := rfl
example (x : M) :
 (ContinuousLinearMap.topologicalSpace : TopologicalSpace
   (TangentSpace (closedSmoothModelWithCorners 3) x →L[ℝ] ℝ)) =
 (inferInstanceAs (TopologicalSpace (TangentSpace (closedSmoothModelWithCorners 3) x →L[ℝ] ℝ))) := rfl
end Poincare.FiberTopologyAgreement
