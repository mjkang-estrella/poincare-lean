import Poincare.Global.DeTurckChartLiftDefinitions
import Lean
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
universe u
open Lean Elab Command Term
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M] [T2Space M] [ChartedSpace Poincare.DeTurckChartLift.E M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(g0 : Poincare.ClosedSmoothRiemannianMetric 3 M) (anchor : M) (F : Poincare.DeTurckChartLift.E → Poincare.DeTurckChartLift.Bilin),\nContDiff ℝ ((⊤ : ENat) : WithTop ENat) F → HasCompactSupport F → tsupport F ⊆ (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor).target →\n∃ ε : ℝ, 0 < ε ∧ ∀ s : ℝ, |s| < ε → ∀ z ∈ (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor).target,\n∀ v : Poincare.DeTurckChartLift.E, v ≠ 0 → 0 < (_root_.CovariantDerivative.chartMetric (I := Poincare.closedSmoothModelWithCorners 3) g0.inner anchor z + s • F z) v v" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: Poincare.DeTurckChartLift.exists_coordinate_variation_radius"
