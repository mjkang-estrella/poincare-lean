lake env lean /dev/stdin
