LEAN_NUM_THREADS=1 lake env lean /dev/stdin
