import Poincare.Global.DeTurckChartLiftCoordinates
import Poincare.Global.DeTurckChartLiftSupport
open Bundle FiberBundle Set
open scoped Manifold ContDiff Topology
#check contMDiff_of_contMDiffOn_union_of_isOpen
#check Bundle.contMDiff_zeroSection
#check Bundle.Trivialization.contMDiffOn_section_baseSet_iff
#check contMDiffOn_extChartAt
#check ContMDiff.comp_contMDiffOn
#check ContDiff.contMDiff
#check Bundle.zeroSection
#check ContMDiffOn.congr
#print Bundle.contMDiff_zeroSection
