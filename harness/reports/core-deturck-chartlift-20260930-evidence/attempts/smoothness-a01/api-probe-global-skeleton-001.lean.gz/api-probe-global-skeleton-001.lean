import Poincare.Global.DeTurckChartLiftCoordinates
import Poincare.Global.DeTurckChartLiftSupport
noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
open Bundle FiberBundle Set
open scoped Manifold ContDiff Topology
universe u
namespace Poincare.DeTurckChartLift
example (M : Type u) [TopologicalSpace M] [T2Space M] [ChartedSpace E M]
    [IsManifold I ∞ M] (anchor : M) (F : E → Bilin)
    (hF : ContDiff ℝ ∞ F) (hcompact : HasCompactSupport F)
    (htarget : tsupport F ⊆ (extChartAt I anchor).target) :
    ContMDiff I (I.prod 𝓘(ℝ, Bilin)) ∞
      (fun x : M => TotalSpace.mk' Bilin x (chartLift anchor F x)) := by
  classical
  obtain ⟨hK, hsource, hzero, -, -, -⟩ :=
    compact_source_support M anchor F hcompact htarget
  let e := trivializationAt E (TangentSpace I) anchor
  let eR := trivializationAt ℝ (fun _ : M => ℝ) anchor
  let eBil := e.continuousLinearMap (RingHom.id ℝ)
    (e.continuousLinearMap (RingHom.id ℝ) eR)
  have hbase : eBil.baseSet = (extChartAt I anchor).source := by
    simp [eBil, eR, e, TangentBundle.trivializationAt_baseSet, extChartAt_source]
  have hsourceSmooth : ContMDiffOn I (I.prod 𝓘(ℝ, Bilin)) ∞
      (fun x : M => TotalSpace.mk' Bilin x (chartLift anchor F x))
      (extChartAt I anchor).source := by
    rw [← hbase, eBil.contMDiffOn_section_baseSet_iff]
    have hcoords : ContMDiffOn I 𝓘(ℝ, Bilin) ∞
        (fun x : M => F (extChartAt I anchor x)) eBil.baseSet := by
      simpa only [Function.comp_def, hbase, extChartAt_source] using
        hF.contMDiff.comp_contMDiffOn
          (contMDiffOn_extChartAt (I := I) (x := anchor) (n := ∞))
    refine hcoords.congr ?_
    intro x hx
    exact chartLift_coordinates anchor F x (hbase ▸ hx)
  have hcomplementSmooth : ContMDiffOn I (I.prod 𝓘(ℝ, Bilin)) ∞
      (fun x : M => TotalSpace.mk' Bilin x (chartLift anchor F x))
      (sourceSupport anchor F)ᶜ := by
    apply ((Bundle.contMDiff_zeroSection (IB := I) (n := ∞) (F := Bilin) ℝ
      (fun x : M => TangentSpace I x →L[ℝ] TangentSpace I x →L[ℝ] ℝ)).contMDiffOn).congr
    intro x hx
    simp only [hzero x hx, Bundle.zeroSection]
  apply contMDiff_of_contMDiffOn_union_of_isOpen hsourceSmooth hcomplementSmooth
  · exact Set.compl_subset_iff_union.mp <| Set.compl_subset_compl.mpr hsource
  · exact (extChartAt I anchor).open_source
  · exact hK.isClosed.isOpen_compl
end Poincare.DeTurckChartLift
