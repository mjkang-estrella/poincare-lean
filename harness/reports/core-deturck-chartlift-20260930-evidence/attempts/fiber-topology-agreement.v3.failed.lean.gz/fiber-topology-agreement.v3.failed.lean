import Poincare.Global.DeTurckMetricVariation
open scoped Manifold ContDiff
universe u
namespace Poincare.FiberTopologyAgreement
variable {M : Type u} [TopologicalSpace M]
 [ChartedSpace (ClosedSmoothModel 3) M]
 [IsManifold (closedSmoothModelWithCorners 3) ∞ M]
example (x : M) :
 (letI : NormedAddCommGroup (TangentSpace (closedSmoothModelWithCorners 3) x) :=
    inferInstanceAs (NormedAddCommGroup (ClosedSmoothModel 3))
  (inferInstance : TopologicalSpace (TangentSpace (closedSmoothModelWithCorners 3) x))) =
 (inferInstance : TopologicalSpace (TangentSpace (closedSmoothModelWithCorners 3) x)) := rfl
example (x : M) :
 ((inferInstance : NormedSpace ℝ (ClosedSmoothModel 3)).toModule :
  Module ℝ (TangentSpace (closedSmoothModelWithCorners 3) x)) =
 (inferInstance : Module ℝ (TangentSpace (closedSmoothModelWithCorners 3) x)) := rfl
example (x : M) :
 (ContinuousLinearMap.topologicalSpace : TopologicalSpace
  (TangentSpace (closedSmoothModelWithCorners 3) x →L[ℝ] ℝ)) =
 (inferInstance : TopologicalSpace (TangentSpace (closedSmoothModelWithCorners 3) x →L[ℝ] ℝ)) := rfl
end Poincare.FiberTopologyAgreement
