import Poincare.Global.DeTurckChartLiftDefinitions
import Lean
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
universe u
open Lean Elab Command Term
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M] [T2Space M]\n[ChartedSpace Poincare.DeTurckChartLift.E M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(anchor : M) (F : Poincare.DeTurckChartLift.E → Poincare.DeTurckChartLift.Bilin),\nContDiff ℝ ((⊤ : ENat) : WithTop ENat) F → HasCompactSupport F →\ntsupport F ⊆ (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor).target →\nContMDiff (Poincare.closedSmoothModelWithCorners 3)\n ((Poincare.closedSmoothModelWithCorners 3).prod (modelWithCornersSelf ℝ Poincare.DeTurckChartLift.Bilin))\n ((⊤ : ENat) : WithTop ENat)\n (fun x : M => Bundle.TotalSpace.mk' Poincare.DeTurckChartLift.Bilin x (Poincare.DeTurckChartLift.chartLift anchor F x))" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: chartLift_contMDiff"
