import Poincare.Global.DeTurckChartLiftDefinitions
import Lean
set_option maxHeartbeats 2000000
set_option synthInstance.maxHeartbeats 200000
set_option maxSynthPendingDepth 100
universe u
open Lean Elab Command Term
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M] [ChartedSpace Poincare.DeTurckChartLift.E M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(anchor : M) (F : Poincare.DeTurckChartLift.E → Poincare.DeTurckChartLift.Bilin) (z : Poincare.DeTurckChartLift.E), z ∈ (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor).target →\n_root_.CovariantDerivative.chartMetric (I := Poincare.closedSmoothModelWithCorners 3) (Poincare.DeTurckChartLift.chartLift anchor F) anchor z = F z" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: Poincare.DeTurckChartLift.chartMetric_chartLift"
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M] [ChartedSpace Poincare.DeTurckChartLift.E M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(anchor : M) (F : Poincare.DeTurckChartLift.E → Poincare.DeTurckChartLift.Bilin), (∀ z v w : Poincare.DeTurckChartLift.E, F z v w = F z w v) →\n∀ (x : M) (v w : TangentSpace (Poincare.closedSmoothModelWithCorners 3) x), Poincare.DeTurckChartLift.chartLift anchor F x v w = Poincare.DeTurckChartLift.chartLift anchor F x w v" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: Poincare.DeTurckChartLift.chartLift_symmetric"
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M] [ChartedSpace Poincare.DeTurckChartLift.E M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(anchor : M) (F : Poincare.DeTurckChartLift.E → Poincare.DeTurckChartLift.Bilin) (x : M), x ∈ (extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor).source →\nlet e := trivializationAt Poincare.DeTurckChartLift.E (TangentSpace (Poincare.closedSmoothModelWithCorners 3)) anchor\nlet eR := trivializationAt ℝ (fun _ : M => ℝ) anchor\n((e.continuousLinearMap (RingHom.id ℝ) (e.continuousLinearMap (RingHom.id ℝ) eR))\n ⟨x, Poincare.DeTurckChartLift.chartLift anchor F x⟩).2 = F ((extChartAt (Poincare.closedSmoothModelWithCorners 3) anchor) x)" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar || expected.hasSorry then throwError "unresolved or recovered expression"
  logInfo "PREFLIGHT_OK: Poincare.DeTurckChartLift.chartLift_coordinates"
