exec(open('/tmp/poincare-global-freeze-20260930.py').read().split('for slug,mod,name,t in')[0])
source=(root/'Poincare/Global/MetricAdaptedLocalParametrix.lean').read_text();signature=source.split('theorem exists_metric_adapted_local_parametrix :\n',1)[1].split(' := by',1)[0];prefix=signature.split(' ∃ Cψ CP τ : ℝ',1)[0]
local=signature.split('   ∀ i,',1)[1].replace('(P i f)','(S i f)').replace('‖P i f‖','‖S i f‖')
gate=f'''∀ i j,
 ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (θ i j) ∧ HasCompactSupport (θ i j) ∧
 (∀ z, θ i j z ∈ Set.Icc 0 1) ∧
 tsupport (θ i j) ⊆ (({FA}.chart A i).symm.trans ({FA}.chart A j)).source ∧
 (∀ z ∈ ({FA}.chart A i) '' (tsupport (A.partition i) ∩ ({FA}.chart A j).symm '' tsupport (ξ j)),
  Filter.Eventually (fun y => θ i j y = 1) (nhds z)) ∧
 ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (F i j) ∧ HasCompactSupport (F i j) ∧
 (∀ z ∈ tsupport (θ i j), Filter.Eventually (fun y => F i j y = {FA}.change A i j y) (nhds z)) ∧
 ∃ L : NNReal, LipschitzWith L (F i j)'''
raw=f'''∀ w p, (B i j c d w).u p = ∑ a : Fin 3, ∑ b : Fin 3,
 Poincare.BufferedTensorGraphTransport.weight A i (θ i j) (ξ j) (F i j) a b c d p.2 *
 (w (a,b)).u (p.1,F i j p.2)'''
bv=chartvalue.replace('∀ i j c d (w', '∀ (w',1)
bs=supported.replace('∀ i j c d (w','∀ (w',1)
vv=valueformula.replace(f'(({GA}.ambient A α T S B f) (i,c,d)).u', '(Pglobal f).val (i,c,d) |PLACEHOLDER|')
# Write explicit output formula to avoid precedence ambiguity in chained field projection.
vv=f'''∀ (f : {YM}) i c d t (x : M), x ∈ ({FA}.chart A i).source →
((Pglobal f).val (i,c,d)).u (t,{FA}.chart A i x) =
{V} A ξ (fun j a b z => (S j (f.val (j,a,b))).u (t,z)) i c d x'''
t=prefix+f''' ∃ θ : Fin A.cover.chartCount → Fin A.cover.chartCount → {E} → ℝ,
 ∃ F : Fin A.cover.chartCount → Fin A.cover.chartCount → {E} → {E},
 ({gate}) ∧
 ∃ Cψ CP Cglobal τ : ℝ,
 ∃ CB : Fin A.cover.chartCount → Fin A.cover.chartCount → Fin 3 → Fin 3 → ℝ,
 0 ≤ Cψ ∧ 0 ≤ CP ∧ 0 < τ ∧ τ ≤ 1 ∧ (∀ i j c d, 0 ≤ CB i j c d) ∧
 Cglobal = CP * (∑ i : Fin A.cover.chartCount, ∑ j : Fin A.cover.chartCount,
   ∑ c : Fin 3, ∑ d : Fin 3, CB i j c d) ∧
 ∀ T ∈ Set.Ioc 0 τ,
 ∃ S : Fin A.cover.chartCount → ({Y}) →L[ℝ] ({G}),
 ∃ R : Fin A.cover.chartCount → ({Y}) →L[ℝ] ({Y}),
 ∃ B : {GA}.Transports A α T,
 ∃ Pglobal : ({YM}) →L[ℝ] ({FA}.X_M A α T),
 (∀ i,{local}) ∧
 (∀ i j c d, ‖B i j c d‖ ≤ CB i j c d ∧ ({raw}) ∧ ({bs}) ∧ ({bv})) ∧
 ‖Pglobal‖ ≤ Cglobal ∧
 (∀ (f : {YM}) i c d, (Pglobal f).val (i,c,d) =
   ∑ j : Fin A.cover.chartCount, B i j c d (fun ab => S j (f.val (j,ab.1,ab.2)))) ∧
 ({vv})'''
pins+=['Poincare/Global/BufferedTensorGraphTransportDefinitions.lean','Poincare/Global/MetricAdaptedLocalParametrix.lean']
c={'imports':['Poincare.Global.MetricAdaptedGlobalParametrix'],'declarations':[{'name':'Poincare.MetricAdaptedGlobalParametrix.exists_metric_adapted_global_parametrix','lean_type':t,'universes':['u']}],'definition_files':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in pins],'author':'root-orchestrator'}
c['review']={'reviewer':'global-parametrix-readback','method':'blind-readback','snapshot_sha256':statement_contract_snapshot(c),'verdict':'pending','report_path':'harness/v2/contracts/core-global-parametrix-20260930/producer.readback.json','report_sha256':'0'*64}
(folder/'producer.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
pre='import Poincare.Global.GlobalParametrixAssemblyDefinitions\nimport Poincare.Global.FiniteAtlasBufferedTensorValueDefinitions\nimport Poincare.Global.MetricAdaptedLocalParametrix\nimport Poincare.Global.BufferedTensorGraphTransportDefinitions\nimport Lean\nopen Lean Elab Command Term\nuniverse u\n'
pre+=f'run_cmd liftTermElabM do\n  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(t,ensure_ascii=False)} with\n    | .ok s => pure s\n    | .error e => throwError e\n  let expected ← Term.elabType stx\n  Term.synthesizeSyntheticMVarsNoPostponing\n  let expected ← instantiateMVars expected\n  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"\n  logInfo "PREFLIGHT_OK: exists_metric_adapted_global_parametrix"\n'
(state/'producer.preflight.lean').write_text(pre)
