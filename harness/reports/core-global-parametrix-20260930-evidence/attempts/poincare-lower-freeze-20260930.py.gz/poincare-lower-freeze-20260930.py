import json,hashlib
from pathlib import Path
from harness.v2.runtime.validation import statement_contract_snapshot
root=Path.cwd();folder=root/'harness/v2/contracts/core-global-parametrix-20260930';state=root/'harness/v2/state/core-global-parametrix-20260930'
E='Poincare.DeTurckPrincipalSecondJet.E';G='Poincare.DeTurckPrincipalSecondJet.Bilin';J='Poincare.DeTurckPrincipalSecondJet.Jet1'
t=f'''∀ (B : {E} →L[ℝ] {E} →L[ℝ] {E})
(DB : {E} →L[ℝ] {E} →L[ℝ] {E} →L[ℝ] {E})
(G0 : {G}) (J0 : {J}), G0.IsInvertible →
ContDiffAt ℝ ((⊤ : ENat) : WithTop ENat)
 (fun p : {G} × {J} => Poincare.DeTurckPrincipalIdentity.lowerTerm B DB p.1 p.2)
 (G0,J0)'''
pins=['Poincare/Global/RiemannianContext.lean','Poincare/Global/DeTurckPrincipalSecondJet.lean','Poincare/Global/DeTurckPrincipalIdentity.lean']
c={'imports':['Poincare.Global.DeTurckLowerJetSmoothness'],'declarations':[{'name':'Poincare.DeTurckLowerJetSmoothness.contDiffAt_lowerTerm','lean_type':t,'universes':[]}],'definition_files':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in pins],'author':'root-orchestrator'};c['review']={'reviewer':'global-parametrix-readback','method':'blind-readback','snapshot_sha256':statement_contract_snapshot(c),'verdict':'pending','report_path':'harness/v2/contracts/core-global-parametrix-20260930/lower-smooth.readback.json','report_sha256':'0'*64};(folder/'lower-smooth.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
pre='import Poincare.Global.DeTurckPrincipalIdentity\nimport Lean\nopen Lean Elab Command Term\n'
pre+=f'run_cmd liftTermElabM do\n  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(t,ensure_ascii=False)} with\n    | .ok s => pure s\n    | .error e => throwError e\n  let expected ← Term.elabType stx\n  Term.synthesizeSyntheticMVarsNoPostponing\n  let expected ← instantiateMVars expected\n  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"\n  logInfo "PREFLIGHT_OK: contDiffAt_lowerTerm"\n';(state/'lower-smooth.preflight.lean').write_text(pre)
(folder/'lower-smooth-context.md').write_text('''# Genuine DeTurck lower coefficient prerequisite

Core assumption helped: UniversalHamiltonConvergenceStatement via actual general Ricci-flow construction. Subsequent consumer: construct the real finite-jet differential DQ(g0), then actual L=dt-DQ(g0):X_M ->L Y_M with full lower coefficients and its signed global residual/contraction. This task is independent of the global P assembly and closes the first explicit lower-coefficient differentiability obstacle.

Use the ACTUAL DeTurckPrincipalIdentity.lowerTerm B DB G J, not the existential lower exported by principalIdentity and not survey/Appendix probes or an assumed linear CLM package. The explicit nonlinear expression is inverseEntries(G):H + lowerTerm(B,DB,G,J). Differentiating the principal part must later retain Da(G0)[h]:H0 in the zero-order term. Current task proves genuine smoothness at invertible G0 in the metric/first-jet product, with B/DB fixed; it does not claim the full differential, covariance or spatial coefficient regularity.

Actual g0 invertibility in chart cutoff-one germs is proved by chartMetric_isInvertible_of_cutoff. Background Christoffel smoothness is already proved. ContinuousLinearMap.IsInvertible.contDiffAt_map_inverse supplies smooth inversion of the actual bilinear metric as E->L Cov. No symmetry, positive-curvature, metric seed, approximate coefficient, flow or operator assumption is permitted beyond the exact frozen hypothesis. No new norm or NormedSpace instance should be introduced.

The remaining explicit field/operator algebra can use existing CLM comp/flip/apply/sum APIs and finite-dimensional coordinate/evaluation criteria for the actual continuousBilinear output. Preserve the bilinear lowerTerm, not merely its scalar values unless they are used to prove the same output smoothness.

Both universal cores remain open. Local helpers are not registered Pi/Leanstral Jobs. Preserve every failed compiler/source attempt and final diff. Workers do not full-build, self-accept, merge or alter services.
''')
