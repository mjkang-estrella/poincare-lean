import Poincare.Global.TopologicalCompletionBridge
import Poincare.Global.HamiltonFrontStatements
import Poincare.Global.HamiltonPoincareReduction
import Lean
#print Poincare.ExistsSmoothabilitySmoothManifoldStatement
#print Poincare.UniversalHamiltonConvergenceStatement
#print Poincare.UniversalHamiltonFrontInputsStatement
#check Poincare.poincareConjectureStatement_of_exists_smoothability_of_universalHamiltonConvergence
open Lean Elab Command in
run_cmd do
  if (← getEnv).contains `Poincare.poincare_conjecture then
    throwError "Reserved theorem unexpectedly present; independently probe its exact type"
  logInfo "RESERVED_FINAL_THEOREM_ABSENT"
