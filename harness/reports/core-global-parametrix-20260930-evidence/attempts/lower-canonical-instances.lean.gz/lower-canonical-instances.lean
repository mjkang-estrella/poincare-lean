import Poincare.Global.DeTurckPrincipalIdentity
open Poincare.DeTurckPrincipalSecondJet
noncomputable section
set_option backward.isDefEq.respectTransparency false
local instance jetGroup : NormedAddCommGroup Jet1 := ContinuousLinearMap.toNormedAddCommGroup
local instance jetSpace : NormedSpace ℝ Jet1 := ContinuousLinearMap.toNormedSpace
#synth NormedAddCommGroup (Bilin × Jet1)
#synth NormedSpace ℝ (Bilin × Jet1)
example (J : Jet1) : ‖J‖ = ContinuousLinearMap.opNorm J := rfl
#check ContinuousLinearMap.toNormedAddCommGroup
#check ContinuousLinearMap.toNormedSpace
