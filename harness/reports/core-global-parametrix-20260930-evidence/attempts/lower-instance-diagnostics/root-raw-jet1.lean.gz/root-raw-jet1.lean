import Poincare.Global.DeTurckPrincipalIdentity
open Poincare.DeTurckPrincipalSecondJet
set_option pp.all true in
#print Poincare.DeTurckPrincipalSecondJet.Jet1
abbrev FreshJet1 := E →L[ℝ] Bilin
set_option pp.all true in
#print FreshJet1
example : Jet1 = FreshJet1 := rfl
#synth NormedAddCommGroup FreshJet1
#synth NormedSpace ℝ FreshJet1
set_option pp.all true in
#check fun (J : Jet1) => J.toLinearMap
