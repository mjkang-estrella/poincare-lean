import Poincare.Global.DeTurckPrincipalIdentity
open Poincare.DeTurckPrincipalSecondJet
set_option maxRecDepth 10000
set_option synthInstance.maxHeartbeats 200000
set_option backward.isDefEq.respectTransparency false
#synth NormedAddCommGroup Jet1
#synth NormedSpace ℝ Jet1
example : NormedAddCommGroup Jet1 := ContinuousLinearMap.toNormedAddCommGroup
example (J : Jet1) : ℝ := ContinuousLinearMap.opNorm J
