import Poincare.Global.DeTurckPrincipalIdentity
open Poincare.DeTurckPrincipalSecondJet
set_option pp.all true in
#print Poincare.DeTurckPrincipalSecondJet.Jet1
set_option pp.explicit true in
#print Poincare.DeTurckPrincipalSecondJet.Bilin
#synth NormedAddCommGroup (E →L[ℝ] Bilin)
example : Jet1 = (E →L[ℝ] Bilin) := rfl
example (J : Jet1) : E →L[ℝ] Bilin := J
example : NormedAddCommGroup Jet1 := by
  change NormedAddCommGroup (E →L[ℝ] Bilin)
  infer_instance
