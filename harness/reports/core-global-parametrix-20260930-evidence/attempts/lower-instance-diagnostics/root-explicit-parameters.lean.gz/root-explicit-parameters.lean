import Poincare.Global.DeTurckPrincipalIdentity
open Poincare.DeTurckPrincipalSecondJet
noncomputable section
set_option backward.isDefEq.respectTransparency false
local instance jGroup : NormedAddCommGroup Jet1 := ContinuousLinearMap.toNormedAddCommGroup (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ)
local instance jSpace : NormedSpace ℝ Jet1 := ContinuousLinearMap.toNormedSpace (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ) (𝕜' := ℝ)
#synth NormedAddCommGroup Jet1
#synth NormedSpace ℝ Jet1
example (J : Jet1) : ‖J‖ = ContinuousLinearMap.opNorm (𝕜 := ℝ) (𝕜₂ := ℝ) (E := E) (F := Bilin) (σ₁₂ := RingHom.id ℝ) J := rfl
