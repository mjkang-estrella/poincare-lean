import Poincare.Global.DeTurckPrincipalIdentity
open Poincare.DeTurckPrincipalSecondJet
noncomputable section
set_option backward.isDefEq.respectTransparency false
example : NormedAddCommGroup Jet1 := by
  change NormedAddCommGroup (E →L[ℝ] Bilin)
  exact ContinuousLinearMap.toNormedAddCommGroup (E := E) (F := Bilin)
