import Poincare.Global.DeTurckPrincipalIdentity
open Poincare.DeTurckPrincipalSecondJet
noncomputable section
set_option backward.isDefEq.respectTransparency false
local instance cGroup : NormedAddCommGroup (E →L[ℝ] ℝ) := ContinuousLinearMap.toNormedAddCommGroup (E := E) (F := ℝ)
local instance cSpace : NormedSpace ℝ (E →L[ℝ] ℝ) := ContinuousLinearMap.toNormedSpace (E := E) (F := ℝ)
local instance bGroup : NormedAddCommGroup Bilin := ContinuousLinearMap.toNormedAddCommGroup (E := E) (F := E →L[ℝ] ℝ)
local instance bSpace : NormedSpace ℝ Bilin := ContinuousLinearMap.toNormedSpace (E := E) (F := E →L[ℝ] ℝ)
local instance jGroup : NormedAddCommGroup Jet1 := ContinuousLinearMap.toNormedAddCommGroup (E := E) (F := Bilin)
local instance jSpace : NormedSpace ℝ Jet1 := ContinuousLinearMap.toNormedSpace (E := E) (F := Bilin)
#synth NormedAddCommGroup Jet1
#synth NormedSpace ℝ Jet1
example (J : Jet1) : ‖J‖ = ContinuousLinearMap.opNorm (E := E) (F := Bilin) J := rfl
