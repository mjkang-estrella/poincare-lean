import hashlib,json
from pathlib import Path
from harness.v2.runtime.validation import statement_contract_snapshot
root=Path.cwd();folder=root/'harness/v2/contracts/core-global-parametrix-20260930';state=root/'harness/v2/state/core-global-parametrix-20260930'
E='Poincare.ClosedSmoothModel 3';FA='Poincare.FiniteAtlasParabolicTensorSpace';GA='Poincare.GlobalParametrixAssembly';V='Poincare.FiniteAtlasBufferedTensorValue.value';Y=f'{FA}.Scalar α T';G=f'{FA}.Jet α T';YM=f'{FA}.Y_M A α T'
common=f'''∀ (M : Type u) [TopologicalSpace M]
[ChartedSpace ({E}) M]
[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]
(A : {FA}.AtlasData M) (α T : ℝ)
(S : Fin A.cover.chartCount → ({Y}) →L[ℝ] ({G}))
(B : {GA}.Transports A α T),\n'''
supported=f'''∀ i j c d (w : {GA}.SourceGraphs α T) t z,
z ∉ {FA}.coordSupport A i → (B i j c d w).u (t,z) = 0'''
chartvalue=f'''∀ i j c d (w : {GA}.SourceGraphs α T) t (x : M),
x ∈ ({FA}.chart A i).source →
(B i j c d w).u (t,{FA}.chart A i x) =
A.partition i x * (@ite ℝ (x ∈ ({FA}.chart A j).source) (Classical.propDecidable _)
 (∑ a : Fin 3, ∑ b : Fin 3,
   ξ j ({FA}.chart A j x) * {FA}.jac A i j x a c * {FA}.jac A i j x b d *
   (w (a,b)).u (t,{FA}.chart A j x)) 0)'''
valueformula=f'''∀ (f : {YM}) i c d t (x : M), x ∈ ({FA}.chart A i).source →
(({GA}.ambient A α T S B f) (i,c,d)).u (t,{FA}.chart A i x) =
{V} A ξ (fun j a b z => (S j (f.val (j,a,b))).u (t,z)) i c d x'''
range_t=common+f'''∀ ξ : Fin A.cover.chartCount → {E} → ℝ,
({supported}) → ({chartvalue}) →
(∀ f : {YM}, {GA}.ambient A α T S B f ∈ {FA}.tensorSubmodule A ({FA}.evalX α T)) ∧
({valueformula})'''
norm_t=common+f'''∀ (CP : ℝ) (CB : Fin A.cover.chartCount → Fin A.cover.chartCount → Fin 3 → Fin 3 → ℝ),
0 ≤ CP → (∀ i j c d, 0 ≤ CB i j c d) →
(∀ i j c d, ‖B i j c d‖ ≤ CB i j c d) →
(∀ j (h : {Y}), (∀ p, p.2 ∉ {FA}.coordSupport A j → h p = 0) →
 ‖S j h‖ ≤ CP * ‖h‖) →
‖{GA}.ambient A α T S B‖ ≤ CP *
 (∑ i : Fin A.cover.chartCount, ∑ j : Fin A.cover.chartCount,
   ∑ c : Fin 3, ∑ d : Fin 3, CB i j c d)'''
pins=['Poincare/Global/RiemannianContext.lean','Poincare/Global/FiniteAtlasParabolicTensorSpace.lean','Poincare/Global/ParabolicSolutionGraph.lean','Poincare/Global/ParabolicHolderSpace.lean','Poincare/Global/GlobalParametrixAssemblyDefinitions.lean','Poincare/Global/FiniteAtlasBufferedTensorValueDefinitions.lean']
for slug,mod,name,t in [('range','GlobalParametrixAssemblyRange','ambient_mem_and_chart_value',range_t),('bound','GlobalParametrixAssemblyBound','ambient_norm_le',norm_t)]:
 c={'imports':['Poincare.Global.'+mod],'declarations':[{'name':GA+'.'+name,'lean_type':t,'universes':['u']}],'definition_files':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in pins],'author':'root-orchestrator'}
 c['review']={'reviewer':'global-parametrix-readback','method':'blind-readback','snapshot_sha256':statement_contract_snapshot(c),'verdict':'pending','report_path':f'harness/v2/contracts/core-global-parametrix-20260930/{slug}.readback.json','report_sha256':'0'*64}
 (folder/f'{slug}.contract.json').write_text(json.dumps({'schema_version':'1.0','statement_contract':c},ensure_ascii=False,indent=2)+'\n')
 pre='import Poincare.Global.GlobalParametrixAssemblyDefinitions\nimport Poincare.Global.FiniteAtlasBufferedTensorValueDefinitions\nimport Lean\nopen Lean Elab Command Term\nuniverse u\n'
 pre+=f'run_cmd liftTermElabM do\n  let stx ← match Parser.runParserCategory (← getEnv) `term {json.dumps(t,ensure_ascii=False)} with\n    | .ok s => pure s\n    | .error e => throwError e\n  let expected ← Term.elabType stx\n  Term.synthesizeSyntheticMVarsNoPostponing\n  let expected ← instantiateMVars expected\n  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"\n  logInfo "PREFLIGHT_OK: {name}"\n'
 (state/f'{slug}.preflight.lean').write_text(pre)
(folder/'construction-context.md').write_text('''# Actual global parametrix toward core Hamilton existence

Every Task helps UniversalHamiltonConvergenceStatement through actual general Ricci-flow input construction. Range and bound are consumed immediately by the actual-g0 global constructor, then the true full DeTurck L/P/R identity and contraction. Smoothability and universal Hamilton endpoints remain open.

The pinned ambient CLM uses the same S_j on all source slots, actual finite B_ij component maps, genuine Y_M entries and their canonical submodule/Pi/Graph norms. The range Task must derive source symmetry from Y_M symmetry and linear-map congruence, then use actual support/value and the already verified finite tensor symmetry/transition proof. Off coordSupport use support; inside coordSupport recover a true source chart point. No extra compatibility or package premise is allowed.

The bound Task must use only supported-input estimates for S_j, supplied by the actual local producer. It must derive that Y_M forcing entries have that support via supported_entry, rather than claim unrestricted local opNorm bounds. A finite total sum of nonnegative B bounds gives the global bound. No completeness, alternative norm or new NormedSpace instance is needed.

The final constructor must CONSTRUCT all A,psi,xi,S,R,B inputs from g0 and 0<alpha<1 using the existing MetricAdaptedLocalParametrix and gated extension/entry transport producers, then codRestrict the actual ambient CLM into X_M. Retain the same local residual/support witnesses, buffers and B norm/value certificates, full Graph equality to the finite transported local-solvers sum, and a bound before T. Bare existence of an unspecified P or new assumed flow/operator package does not meet the target.

Local Codex helpers are local proof attempts, not registered Pi/Leanstral Jobs. Preserve every failed compiler/source attempt and final diff. Do not perform full builds or acceptance/merges from workers.
''')
