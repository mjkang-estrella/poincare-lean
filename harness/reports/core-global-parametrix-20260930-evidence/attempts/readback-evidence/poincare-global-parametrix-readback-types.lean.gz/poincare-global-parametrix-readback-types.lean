import Poincare.Global.FiniteAtlasBufferedTensorValueDefinitions
import Poincare.Global.FiniteAtlasParabolicTensorSpace

noncomputable section
set_option autoImplicit false
open scoped Manifold ContDiff

namespace Poincare.GlobalParametrixAssembly
open FiniteAtlasParabolicTensorSpace
universe u
variable {M : Type u} [TopologicalSpace M]
  [ChartedSpace (ClosedSmoothModel 3) M]
  [IsManifold (closedSmoothModelWithCorners 3) ∞ M]

abbrev SourceGraphs (α T : ℝ) := (Fin 3 × Fin 3) → Jet α T
abbrev Transports (A : AtlasData M) (α T : ℝ) :=
  Fin A.cover.chartCount → Fin A.cover.chartCount → Fin 3 → Fin 3 →
    SourceGraphs α T →L[ℝ] Jet α T

/-- Apply the same genuine scalar local solver to each source component. -/
def localGraphs (A : AtlasData M) (α T : ℝ)
    (S : Fin A.cover.chartCount → Scalar α T →L[ℝ] Jet α T)
    (j : Fin A.cover.chartCount) : Y_M A α T →L[ℝ] SourceGraphs α T :=
  ContinuousLinearMap.pi fun k => (S j).comp
    ((ContinuousLinearMap.proj (j, k.1, k.2)).comp
      (tensorSubmodule A (evalY α T)).subtypeL)

/-- The actual finite transported local-solver sum, before codomain restriction. -/
def ambient (A : AtlasData M) (α T : ℝ)
    (S : Fin A.cover.chartCount → Scalar α T →L[ℝ] Jet α T)
    (B : Transports A α T) : Y_M A α T →L[ℝ] LocalProduct A (Jet α T) :=
  ContinuousLinearMap.pi fun k => ∑ j : Fin A.cover.chartCount,
    (B k.1 j k.2.1 k.2.2).comp (localGraphs A α T S j)

end Poincare.GlobalParametrixAssembly

universe u

#check (∀ (M : Type u) [TopologicalSpace M]
[ChartedSpace (Poincare.ClosedSmoothModel 3) M]
[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]
(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M) (α T : ℝ)
(S : Fin A.cover.chartCount → (Poincare.FiniteAtlasParabolicTensorSpace.Scalar α T) →L[ℝ] (Poincare.FiniteAtlasParabolicTensorSpace.Jet α T))
(B : Poincare.GlobalParametrixAssembly.Transports A α T),
∀ ξ : Fin A.cover.chartCount → Poincare.ClosedSmoothModel 3 → ℝ,
(∀ i j c d (w : Poincare.GlobalParametrixAssembly.SourceGraphs α T) t z,
z ∉ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A i → (B i j c d w).u (t,z) = 0) → (∀ i j c d (w : Poincare.GlobalParametrixAssembly.SourceGraphs α T) t (x : M),
x ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).source →
(B i j c d w).u (t,Poincare.FiniteAtlasParabolicTensorSpace.chart A i x) =
A.partition i x * (@ite ℝ (x ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).source) (Classical.propDecidable _)
 (∑ a : Fin 3, ∑ b : Fin 3,
   ξ j (Poincare.FiniteAtlasParabolicTensorSpace.chart A j x) * Poincare.FiniteAtlasParabolicTensorSpace.jac A i j x a c * Poincare.FiniteAtlasParabolicTensorSpace.jac A i j x b d *
   (w (a,b)).u (t,Poincare.FiniteAtlasParabolicTensorSpace.chart A j x)) 0)) →
(∀ f : Poincare.FiniteAtlasParabolicTensorSpace.Y_M A α T, Poincare.GlobalParametrixAssembly.ambient A α T S B f ∈ Poincare.FiniteAtlasParabolicTensorSpace.tensorSubmodule A (Poincare.FiniteAtlasParabolicTensorSpace.evalX α T)) ∧
(∀ (f : Poincare.FiniteAtlasParabolicTensorSpace.Y_M A α T) i c d t (x : M), x ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).source →
((Poincare.GlobalParametrixAssembly.ambient A α T S B f) (i,c,d)).u (t,Poincare.FiniteAtlasParabolicTensorSpace.chart A i x) =
Poincare.FiniteAtlasBufferedTensorValue.value A ξ (fun j a b z => (S j (f.val (j,a,b))).u (t,z)) i c d x))

#check (∀ (M : Type u) [TopologicalSpace M]
[ChartedSpace (Poincare.ClosedSmoothModel 3) M]
[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]
(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M) (α T : ℝ)
(S : Fin A.cover.chartCount → (Poincare.FiniteAtlasParabolicTensorSpace.Scalar α T) →L[ℝ] (Poincare.FiniteAtlasParabolicTensorSpace.Jet α T))
(B : Poincare.GlobalParametrixAssembly.Transports A α T),
∀ (CP : ℝ) (CB : Fin A.cover.chartCount → Fin A.cover.chartCount → Fin 3 → Fin 3 → ℝ),
0 ≤ CP → (∀ i j c d, 0 ≤ CB i j c d) →
(∀ i j c d, ‖B i j c d‖ ≤ CB i j c d) →
(∀ j (h : Poincare.FiniteAtlasParabolicTensorSpace.Scalar α T), (∀ p, p.2 ∉ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A j → h p = 0) →
 ‖S j h‖ ≤ CP * ‖h‖) →
‖Poincare.GlobalParametrixAssembly.ambient A α T S B‖ ≤ CP *
 (∑ i : Fin A.cover.chartCount, ∑ j : Fin A.cover.chartCount,
   ∑ c : Fin 3, ∑ d : Fin 3, CB i j c d))
