import Poincare.Global.MetricAdaptedLocalParametrix
import Poincare.Global.BufferedTensorGraphTransportDefinitions
import Poincare.Global.FiniteAtlasBufferedTensorValueDefinitions
import Poincare.Global.FiniteAtlasParabolicTensorSpace

noncomputable section
set_option autoImplicit false
open scoped Manifold ContDiff

namespace Poincare.GlobalParametrixAssembly
open FiniteAtlasParabolicTensorSpace
universe u
variable {M : Type u} [TopologicalSpace M]
  [ChartedSpace (ClosedSmoothModel 3) M]
  [IsManifold (closedSmoothModelWithCorners 3) ∞ M]

abbrev SourceGraphs (α T : ℝ) := (Fin 3 × Fin 3) → Jet α T
abbrev Transports (A : AtlasData M) (α T : ℝ) :=
  Fin A.cover.chartCount → Fin A.cover.chartCount → Fin 3 → Fin 3 →
    SourceGraphs α T →L[ℝ] Jet α T

/-- Apply the same genuine scalar local solver to each source component. -/
def localGraphs (A : AtlasData M) (α T : ℝ)
    (S : Fin A.cover.chartCount → Scalar α T →L[ℝ] Jet α T)
    (j : Fin A.cover.chartCount) : Y_M A α T →L[ℝ] SourceGraphs α T :=
  ContinuousLinearMap.pi fun k => (S j).comp
    ((ContinuousLinearMap.proj (j, k.1, k.2)).comp
      (tensorSubmodule A (evalY α T)).subtypeL)

/-- The actual finite transported local-solver sum, before codomain restriction. -/
def ambient (A : AtlasData M) (α T : ℝ)
    (S : Fin A.cover.chartCount → Scalar α T →L[ℝ] Jet α T)
    (B : Transports A α T) : Y_M A α T →L[ℝ] LocalProduct A (Jet α T) :=
  ContinuousLinearMap.pi fun k => ∑ j : Fin A.cover.chartCount,
    (B k.1 j k.2.1 k.2.2).comp (localGraphs A α T S j)

end Poincare.GlobalParametrixAssembly

universe u

#check (∀ {M : Type u} [TopologicalSpace M] [T2Space M] [CompactSpace M] [ChartedSpace (Poincare.ClosedSmoothModel 3) M], ∀ [IsManifold (modelWithCornersSelf ℝ (Poincare.ClosedSmoothModel 3)) ((⊤ : ENat) : WithTop ENat) M], ∀ (g0 : Poincare.ClosedSmoothRiemannianMetric 3 M) (α : ℝ), 0 < α → α < 1 →
 ∃ A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M,
 ∃ ψ ξ : Fin A.cover.chartCount → (Poincare.ClosedSmoothModel 3) → ℝ,
 (∀ i, ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (ψ i) ∧ HasCompactSupport (ψ i) ∧
   (∀ z ∈ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A i, Filter.Eventually (fun y ↦ ψ i y = 1) (nhds z)) ∧
   (∀ z, ψ i z ∈ Set.Icc 0 1) ∧
   ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (ξ i) ∧ HasCompactSupport (ξ i) ∧
   (∀ z, ξ i z ∈ Set.Icc 0 1) ∧ (∀ z ∈ tsupport (ψ i), ξ i z = 1) ∧
   tsupport (ξ i) ⊆ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).target ∧
   (∀ z ∈ tsupport (ξ i), Filter.Eventually (fun y ↦ Poincare.GeodesicTransport.cutoff (n := 3) (A.cover.anchor i) y = 1) (nhds z))) ∧
 ∃ θ : Fin A.cover.chartCount → Fin A.cover.chartCount → Poincare.ClosedSmoothModel 3 → ℝ,
 ∃ F : Fin A.cover.chartCount → Fin A.cover.chartCount → Poincare.ClosedSmoothModel 3 → Poincare.ClosedSmoothModel 3,
 (∀ i j,
 ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (θ i j) ∧ HasCompactSupport (θ i j) ∧
 (∀ z, θ i j z ∈ Set.Icc 0 1) ∧
 tsupport (θ i j) ⊆ ((Poincare.FiniteAtlasParabolicTensorSpace.chart A i).symm.trans (Poincare.FiniteAtlasParabolicTensorSpace.chart A j)).source ∧
 (∀ z ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i) '' (tsupport (A.partition i) ∩ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).symm '' tsupport (ξ j)),
  Filter.Eventually (fun y => θ i j y = 1) (nhds z)) ∧
 ContDiff ℝ ((⊤ : ENat) : WithTop ENat) (F i j) ∧ HasCompactSupport (F i j) ∧
 (∀ z ∈ tsupport (θ i j), Filter.Eventually (fun y => F i j y = Poincare.FiniteAtlasParabolicTensorSpace.change A i j y) (nhds z)) ∧
 ∃ L : NNReal, LipschitzWith L (F i j)) ∧
 ∃ Cψ CP Cglobal τ : ℝ,
 ∃ CB : Fin A.cover.chartCount → Fin A.cover.chartCount → Fin 3 → Fin 3 → ℝ,
 0 ≤ Cψ ∧ 0 ≤ CP ∧ 0 < τ ∧ τ ≤ 1 ∧ (∀ i j c d, 0 ≤ CB i j c d) ∧
 Cglobal = CP * (∑ i : Fin A.cover.chartCount, ∑ j : Fin A.cover.chartCount,
   ∑ c : Fin 3, ∑ d : Fin 3, CB i j c d) ∧
 ∀ T ∈ Set.Ioc 0 τ,
 ∃ S : Fin A.cover.chartCount → (Poincare.FiniteAtlasParabolicTensorSpace.Scalar α T) →L[ℝ] (Poincare.FiniteAtlasParabolicTensorSpace.Jet α T),
 ∃ R : Fin A.cover.chartCount → (Poincare.FiniteAtlasParabolicTensorSpace.Scalar α T) →L[ℝ] (Poincare.FiniteAtlasParabolicTensorSpace.Scalar α T),
 ∃ B : Poincare.GlobalParametrixAssembly.Transports A α T,
 ∃ Pglobal : (Poincare.FiniteAtlasParabolicTensorSpace.Y_M A α T) →L[ℝ] (Poincare.FiniteAtlasParabolicTensorSpace.X_M A α T),
 (∀ i, (∀ f p, p.2 ∉ tsupport (ψ i) → (S i f).u p = 0) ∧
     ∀ f : (Poincare.ParabolicHolder.Y (E := (Poincare.ClosedSmoothModel 3)) α T ℝ), (∀ p, p.2 ∉ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A i → f p = 0) →
       (∀ p, R i f p = Poincare.BufferedFrozenParabolicSolver.chartValue
         (fun z ↦ @Inv.inv (Matrix (Fin 3) (Fin 3) ℝ) Matrix.inv
           (Poincare.inverseChartPullbackGramMatrixField g0 (A.cover.anchor i) z))
         (S i f) p - f p) ∧
       ‖R i f‖ ≤ Cψ * (T ^ ((1-α)/2) + T ^ (1-α/2)) * ‖f‖ ∧
       ‖S i f‖ ≤ CP * ‖f‖) ∧
 (∀ i j c d, ‖B i j c d‖ ≤ CB i j c d ∧ (∀ w p, (B i j c d w).u p = ∑ a : Fin 3, ∑ b : Fin 3,
 Poincare.BufferedTensorGraphTransport.weight A i (θ i j) (ξ j) (F i j) a b c d p.2 *
 (w (a,b)).u (p.1,F i j p.2)) ∧ (∀ (w : Poincare.GlobalParametrixAssembly.SourceGraphs α T) t z,
z ∉ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A i → (B i j c d w).u (t,z) = 0) ∧ (∀ (w : Poincare.GlobalParametrixAssembly.SourceGraphs α T) t (x : M),
x ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).source →
(B i j c d w).u (t,Poincare.FiniteAtlasParabolicTensorSpace.chart A i x) =
A.partition i x * (@ite ℝ (x ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).source) (Classical.propDecidable _)
 (∑ a : Fin 3, ∑ b : Fin 3,
   ξ j (Poincare.FiniteAtlasParabolicTensorSpace.chart A j x) * Poincare.FiniteAtlasParabolicTensorSpace.jac A i j x a c * Poincare.FiniteAtlasParabolicTensorSpace.jac A i j x b d *
   (w (a,b)).u (t,Poincare.FiniteAtlasParabolicTensorSpace.chart A j x)) 0))) ∧
 ‖Pglobal‖ ≤ Cglobal ∧
 (∀ (f : Poincare.FiniteAtlasParabolicTensorSpace.Y_M A α T) i c d, (Pglobal f).val (i,c,d) =
   ∑ j : Fin A.cover.chartCount, B i j c d (fun ab => S j (f.val (j,ab.1,ab.2)))) ∧
 (∀ (f : Poincare.FiniteAtlasParabolicTensorSpace.Y_M A α T) i c d t (x : M), x ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).source →
((Pglobal f).val (i,c,d)).u (t,Poincare.FiniteAtlasParabolicTensorSpace.chart A i x) =
Poincare.FiniteAtlasBufferedTensorValue.value A ξ (fun j a b z => (S j (f.val (j,a,b))).u (t,z)) i c d x))
