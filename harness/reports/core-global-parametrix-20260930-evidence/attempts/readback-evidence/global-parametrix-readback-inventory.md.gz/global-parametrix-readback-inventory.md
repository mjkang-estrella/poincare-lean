# Global parametrix readback evidence

The four files listed in global-parametrix-readback-inventory.json were copied unchanged from /tmp. The two .lean files are literal type probes. The two .log files retain their original commands, exit codes, stdout, and stderr. Both original checks exited 0. No checks were rerun during archival, and no reviewed reports, contracts, or Lean sources were edited.
