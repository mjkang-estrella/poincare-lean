import Poincare.Global.MetricAdaptedGlobalParametrix
import Poincare.Global.SmoothInitialMetricExistence
noncomputable section
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
open Set
open scoped Manifold ContDiff
open Poincare Poincare.FiniteAtlasParabolicTensorSpace
universe u
example {M : Type u} [TopologicalSpace M] [T2Space M] [CompactSpace M]
    [ChartedSpace (ClosedSmoothModel 3) M]
    [IsManifold (closedSmoothModelWithCorners 3) ∞ M]
    (α : ℝ) (hα : 0 < α) (hα1 : α < 1) :
    ∃ A : AtlasData M, ∃ C τ : ℝ, 0 < τ ∧ τ ≤ 1 ∧
    ∀ T ∈ Ioc (0 : ℝ) τ,
      ∃ S : Fin A.cover.chartCount → Scalar α T →L[ℝ] Jet α T,
      ∃ B : GlobalParametrixAssembly.Transports A α T,
      ∃ P : Y_M A α T →L[ℝ] X_M A α T,
        ‖P‖ ≤ C ∧ ∀ (f : Y_M A α T) i c d,
          (P f).val (i,c,d) =
            ∑ j : Fin A.cover.chartCount, B i j c d (fun ab => S j (f.val (j,ab.1,ab.2))) := by
  obtain ⟨g0⟩ := SmoothInitialMetricExistence.exists_initial_metric (M := M)
  obtain ⟨A, ψ, ξ, hb, θ, F, hg, Cψ, CP, C, τ, CB,
    hCψ, hCP, hτ, hτ1, hCB, hCeq, hoperators⟩ :=
    MetricAdaptedGlobalParametrix.exists_metric_adapted_global_parametrix g0 α hα hα1
  refine ⟨A, C, τ, hτ, hτ1, ?_⟩
  intro T hT
  obtain ⟨S, R, B, P, hlocal, hB, hP, hsum, hvalue⟩ := hoperators T hT
  exact ⟨S, B, P, hP, hsum⟩
