import Poincare.Global.GlobalParametrixAssemblyDefinitions
import Poincare.Global.FiniteAtlasBufferedTensorValueDefinitions
import Lean
open Lean Elab Command Term
universe u
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M]\n[ChartedSpace (Poincare.ClosedSmoothModel 3) M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M) (α T : ℝ)\n(S : Fin A.cover.chartCount → (Poincare.FiniteAtlasParabolicTensorSpace.Scalar α T) →L[ℝ] (Poincare.FiniteAtlasParabolicTensorSpace.Jet α T))\n(B : Poincare.GlobalParametrixAssembly.Transports A α T),\n∀ (CP : ℝ) (CB : Fin A.cover.chartCount → Fin A.cover.chartCount → Fin 3 → Fin 3 → ℝ),\n0 ≤ CP → (∀ i j c d, 0 ≤ CB i j c d) →\n(∀ i j c d, ‖B i j c d‖ ≤ CB i j c d) →\n(∀ j (h : Poincare.FiniteAtlasParabolicTensorSpace.Scalar α T), (∀ p, p.2 ∉ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A j → h p = 0) →\n ‖S j h‖ ≤ CP * ‖h‖) →\n‖Poincare.GlobalParametrixAssembly.ambient A α T S B‖ ≤ CP *\n (∑ i : Fin A.cover.chartCount, ∑ j : Fin A.cover.chartCount,\n   ∑ c : Fin 3, ∑ d : Fin 3, CB i j c d)" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"
  logInfo "PREFLIGHT_OK: ambient_norm_le"
