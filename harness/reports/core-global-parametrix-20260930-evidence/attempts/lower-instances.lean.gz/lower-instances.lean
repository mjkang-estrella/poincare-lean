import Poincare.Global.DeTurckPrincipalIdentity
open Poincare.DeTurckPrincipalSecondJet
#synth NormedAddCommGroup E
#synth NormedSpace ℝ E
#synth NormedAddCommGroup Bilin
#synth NormedSpace ℝ Bilin
#synth NormedAddCommGroup Jet1
#synth NormedSpace ℝ Jet1
#print Poincare.DeTurckPrincipalSecondJet.Bilin
#print Poincare.DeTurckPrincipalSecondJet.Jet1
set_option backward.isDefEq.respectTransparency false
#synth NormedAddCommGroup (Bilin × Jet1)
#synth NormedSpace ℝ (Bilin × Jet1)
