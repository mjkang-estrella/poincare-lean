import Poincare.Global.GlobalParametrixAssemblyDefinitions
import Poincare.Global.FiniteAtlasBufferedTensorValueDefinitions
import Lean
open Lean Elab Command Term
universe u
run_cmd liftTermElabM do
  let stx ← match Parser.runParserCategory (← getEnv) `term "∀ (M : Type u) [TopologicalSpace M]\n[ChartedSpace (Poincare.ClosedSmoothModel 3) M]\n[IsManifold (Poincare.closedSmoothModelWithCorners 3) ((⊤ : ENat) : WithTop ENat) M]\n(A : Poincare.FiniteAtlasParabolicTensorSpace.AtlasData M) (α T : ℝ)\n(S : Fin A.cover.chartCount → (Poincare.FiniteAtlasParabolicTensorSpace.Scalar α T) →L[ℝ] (Poincare.FiniteAtlasParabolicTensorSpace.Jet α T))\n(B : Poincare.GlobalParametrixAssembly.Transports A α T),\n∀ ξ : Fin A.cover.chartCount → Poincare.ClosedSmoothModel 3 → ℝ,\n(∀ i j c d (w : Poincare.GlobalParametrixAssembly.SourceGraphs α T) t z,\nz ∉ Poincare.FiniteAtlasParabolicTensorSpace.coordSupport A i → (B i j c d w).u (t,z) = 0) → (∀ i j c d (w : Poincare.GlobalParametrixAssembly.SourceGraphs α T) t (x : M),\nx ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).source →\n(B i j c d w).u (t,Poincare.FiniteAtlasParabolicTensorSpace.chart A i x) =\nA.partition i x * (@ite ℝ (x ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A j).source) (Classical.propDecidable _)\n (∑ a : Fin 3, ∑ b : Fin 3,\n   ξ j (Poincare.FiniteAtlasParabolicTensorSpace.chart A j x) * Poincare.FiniteAtlasParabolicTensorSpace.jac A i j x a c * Poincare.FiniteAtlasParabolicTensorSpace.jac A i j x b d *\n   (w (a,b)).u (t,Poincare.FiniteAtlasParabolicTensorSpace.chart A j x)) 0)) →\n(∀ f : Poincare.FiniteAtlasParabolicTensorSpace.Y_M A α T, Poincare.GlobalParametrixAssembly.ambient A α T S B f ∈ Poincare.FiniteAtlasParabolicTensorSpace.tensorSubmodule A (Poincare.FiniteAtlasParabolicTensorSpace.evalX α T)) ∧\n(∀ (f : Poincare.FiniteAtlasParabolicTensorSpace.Y_M A α T) i c d t (x : M), x ∈ (Poincare.FiniteAtlasParabolicTensorSpace.chart A i).source →\n((Poincare.GlobalParametrixAssembly.ambient A α T S B f) (i,c,d)).u (t,Poincare.FiniteAtlasParabolicTensorSpace.chart A i x) =\nPoincare.FiniteAtlasBufferedTensorValue.value A ξ (fun j a b z => (S j (f.val (j,a,b))).u (t,z)) i c d x)" with
    | .ok s => pure s
    | .error e => throwError e
  let expected ← Term.elabType stx
  Term.synthesizeSyntheticMVarsNoPostponing
  let expected ← instantiateMVars expected
  if expected.hasMVar || expected.hasLevelMVar then throwError "unresolved metavariables"
  logInfo "PREFLIGHT_OK: ambient_mem_and_chart_value"
